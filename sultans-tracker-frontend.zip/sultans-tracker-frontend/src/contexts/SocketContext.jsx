import { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';

const SocketContext = createContext();

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [securityAlerts, setSecurityAlerts] = useState([]);
  const { user, isAuthenticated, logout } = useAuth();

  useEffect(() => {
    if (isAuthenticated && user) {
      console.log(' Connecting to Socket.IO...');
      
      const newSocket = io('http://localhost:5000', {
        auth: {
          token: localStorage.getItem('token')
        }
      });

      newSocket.on('connect', () => {
        console.log(' Socket.IO connected:', newSocket.id);
        setIsConnected(true);
        
        // Join user-specific room for security alerts
        newSocket.emit('join_user_room', user.id);
      });

      newSocket.on('disconnect', (reason) => {
        console.log(' Socket.IO disconnected:', reason);
        setIsConnected(false);
        
        // If disconnect was due to authentication issues, logout
        if (reason === 'io server disconnect' || reason === 'transport close') {
          console.log(' Socket disconnected due to server issues');
        }
      });

      newSocket.on('connect_error', (error) => {
        console.error(' Socket.IO connection error:', error);
        // If authentication failed, logout user
        if (error.message.includes('auth') || error.message.includes('401') || error.message.includes('403')) {
          console.log(' Authentication failed on socket, logging out');
          logout('Socket authentication failed');
        }
      });

      newSocket.on('security_alert', (alertData) => {
        console.log(' Real-time security alert received:', alertData);
        
        // Add alert to state
        setSecurityAlerts(prev => [alertData, ...prev.slice(0, 9)]); // Keep last 10 alerts
        
        // Show browser notification
        if (Notification.permission === 'granted') {
          new Notification('Security Alert', {
            body: alertData.message,
            icon: '/security-shield.png'
          });
        }
      });

      setSocket(newSocket);

      return () => {
        console.log(' Cleaning up Socket.IO connection');
        if (newSocket) {
          newSocket.disconnect();
        }
      };
    } else {
      // If not authenticated, ensure socket is disconnected
      if (socket) {
        console.log(' Disconnecting socket due to authentication change');
        socket.disconnect();
        setSocket(null);
        setIsConnected(false);
      }
    }
  }, [isAuthenticated, user, logout]);

  const value = {
    socket,
    isConnected,
    securityAlerts,
    clearAlerts: () => setSecurityAlerts([]),
    sendTransactionForMonitoring: (transactionData) => {
      if (socket && isConnected) {
        socket.emit('monitor_transaction', transactionData);
      }
    }
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};