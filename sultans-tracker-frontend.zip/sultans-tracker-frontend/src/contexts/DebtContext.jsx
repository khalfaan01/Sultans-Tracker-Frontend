// src/contexts/DebtContext.jsx
import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { debtAPI } from '../services/debtService.js';
import { useAuth } from './AuthContext.jsx';

const DebtContext = createContext();

const debtReducer = (state, action) => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    
    case 'SET_DEBTS':
      return { ...state, debts: action.payload, loading: false };
    
    case 'ADD_DEBT':
      return { ...state, debts: [...state.debts, action.payload] };
    
    case 'UPDATE_DEBT':
      return {
        ...state,
        debts: state.debts.map(debt =>
          debt.id === action.payload.id ? action.payload : debt
        )
      };
    
    case 'DELETE_DEBT':
      return {
        ...state,
        debts: state.debts.filter(debt => debt.id !== action.payload)
      };
    
    case 'SET_ANALYTICS':
      return { ...state, analytics: action.payload };
    
    case 'SET_ERROR':
      return { ...state, error: action.payload, loading: false };
    
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    
    default:
      return state;
  }
};

const initialState = {
  debts: [],
  analytics: null,
  loading: false,
  error: null
};

export const DebtProvider = ({ children }) => {
  const [state, dispatch] = useReducer(debtReducer, initialState);
  const { isAuthenticated, loading: authLoading } = useAuth();

  // Load all debts
  const loadDebts = async () => {
    if (!isAuthenticated) {
      console.log('🔐 DebtContext - Skipping debt load: user not authenticated');
      return;
    }

    try {
      console.log('🔐 DebtContext - Loading debts for authenticated user');
      dispatch({ type: 'SET_LOADING', payload: true });
      const debts = await debtAPI.getAll();
      dispatch({ type: 'SET_DEBTS', payload: debts });
    } catch (error) {
      console.error('🔐 DebtContext - Failed to load debts:', error);
      if (error.response?.status === 401) {
        console.log('🔐 DebtContext - Token invalid, clearing data');
        dispatch({ type: 'SET_DEBTS', payload: [] });
        dispatch({ type: 'SET_ANALYTICS', payload: null });
      } else {
        dispatch({ type: 'SET_ERROR', payload: error.message });
      }
    }
  };

  // Load debt analytics
  const loadAnalytics = async () => {
    if (!isAuthenticated) {
      console.log('🔐 DebtContext - Skipping analytics load: user not authenticated');
      return;
    }

    try {
      console.log('🔐 DebtContext - Loading analytics for authenticated user');
      const analytics = await debtAPI.getAnalytics();
      dispatch({ type: 'SET_ANALYTICS', payload: analytics });
    } catch (error) {
      console.error('🔐 DebtContext - Failed to load debt analytics:', error);
      // Don't set error state for analytics failures to avoid breaking the UI
    }
  };

  // Add new debt
  const addDebt = async (debtData) => {
    if (!isAuthenticated) {
      throw new Error('User must be authenticated to add debts');
    }

    try {
      const newDebt = await debtAPI.create(debtData);
      dispatch({ type: 'ADD_DEBT', payload: newDebt });
      await loadAnalytics(); // Refresh analytics
      return newDebt;
    } catch (error) {
      console.error('🔐 DebtContext - Failed to add debt:', error);
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  // Update debt
  const updateDebt = async (id, debtData) => {
    if (!isAuthenticated) {
      throw new Error('User must be authenticated to update debts');
    }

    try {
      const updatedDebt = await debtAPI.update(id, debtData);
      dispatch({ type: 'UPDATE_DEBT', payload: updatedDebt });
      await loadAnalytics(); // Refresh analytics
      return updatedDebt;
    } catch (error) {
      console.error('🔐 DebtContext - Failed to update debt:', error);
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  // Delete debt
  const deleteDebt = async (id) => {
    if (!isAuthenticated) {
      throw new Error('User must be authenticated to delete debts');
    }

    try {
      await debtAPI.delete(id);
      dispatch({ type: 'DELETE_DEBT', payload: id });
      await loadAnalytics(); // Refresh analytics
    } catch (error) {
      console.error('🔐 DebtContext - Failed to delete debt:', error);
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  // Make payment
  const makePayment = async (id, paymentData) => {
    if (!isAuthenticated) {
      throw new Error('User must be authenticated to make payments');
    }

    try {
      const result = await debtAPI.makePayment(id, paymentData);
      await loadDebts(); // Refresh all debts
      await loadAnalytics(); // Refresh analytics
      return result;
    } catch (error) {
      console.error('🔐 DebtContext - Failed to make payment:', error);
      dispatch({ type: 'SET_ERROR', payload: error.message });
      throw error;
    }
  };

  // Clear error
  const clearError = () => {
    dispatch({ type: 'CLEAR_ERROR' });
  };

  // Refresh all debt data
  const refreshDebts = async () => {
    if (!isAuthenticated) {
      console.log('🔐 DebtContext - Cannot refresh: user not authenticated');
      return;
    }
    
    await loadDebts();
    await loadAnalytics();
  };

  // Load data when authentication state changes
  useEffect(() => {
    if (isAuthenticated && !authLoading) {
      console.log('🔐 DebtContext - User authenticated, loading debt data...');
      loadDebts();
      loadAnalytics();
    } else if (!isAuthenticated && !authLoading) {
      console.log('🔐 DebtContext - User not authenticated, clearing debt data');
      // Clear data when user logs out
      dispatch({ type: 'SET_DEBTS', payload: [] });
      dispatch({ type: 'SET_ANALYTICS', payload: null });
      dispatch({ type: 'CLEAR_ERROR' });
    }
  }, [isAuthenticated, authLoading]);

  

// Add to the value object in DebtProvider:
const value = {
  ...state,
  loadDebts,
  loadAnalytics,
  addDebt,
  updateDebt,
  deleteDebt,
  makePayment,
  clearError,
  refreshDebts,
  isAuthenticated,
  
  // NEW: Analytics integration functions
  getDebtToIncomeRatio: () => {
    if (!state.analytics) return 0;
    return state.analytics.totalDebt / (state.analytics.totalMonthlyIncome || 1);
  },
  
  getDebtProgress: () => {
    if (!state.analytics) return 0;
    const totalPaid = state.debts.reduce((sum, debt) => 
      sum + (debt.principal - debt.balance), 0);
    const totalPrincipal = state.debts.reduce((sum, debt) => 
      sum + debt.principal, 0);
    return totalPrincipal > 0 ? (totalPaid / totalPrincipal) * 100 : 0;
  },
  
  // For homepage summary
  getDebtSummary: () => ({
    totalDebt: state.analytics?.totalDebt || 0,
    totalMonthlyPayments: state.analytics?.totalMinimumPayments || 0,
    activeDebts: state.debts.filter(debt => debt.isActive).length,
    debtFreeDate: calculateDebtFreeDate(state.debts)
  })
};

// Helper function for debt-free date calculation
function calculateDebtFreeDate(debts) {
  const activeDebts = debts.filter(debt => debt.isActive);
  if (activeDebts.length === 0) return null;
  
  const maxPayoff = Math.max(...activeDebts.map(debt => 
    debt.estimatedPayoffMonths || 0
  ));
  
  if (maxPayoff > 0) {
    const date = new Date();
    date.setMonth(date.getMonth() + maxPayoff);
    return date;
  }
  
  return null;
}

  return (
    <DebtContext.Provider value={value}>
      {children}
    </DebtContext.Provider>
  );
};

export const useDebt = () => {
  const context = useContext(DebtContext);
  if (!context) {
    throw new Error('useDebt must be used within a DebtProvider');
  }
  return context;
};