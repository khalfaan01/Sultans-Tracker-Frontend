// src/contexts/AuthContext.jsx
import { createContext, useContext, useState, useEffect } from 'react';
import { authAPI } from '../services/api';

const AuthContext = createContext();

// Session timeout (24 hours)
const SESSION_TIMEOUT = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);

    // Enhanced logout with cleanup
  const logout = (reason = 'User initiated') => {
    console.log(` AuthContext - Logging out user: ${reason}`);
    
    // Clear all storage
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
    localStorage.removeItem('loginTime');
    localStorage.removeItem('lastActivity');
    
    console.log(' AuthContext - Storage cleared, redirecting to home');
    
    // Reset state
    setUser(null);
    setAuthenticated(false);
    
    // Redirect to home
    window.location.href = '/';
  };

  // Session timeout checker
  const checkSessionTimeout = () => {
    const loginTime = localStorage.getItem('loginTime');
    const lastActivity = localStorage.getItem('lastActivity');
    
    if (loginTime && lastActivity) {
      const timeSinceLogin = Date.now() - parseInt(loginTime);
      const timeSinceActivity = Date.now() - parseInt(lastActivity);
      
      // Logout if session exceeded 24 hours OR no activity for 24 hours
      if (timeSinceLogin > SESSION_TIMEOUT || timeSinceActivity > SESSION_TIMEOUT) {
        logout('Session timeout');
        return true;
      }
    }
    return false;
  };

  // Update last activity timestamp
  const updateLastActivity = () => {
    localStorage.setItem('lastActivity', Date.now().toString());
  };

  // Browser/tab close detection
  const setupBeforeUnload = () => {
    const handleBeforeUnload = (event) => {
      // Only clear tokens, don't show confirmation dialog for better UX
      localStorage.removeItem('token');
      localStorage.removeItem('refreshToken');
      console.log(' Browser closed - Tokens cleared for security');
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  };

  // User activity tracking
  const setupActivityTracking = () => {
    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    
    const updateActivity = () => {
      updateLastActivity();
    };

    events.forEach(event => {
      document.addEventListener(event, updateActivity);
    });

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, updateActivity);
      });
    };
  };

  // Periodic session check
  const setupSessionChecker = () => {
    const interval = setInterval(() => {
      checkSessionTimeout();
    }, 60000); // Check every minute

    return () => clearInterval(interval);
  };


  useEffect(() => {
    // Check if user is logged in on app start
    console.log(' AuthContext - Checking initial auth state');
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (token && userData) {
      // Check if session is still valid
      if (checkSessionTimeout()) {
        return; // Session expired, will redirect
      }
      
      console.log(' AuthContext - Restoring user session');
      setUser(JSON.parse(userData));
      setAuthenticated(true);
      
      // Initialize activity tracking
      updateLastActivity();
      
      // Set up session management
      const cleanupBeforeUnload = setupBeforeUnload();
      const cleanupActivityTracking = setupActivityTracking();
      const cleanupSessionChecker = setupSessionChecker();
      
      return () => {
        cleanupBeforeUnload();
        cleanupActivityTracking();
        cleanupSessionChecker();
      };
    } else {
      console.log(' AuthContext - No existing session found');
      setLoading(false);
    }
  }, []);

 const login = async (email, password) => {
    try {
      setLoading(true);
      console.log(' AuthContext - Attempting login with:', email);
      
      const response = await authAPI.login(email, password);
      
      let responseData;
      if (response.data) {
        responseData = response.data;
      } else {
        responseData = response;
      }
      
      if (!responseData) {
        console.error(' AuthContext - No data in response:', response);
        throw new Error('Invalid response from server');
      }
      
      const { accessToken, refreshToken, user: userData } = responseData;
      
      if (!accessToken) {
        console.error(' AuthContext - No access token in response');
        throw new Error('No access token received from server');
      }
      
      console.log(' AuthContext - Tokens received');
      
      // Store tokens and session data
      localStorage.setItem('token', accessToken);
      if (refreshToken) {
        localStorage.setItem('refreshToken', refreshToken);
      }
      localStorage.setItem('user', JSON.stringify(userData));
      localStorage.setItem('loginTime', Date.now().toString());
      localStorage.setItem('lastActivity', Date.now().toString());
      
      // Set up session management
      setupBeforeUnload();
      setupActivityTracking();
      setupSessionChecker();
      
      // Update state
      setUser(userData);
      setAuthenticated(true);
      
      console.log(' AuthContext - Login successful, user:', userData.email);
      
      return { 
        success: true, 
        data: responseData,
        message: 'Login successful' 
      };
    } catch (error) {
      console.error(' AuthContext - Login error:', error);
      return { 
        success: false, 
        error: error.response?.data?.message || error.message || 'Login failed' 
      };
    } finally {
      setLoading(false);
    }
  };


  const register = async (name, email, password) => {
    try {
      setLoading(true);
      console.log(' AuthContext - Attempting registration with:', { name, email, password: '***' });
      
      const response = await authAPI.register(name, email, password);
      
      console.log(' AuthContext - Registration response:', response); 
      
      return { 
        success: true, 
        data: response,
        message: 'Registration successful' 
      };
    } catch (error) {
      console.error(' AuthContext - Registration error:', error); 
      
      let errorMessage = 'Registration failed';
      if (error.response?.data?.errors) {
        errorMessage = error.response.data.errors.map(err => err.msg).join(', ');
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      }
      
      return { 
        success: false, 
        error: errorMessage
      };
    } finally {
      setLoading(false);
    }
  };


  const value = {
    user,
    login,
    register,
    logout,
    loading,
    isAuthenticated: authenticated,
    updateLastActivity, 
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};