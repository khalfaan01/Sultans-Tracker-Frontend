import { createContext, useContext, useState, useEffect } from 'react';
import { transactionsAPI, accountsAPI, budgetsAPI, goalsAPI } from '../services/api';
import { useAuth } from './AuthContext';
import { useSocket } from './SocketContext';

const TransactionsContext = createContext();

export const useTransactions = () => {
  const context = useContext(TransactionsContext);
  if (!context) {
    throw new Error('useTransactions must be used within a TransactionsProvider');
  }
  return context;
};

export const TransactionsProvider = ({ children }) => {
  const [transactions, setTransactions] = useState([]);
  const [accounts, setAccounts] = useState([{ id: 1, name: "Main Account", balance: 0 }]);
  const [budgets, setBudgets] = useState([]);
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { socket, isConnected } = useSocket();
  
  const { isAuthenticated } = useAuth();

  //  Default transaction state
  const defaultTransaction = {
    amount: '',
    type: 'expense',
    category: 'Food',
    date: new Date().toISOString().split('T')[0], // Today's date
    description: ''
  };

  //  Load only transactions function
  const loadTransactions = async () => {
    if (!isAuthenticated) return;
    
    try {
      const transactionsData = await transactionsAPI.getAll();
      setTransactions(transactionsData);
    } catch (err) {
      console.error('Error loading transactions:', err);
    }
  };

  // Load transactions and accounts ONLY when authenticated
  const loadData = async () => {
    if (!isAuthenticated) {
      console.log(' Not authenticated, skipping data load');
      return;
    }
    
    setLoading(true);
    setError('');
    try {
      console.log(' Loading all data...');
      
      // Load all data in parallel
      const [transactionsData, accountsData, budgetsData, goalsData] = await Promise.all([
        transactionsAPI.getAll(),
        accountsAPI.getAll(),
        budgetsAPI.getAll(),
        goalsAPI.getAll()
      ]);
      
      setTransactions(transactionsData);
      setAccounts(accountsData);
      setBudgets(budgetsData);
      setGoals(goalsData);
      
      console.log(' Data loaded:', {
        transactions: transactionsData.length,
        accounts: accountsData.length,
        budgets: budgetsData.length,
        goals: goalsData.length
      });
      
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to load data';
      setError(errorMsg);
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [isAuthenticated]);

  // Add new transaction
  const addTransaction = async (transactionData) => {
    try {
      setLoading(true);
      
      // Send to real-time monitoring if connected
      if (isConnected && socket) {
        socket.emit('monitor_transaction', {
          ...transactionData,
          timestamp: new Date(),
          ip: 'current-user-ip' // You can get this from the user's context
        });
      }

      const response = await transactionsAPI.create(transactionData);
      
      if (response.warning) {
        // Show fraud warning
        console.log(' Fraud warning:', response.warning);
      }
      
      await loadTransactions();
      return { success: true, warning: response.warning };
    } catch (error) {
      console.error('Add transaction error:', error);
      return { 
        success: false, 
        error: error.response?.data?.error || 'Failed to add transaction' 
      };
    } finally {
      setLoading(false);
    }
  };


  // Update transaction
  const updateTransaction = async (id, transactionData) => {
    setLoading(true);
    setError('');
    try {
      const updatedTransaction = await transactionsAPI.update(id, transactionData);
      setTransactions(prev => 
        prev.map(tx => tx.id === id ? updatedTransaction : tx)
      );
      return { success: true, data: updatedTransaction };
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to update transaction';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  // Delete transaction
  const deleteTransaction = async (id) => {
    setLoading(true);
    setError('');
    try {
      await transactionsAPI.delete(id);
      setTransactions(prev => prev.filter(tx => tx.id !== id));
      return { success: true };
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to delete transaction';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  // Add new account
  const addAccount = async (accountData) => {
    setLoading(true);
    setError('');
    try {
      const newAccount = await accountsAPI.create(accountData);
      setAccounts(prev => [...prev, newAccount]);
      return { success: true, data: newAccount };
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to create account';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

   const updateAccount = async (id, accountData) => {
    setLoading(true);
    setError('');
    try {
      const updatedAccount = await accountsAPI.update(id, accountData);
      setAccounts(prev => prev.map(acc => acc.id === id ? updatedAccount : acc));
      return { success: true, data: updatedAccount };
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to update account';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };


  // Add new budget
  const addBudget = async (budgetData) => {
    setLoading(true);
    setError('');
    try {
      const newBudget = await budgetsAPI.create(budgetData);
      setBudgets(prev => [newBudget, ...prev]);
      return { success: true, data: newBudget };
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to create budget';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  // Update budget
  const updateBudget = async (id, budgetData) => {
    setLoading(true);
    setError('');
    try {
      const updatedBudget = await budgetsAPI.update(id, budgetData);
      setBudgets(prev => prev.map(budget => budget.id === id ? updatedBudget : budget));
      return { success: true, data: updatedBudget };
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to update budget';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  // Delete budget
  const deleteBudget = async (id) => {
    setLoading(true);
    setError('');
    try {
      await budgetsAPI.delete(id);
      setBudgets(prev => prev.filter(budget => budget.id !== id));
      return { success: true };
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to delete budget';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  // Add new goal
  const addGoal = async (goalData) => {
    setLoading(true);
    setError('');
    try {
      const newGoal = await goalsAPI.create(goalData);
      setGoals(prev => [newGoal, ...prev]);
      return { success: true, data: newGoal };
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to create goal';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  // Update goal
  const updateGoal = async (id, goalData) => {
    setLoading(true);
    setError('');
    
try {
    // Only send changed fields to avoid 403 errors
    const updatePayload = {
      isActive: goalData.isActive
      // Add other fields only if they're provided and different
    };
    
    const updatedGoal = await goalsAPI.update(id, updatePayload);
    setGoals(prev => prev.map(goal => goal.id === id ? updatedGoal : goal));
    return { success: true, data: updatedGoal };
  } catch (err) {
    const errorMsg = err.response?.data?.error || err.response?.data?.message || 'Failed to update goal';
    setError(errorMsg);
    return { success: false, error: errorMsg };
  } finally {
    setLoading(false);
  }
};

  // Delete goal
  const deleteGoal = async (id) => {
    setLoading(true);
    setError('');
    try {
      await goalsAPI.delete(id);
      setGoals(prev => prev.filter(goal => goal.id !== id));
      return { success: true };
    } catch (err) {
      const errorMsg = err.response?.data?.message || 'Failed to delete goal';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  // Calculate dashboard statistics
  const getDashboardStats = () => {
    const income = transactions
      .filter(tx => tx.type === 'income')
      .reduce((sum, tx) => sum + tx.amount, 0);
    
    const expenses = transactions
      .filter(tx => tx.type === 'expense')
      .reduce((sum, tx) => sum + Math.abs(tx.amount), 0);
    
    const balance = income - expenses;
    
    // Category breakdown
    const categoryBreakdown = transactions.reduce((acc, tx) => {
      if (tx.type === 'expense') {
        const amount = Math.abs(tx.amount);
        acc[tx.category] = (acc[tx.category] || 0) + amount;
      }
      return acc;
    }, {});

    // Monthly trends
    const monthlyData = transactions.reduce((acc, tx) => {
      const month = new Date(tx.date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      if (!acc[month]) {
        acc[month] = { income: 0, expenses: 0 };
      }
      if (tx.type === 'income') {
        acc[month].income += tx.amount;
      } else {
        acc[month].expenses += Math.abs(tx.amount);
      }
      return acc;
    }, {});

    // Budget progress
    const budgetProgress = budgets.map(budget => {
      const spent = transactions
        .filter(tx => tx.type === 'expense' && tx.category === budget.category)
        .reduce((sum, tx) => sum + Math.abs(tx.amount), 0);
      
      return {
        ...budget,
        spent,
        percentage: (spent / budget.limit) * 100
      };
    });

    // Goal progress
    const goalProgress = goals.map(goal => {
      const percentage = (goal.currentAmount / goal.targetAmount) * 100;
      const daysLeft = Math.ceil((new Date(goal.deadline) - new Date()) / (1000 * 60 * 60 * 24));
      
      return {
        ...goal,
        percentage,
        daysLeft,
        isCompleted: percentage >= 100
      };
    });

    return {
      balance,
      income,
      expenses,
      categoryBreakdown,
      monthlyData: Object.entries(monthlyData).map(([month, data]) => ({
        month,
        ...data
      })),
      budgetProgress,
      goalProgress
    };
  };
    // Budget functions
const calculateBudgetRollover = async (id) => {
  setLoading(true);
  setError('');
  try {
    const result = await budgetsAPI.calculateRollover(id);
    return { success: true, data: result };
  } catch (err) {
    const errorMsg = err.response?.data?.message || 'Failed to calculate rollover';
    setError(errorMsg);
    return { success: false, error: errorMsg };
  } finally {
    setLoading(false);
  }
};

// Goal functions
const contributeToGoal = async (id, contributionData) => {
  setLoading(true);
  setError('');
  try {
    const result = await goalsAPI.contribute(id, contributionData);
    
    // Update goals state with new amount
    setGoals(prev => prev.map(goal => 
      goal.id === id ? { ...goal, currentAmount: result.goal.currentAmount, isCompleted: result.goal.isCompleted } : goal
    ));
    
    // Reload transactions to include the new contribution transaction
    const transactionsData = await transactionsAPI.getAll();
    setTransactions(transactionsData);
    
    return { success: true, data: result };
  } catch (err) {
    const errorMsg = err.response?.data?.message || 'Failed to contribute to goal';
    setError(errorMsg);
    return { success: false, error: errorMsg };
  } finally {
    setLoading(false);
  }
};

const autoAllocateIncome = async (allocationData) => {
  setLoading(true);
  setError('');
  try {
    const result = await goalsAPI.autoAllocate(allocationData);
    
    // Reload goals and transactions to reflect allocations
    const [goalsData, transactionsData] = await Promise.all([
      goalsAPI.getAll(),
      transactionsAPI.getAll()
    ]);
    
    setGoals(goalsData);
    setTransactions(transactionsData);
    
    return { success: true, data: result };
  } catch (err) {
    const errorMsg = err.response?.data?.message || 'Failed to auto-allocate income';
    setError(errorMsg);
    return { success: false, error: errorMsg };
  } finally {
    setLoading(false);
  }
  };

  const value = {
    // Data
    transactions,
    accounts,
    budgets,
    goals,
    loading,
    error,
    defaultTransaction,
    
    // Transaction functions
    addTransaction,
    updateTransaction,
    deleteTransaction,
    
    // Account functions
    addAccount,
    updateAccount,
    
    // Budget functions
    addBudget,
    updateBudget,
    deleteBudget,
    calculateBudgetRollover,
    
    // Goal functions
    addGoal,
    updateGoal,
    deleteGoal,
    contributeToGoal, 
    autoAllocateIncome, 
    
    // Utility functions
    reloadData: loadData,
    getDashboardStats,
    loadTransactions
  };

  return (
    <TransactionsContext.Provider value={value}>
      {children}
    </TransactionsContext.Provider>
  );
};