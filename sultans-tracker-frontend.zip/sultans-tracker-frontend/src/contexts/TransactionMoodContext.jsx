import { createContext, useContext, useState, useEffect } from 'react';
import { transactionMoodsAPI } from '../services/api';
import { useAuth } from './AuthContext';

const TransactionMoodContext = createContext();

export const useTransactionMood = () => {
  const context = useContext(TransactionMoodContext);
  if (!context) {
    throw new Error('useTransactionMood must be used within a TransactionMoodProvider');
  }
  return context;
};

export const TransactionMoodProvider = ({ children }) => {
  const [moods, setMoods] = useState([]);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { isAuthenticated } = useAuth();

  // Load mood analysis data
  const loadMoodAnalysis = async () => {
    if (!isAuthenticated) return;
    
    setLoading(true);
    setError('');
    try {
      const data = await transactionMoodsAPI.getMoodAnalysis();
      setMoods(data.moods || []);
      setAnalysis(data.analysis || null);
    } catch (err) {
      console.error('Error loading mood analysis:', err);
      setError(err.response?.data?.error || 'Failed to load mood analysis');
    } finally {
      setLoading(false);
    }
  };

  // Add mood to transaction
  const addTransactionMood = async (transactionId, moodData) => {
    setLoading(true);
    setError('');
    try {
      const mood = await transactionMoodsAPI.addMood({
        transactionId,
        ...moodData
      });
      
      // Update local state
      setMoods(prev => {
        const filtered = prev.filter(m => m.transactionId !== transactionId);
        return [...filtered, mood];
      });
      
      // Reload analysis to get updated stats
      await loadMoodAnalysis();
      
      return { success: true, data: mood };
    } catch (err) {
      const errorMsg = err.response?.data?.error || 'Failed to add mood';
      setError(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  // Get mood for specific transaction
  const getTransactionMood = async (transactionId) => {
    try {
      const mood = await transactionMoodsAPI.getMoodByTransaction(transactionId);
      return mood;
    } catch (err) {
      console.error('Error getting transaction mood:', err);
      return null;
    }
  };

  // Get spending insights based on moods
  const getMoodInsights = () => {
    if (!analysis) return null;

    const insights = [];
    
    // Find highest spending mood
    const moodSpending = Object.entries(analysis.averageSpendingByMood || {});
    if (moodSpending.length > 0) {
      const highestSpendingMood = moodSpending.reduce((max, [mood, data]) => {
        return data.average > max.average ? { mood, ...data } : max;
      }, { mood: '', average: 0 });
      
      if (highestSpendingMood.mood) {
        insights.push({
          type: 'high_spending',
          mood: highestSpendingMood.mood,
          amount: highestSpendingMood.average,
          message: `You spend the most when feeling ${highestSpendingMood.mood} ($${highestSpendingMood.average.toFixed(2)} on average)`
        });
      }
    }

    // Find most common mood
    const moodDistribution = Object.entries(analysis.moodDistribution || {});
    if (moodDistribution.length > 0) {
      const mostCommonMood = moodDistribution.reduce((max, [mood, count]) => {
        return count > max.count ? { mood, count } : max;
      }, { mood: '', count: 0 });
      
      if (mostCommonMood.mood) {
        insights.push({
          type: 'common_mood',
          mood: mostCommonMood.mood,
          count: mostCommonMood.count,
          message: `You most often feel ${mostCommonMood.mood} when spending (${mostCommonMood.count} times)`
        });
      }
    }

    return insights;
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadMoodAnalysis();
    }
  }, [isAuthenticated]);

  const value = {
    moods,
    analysis,
    loading,
    error,
    addTransactionMood,
    getTransactionMood,
    getMoodInsights,
    reloadMoodAnalysis: loadMoodAnalysis
  };

  return (
    <TransactionMoodContext.Provider value={value}>
      {children}
    </TransactionMoodContext.Provider>
  );
};