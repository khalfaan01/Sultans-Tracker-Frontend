import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { TransactionsProvider } from './contexts/TransactionsContext';
import { TransactionMoodProvider } from './contexts/TransactionMoodContext'; 
import { SocketProvider } from './contexts/SocketContext';
import { DebtProvider } from './contexts/DebtContext';


import MagneticCursor from './components/ui/MagneticCursor'; 
import LandingPage from './pages/LandingPage';
import Login from './pages/Login';
import Register from './pages/Register';
import DashboardLayout from './components/dashboard/DashboardLayout';
import './styles/globals.css';

function App() {
  return (
    <AuthProvider>
      <SocketProvider> 
        <TransactionsProvider>
          <TransactionMoodProvider> 
            {/* WRAP WITH DEBT AND SETTINGS PROVIDERS: */}
            <DebtProvider>
              
                <Router>
                  {/* Add MagneticCursor here to cover all routes */}
                  <MagneticCursor />
                  <Routes>
                    <Route path="/" element={<LandingPage />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/dashboard/*" element={<DashboardLayout />} />
                  </Routes>
                </Router>
              
            </DebtProvider>
          </TransactionMoodProvider> 
        </TransactionsProvider>
      </SocketProvider>
    </AuthProvider>
  );
}

export default App;