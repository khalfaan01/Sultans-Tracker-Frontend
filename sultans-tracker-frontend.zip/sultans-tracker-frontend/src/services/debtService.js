// src/services/debtService.js
import axios from 'axios';

// Debug: Check what we're importing
console.log('🔐 DEBT SERVICE - Starting import...');

// Try to import the api instance
let api;
try {
  api = await import('./api.js');
  console.log('🔐 DEBT SERVICE - api.js import result:', api);
  console.log('🔐 DEBT SERVICE - api.default export:', api.default);
  console.log('🔐 DEBT SERVICE - api.named exports:', Object.keys(api));
} catch (importError) {
  console.error('🔐 DEBT SERVICE - Failed to import api.js:', importError);
}

// Create a backup API instance with manual token handling
const createApiRequest = (method, url, data = null) => {
  const token = localStorage.getItem('token');
  console.log('🔐 MANUAL API REQUEST - Debug:');
  console.log('  - Method:', method);
  console.log('  - URL:', url);
  console.log('  - Token exists:', !!token);
  console.log('  - Token value (first 20 chars):', token ? token.substring(0, 20) + '...' : 'MISSING');
  
  const config = {
    method,
    url: `http://localhost:5000/api${url}`,
    headers: {
      'Content-Type': 'application/json',
    }
  };
  
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
    console.log('  - Authorization header added');
  } else {
    console.warn('  - WARNING: No token found in localStorage');
  }
  
  if (data) {
    config.data = data;
  }
  
  console.log('  - Final request config:', config);
  return axios(config);
};

export const debtAPI = {
  // Get all debts
  getAll: async () => {
    console.log('🔐 debtAPI.getAll - Starting request...');
    console.log('🔐 debtAPI.getAll - localStorage token:', localStorage.getItem('token'));
    
    try {
      // Try using the imported api first
      if (api && api.default) {
        console.log('🔐 debtAPI.getAll - Using imported api instance');
        const response = await api.default.get('/debts');
        console.log('🔐 debtAPI.getAll - Success with imported api');
        return response.data;
      } else {
        console.log('🔐 debtAPI.getAll - Using manual API request');
        const response = await createApiRequest('get', '/debts');
        console.log('🔐 debtAPI.getAll - Success with manual request');
        return response.data;
      }
    } catch (error) {
      console.error('🔐 debtAPI.getAll - ERROR DETAILS:');
      console.error('  - Error message:', error.message);
      console.error('  - Error response status:', error.response?.status);
      console.error('  - Error response data:', error.response?.data);
      console.error('  - Error config:', error.config);
      throw error;
    }
  },

  // Get debt by ID
  getById: async (id) => {
    console.log('🔐 debtAPI.getById - Requesting debt:', id);
    try {
      if (api && api.default) {
        const response = await api.default.get(`/debts/${id}`);
        return response.data;
      } else {
        const response = await createApiRequest('get', `/debts/${id}`);
        return response.data;
      }
    } catch (error) {
      console.error('🔐 debtAPI.getById - Error:', error);
      throw error;
    }
  },

  // Create new debt
  create: async (debtData) => {
    console.log('🔐 debtAPI.create - Creating debt:', debtData);
    try {
      if (api && api.default) {
        const response = await api.default.post('/debts', debtData);
        return response.data;
      } else {
        const response = await createApiRequest('post', '/debts', debtData);
        return response.data;
      }
    } catch (error) {
      console.error('🔐 debtAPI.create - Error:', error);
      throw error;
    }
  },

  // Update debt
  update: async (id, debtData) => {
    console.log('🔐 debtAPI.update - Updating debt:', id, debtData);
    try {
      if (api && api.default) {
        const response = await api.default.put(`/debts/${id}`, debtData);
        return response.data;
      } else {
        const response = await createApiRequest('put', `/debts/${id}`, debtData);
        return response.data;
      }
    } catch (error) {
      console.error('🔐 debtAPI.update - Error:', error);
      throw error;
    }
  },

  // Delete debt
  delete: async (id) => {
    console.log('🔐 debtAPI.delete - Deleting debt:', id);
    try {
      if (api && api.default) {
        const response = await api.default.delete(`/debts/${id}`);
        return response.data;
      } else {
        const response = await createApiRequest('delete', `/debts/${id}`);
        return response.data;
      }
    } catch (error) {
      console.error('🔐 debtAPI.delete - Error:', error);
      throw error;
    }
  },

  // Make payment
  makePayment: async (id, paymentData) => {
    console.log('🔐 debtAPI.makePayment - Making payment on debt:', id, paymentData);
    try {
      if (api && api.default) {
        const response = await api.default.post(`/debts/${id}/payment`, paymentData);
        return response.data;
      } else {
        const response = await createApiRequest('post', `/debts/${id}/payment`, paymentData);
        return response.data;
      }
    } catch (error) {
      console.error('🔐 debtAPI.makePayment - Error:', error);
      throw error;
    }
  },

  // Get debt analytics
  getAnalytics: async () => {
    console.log('🔐 debtAPI.getAnalytics - Requesting debt analytics');
    try {
      if (api && api.default) {
        const response = await api.default.get('/debts/analytics/summary');
        return response.data;
      } else {
        const response = await createApiRequest('get', '/debts/analytics/summary');
        return response.data;
      }
    } catch (error) {
      console.error('🔐 debtAPI.getAnalytics - Error:', error);
      throw error;
    }
  }
};

// Additional debug: Test API instance after initialization
console.log('🔐 DEBT SERVICE - Final check:');
console.log('  - debtAPI object:', debtAPI);
console.log('  - localStorage token:', localStorage.getItem('token'));
console.log('  - API instance available:', !!api);

// Test function to manually check token
export const testToken = () => {
  const token = localStorage.getItem('token');
  console.log('🔐 TOKEN TEST:');
  console.log('  - Token exists:', !!token);
  console.log('  - Token length:', token ? token.length : 0);
  console.log('  - Token preview:', token ? token.substring(0, 50) + '...' : 'NONE');
  return token;
};