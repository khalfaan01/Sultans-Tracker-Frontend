import api from './api';

export const securityAPI = {
  getSecurityOverview: async () => {
    const response = await api.get('/security/overview');
    return response.data;
  },

  getLoginAttempts: async (days = 30) => {
    const response = await api.get(`/security/login-attempts?days=${days}`);
    return response.data;
  },

  getSuspiciousTransactions: async () => {
    const response = await api.get('/security/suspicious-transactions');
    return response.data;
  },

  updateAlertPreferences: async (preferences) => {
    const response = await api.post('/security/alert-preferences', preferences);
    return response.data;
  },

  getSecurityLogs: async () => {
    const response = await api.get('/security/logs');
    return response.data;
  },

  // Real-time security events
  subscribeToAlerts: (callback) => {
    // This will be implemented with Socket.IO
    console.log('Subscribing to security alerts...');
  }
};

export default securityAPI;