import { api } from './api';

class TransactionMoodService {
  // Analyze mood based on transaction data
  analyzeTransactionMood(transaction, context = {}) {
    const amount = Math.abs(transaction.amount);
    const isIncome = transaction.amount > 0;
    const category = transaction.category || 'Other';
    
    let moodScore = 50; // Neutral baseline
    let mood = 'neutral';
    let factors = [];

    // Amount-based analysis
    if (isIncome) {
      if (amount > 1000) {
        moodScore += 25;
        factors.push('large income');
      } else if (amount > 100) {
        moodScore += 10;
        factors.push('moderate income');
      }
    } else {
      // Expense analysis
      if (amount > 500) {
        moodScore -= 30;
        factors.push('large expense');
      } else if (amount > 100) {
        moodScore -= 15;
        factors.push('moderate expense');
      } else if (amount < 20) {
        moodScore += 5;
        factors.push('small expense');
      }

      // Category-based analysis
      const categoryImpact = this.getCategoryMoodImpact(category);
      moodScore += categoryImpact.score;
      if (categoryImpact.factor) {
        factors.push(categoryImpact.factor);
      }
    }

    // Context analysis (budget, trends, etc.)
    if (context.budgetStatus === 'under_budget') {
      moodScore += 10;
      factors.push('under budget');
    } else if (context.budgetStatus === 'over_budget') {
      moodScore -= 15;
      factors.push('over budget');
    }

    if (context.savingsTrend === 'increasing') {
      moodScore += 8;
      factors.push('savings increasing');
    } else if (context.savingsTrend === 'decreasing') {
      moodScore -= 12;
      factors.push('savings decreasing');
    }

    // Clamp score between 0-100
    moodScore = Math.max(0, Math.min(100, moodScore));

    // Determine mood category
    if (moodScore >= 80) mood = 'excellent';
    else if (moodScore >= 65) mood = 'good';
    else if (moodScore >= 45) mood = 'neutral';
    else if (moodScore >= 30) mood = 'poor';
    else mood = 'terrible';

    return {
      score: Math.round(moodScore),
      mood,
      factors,
      emoji: this.getMoodEmoji(mood),
      color: this.getMoodColor(mood),
      timestamp: new Date().toISOString()
    };
  }

  // Get mood impact based on category
  getCategoryMoodImpact(category) {
    const impacts = {
      'Dining': { score: -5, factor: 'dining out' },
      'Entertainment': { score: -3, factor: 'entertainment' },
      'Shopping': { score: -8, factor: 'shopping' },
      'Utilities': { score: -2, factor: 'bills' },
      'Healthcare': { score: -10, factor: 'healthcare' },
      'Education': { score: 5, factor: 'education investment' },
      'Savings': { score: 15, factor: 'savings' },
      'Investment': { score: 12, factor: 'investment' },
      'Groceries': { score: 0, factor: 'essential groceries' },
      'Transportation': { score: -2, factor: 'transportation' }
    };

    return impacts[category] || { score: 0, factor: null };
  }

  // Get emoji for mood
  getMoodEmoji(mood) {
    const emojis = {
      'excellent': '😊',
      'good': '🙂',
      'neutral': '😐',
      'poor': '😕',
      'terrible': '😞'
    };
    return emojis[mood] || '😐';
  }

  // Get color for mood
  getMoodColor(mood) {
    const colors = {
      'excellent': '#10B981', // Green
      'good': '#34D399',      // Light Green
      'neutral': '#6B7280',   // Gray
      'poor': '#F59E0B',      // Yellow
      'terrible': '#EF4444'   // Red
    };
    return colors[mood] || '#6B7280';
  }

  // Analyze overall financial mood for a period
  analyzeOverallMood(transactions, period = 'month') {
    if (!transactions || transactions.length === 0) {
      return this.getDefaultMood();
    }

    const recentTransactions = this.filterByPeriod(transactions, period);
    const moods = recentTransactions.map(transaction => 
      this.analyzeTransactionMood(transaction)
    );

    const averageScore = moods.reduce((sum, mood) => sum + mood.score, 0) / moods.length;
    const allFactors = [...new Set(moods.flatMap(mood => mood.factors))];

    // Determine overall mood
    let overallMood = 'neutral';
    if (averageScore >= 75) overallMood = 'excellent';
    else if (averageScore >= 60) overallMood = 'good';
    else if (averageScore >= 40) overallMood = 'neutral';
    else if (averageScore >= 25) overallMood = 'poor';
    else overallMood = 'terrible';

    return {
      score: Math.round(averageScore),
      mood: overallMood,
      factors: allFactors.slice(0, 5), // Top 5 factors
      emoji: this.getMoodEmoji(overallMood),
      color: this.getMoodColor(overallMood),
      transactionCount: recentTransactions.length,
      analyzedPeriod: period,
      timestamp: new Date().toISOString()
    };
  }

  // Filter transactions by time period
  filterByPeriod(transactions, period) {
    const now = new Date();
    let startDate;

    switch (period) {
      case 'week':
        startDate = new Date(now.setDate(now.getDate() - 7));
        break;
      case 'month':
        startDate = new Date(now.setMonth(now.getMonth() - 1));
        break;
      case 'quarter':
        startDate = new Date(now.setMonth(now.getMonth() - 3));
        break;
      default:
        startDate = new Date(now.setMonth(now.getMonth() - 1));
    }

    return transactions.filter(transaction => 
      new Date(transaction.date) >= startDate
    );
  }

  // Get default mood for no data
  getDefaultMood() {
    return {
      score: 50,
      mood: 'neutral',
      factors: ['no transaction data'],
      emoji: '😐',
      color: '#6B7280',
      transactionCount: 0,
      analyzedPeriod: 'month',
      timestamp: new Date().toISOString()
    };
  }

  // Track mood trends over time
  analyzeMoodTrends(transactions, periods = ['week', 'month', 'quarter']) {
    return periods.map(period => ({
      period,
      mood: this.analyzeOverallMood(transactions, period)
    }));
  }

  // Get mood improvement suggestions
  getMoodImprovementSuggestions(moodAnalysis) {
    const suggestions = [];

    if (moodAnalysis.score < 40) {
      suggestions.push(
        'Consider reviewing your recent large expenses',
        'Look for subscription services you can cancel',
        'Set up a weekly spending limit'
      );
    }

    if (moodAnalysis.factors.includes('dining out')) {
      suggestions.push('Try cooking at home more often to save on dining expenses');
    }

    if (moodAnalysis.factors.includes('shopping')) {
      suggestions.push('Implement a 24-hour waiting period before non-essential purchases');
    }

    if (moodAnalysis.score > 70) {
      suggestions.push(
        'Great job! Consider increasing your savings rate',
        'Your financial habits are excellent - keep it up!'
      );
    }

    return suggestions.length > 0 ? suggestions : [
      'Your financial mood is stable. Consider setting new financial goals!'
    ];
  }

  // API methods
  async saveTransactionMood(transactionId, moodData) {
    try {
      const response = await api.post('/transaction-moods', {
        transactionId,
        ...moodData
      });
      return response.data;
    } catch (error) {
      console.error('Error saving transaction mood:', error);
      throw error;
    }
  }

  async getTransactionMoods(period = 'month') {
    try {
      const response = await api.get(`/transaction-moods?period=${period}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching transaction moods:', error);
      throw error;
    }
  }

  async getMoodHistory(days = 30) {
    try {
      const response = await api.get(`/transaction-moods/history?days=${days}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching mood history:', error);
      throw error;
    }
  }
}

export const transactionMoodService = new TransactionMoodService();
export default transactionMoodService;