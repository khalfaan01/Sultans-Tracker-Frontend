export class PatternDetector {
  static detectSpendingPatterns(transactions) {
    const patterns = {
      recurringPayments: this.detectRecurringPayments(transactions),
      seasonalTrends: this.detectSeasonalTrends(transactions),
      behavioralPatterns: this.detectBehavioralPatterns(transactions),
      anomalyDetections: this.detectAnomalies(transactions)
    };
    
    return patterns;
  }

  static detectRecurringPayments(transactions) {
    const recurring = [];
    const expenseTransactions = transactions.filter(tx => tx.type === 'expense');
    
    // Group by description and amount
    const paymentGroups = {};
    expenseTransactions.forEach(tx => {
      const key = `${tx.description}-${Math.abs(tx.amount)}`;
      if (!paymentGroups[key]) {
        paymentGroups[key] = [];
      }
      paymentGroups[key].push(tx);
    });

    // Find recurring patterns (3+ occurrences with regular intervals)
    Object.entries(paymentGroups).forEach(([key, txs]) => {
      if (txs.length >= 3) {
        const dates = txs.map(tx => new Date(tx.date)).sort((a, b) => a - b);
        const intervals = [];
        
        for (let i = 1; i < dates.length; i++) {
          intervals.push((dates[i] - dates[i-1]) / (1000 * 60 * 60 * 24)); // days between
        }
        
        const avgInterval = intervals.reduce((a, b) => a + b) / intervals.length;
        const isRegular = intervals.every(interval => 
          Math.abs(interval - avgInterval) <= 7 // within 7 days variance
        );

        if (isRegular) {
          recurring.push({
            description: txs[0].description,
            amount: Math.abs(txs[0].amount),
            frequency: avgInterval <= 35 ? 'monthly' : 'yearly',
            occurrences: txs.length,
            nextExpected: new Date(dates[dates.length - 1].getTime() + avgInterval * 24 * 60 * 60 * 1000)
          });
        }
      }
    });

    return recurring;
  }

  static detectSeasonalTrends(transactions) {
    const monthlySpending = {};
    const currentYear = new Date().getFullYear();
    
    transactions
      .filter(tx => tx.type === 'expense' && new Date(tx.date).getFullYear() === currentYear)
      .forEach(tx => {
        const month = new Date(tx.date).getMonth();
        monthlySpending[month] = (monthlySpending[month] || 0) + Math.abs(tx.amount);
      });

    return monthlySpending;
  }

  static detectBehavioralPatterns(transactions) {
    const patterns = {
      weekendSpending: 0,
      weekdaySpending: 0,
      morningSpending: 0,
      eveningSpending: 0
    };

    transactions.forEach(tx => {
      const date = new Date(tx.date);
      const dayOfWeek = date.getDay();
      const hour = date.getHours();
      const amount = Math.abs(tx.amount);

      if (dayOfWeek === 0 || dayOfWeek === 6) {
        patterns.weekendSpending += amount;
      } else {
        patterns.weekdaySpending += amount;
      }

      if (hour >= 18 || hour < 6) {
        patterns.eveningSpending += amount;
      } else {
        patterns.morningSpending += amount;
      }
    });

    return patterns;
  }

  static detectAnomalies(transactions) {
    const anomalies = [];
    const expenseTransactions = transactions.filter(tx => tx.type === 'expense');
    
    if (expenseTransactions.length === 0) return anomalies;

    // Calculate average and standard deviation
    const amounts = expenseTransactions.map(tx => Math.abs(tx.amount));
    const average = amounts.reduce((a, b) => a + b) / amounts.length;
    const stdDev = Math.sqrt(
      amounts.map(x => Math.pow(x - average, 2)).reduce((a, b) => a + b) / amounts.length
    );

    // Find anomalies (3 standard deviations from mean)
    expenseTransactions.forEach(tx => {
      const amount = Math.abs(tx.amount);
      if (amount > average + (3 * stdDev)) {
        anomalies.push({
          transaction: tx,
          deviation: ((amount - average) / stdDev).toFixed(2),
          riskLevel: amount > average + (5 * stdDev) ? 'high' : 'medium'
        });
      }
    });

    return anomalies;
  }
}