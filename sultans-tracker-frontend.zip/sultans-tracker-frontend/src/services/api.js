// src/services/api.js (UPDATED - Enhanced debug logging)
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Token refresh variables
let isRefreshing = false;
let failedQueue = [];

const processQueue = (error, token = null) => {
  failedQueue.forEach(prom => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(token);
    }
  });
  failedQueue = [];
};

// Add auth token to requests WITH AUTO-REFRESH
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Handle token expiration and auto-refresh
api.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;

    // If error is 403 and token expired, try to refresh
    if (error.response?.status === 403 && 
        error.response?.data?.error === 'Token expired' && 
        !originalRequest._retry) {
      
      if (isRefreshing) {
        // If already refreshing, add to queue
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then(token => {
          originalRequest.headers.Authorization = `Bearer ${token}`;
          return api(originalRequest);
        }).catch(err => {
          return Promise.reject(err);
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const refreshToken = localStorage.getItem('refreshToken');
        if (!refreshToken) {
          throw new Error('No refresh token available');
        }

        // Call refresh token endpoint
        const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
          refreshToken
        });

        const newAccessToken = response.data.accessToken;
        
        // Store new token
        localStorage.setItem('token', newAccessToken);
        
        // Update authorization header
        api.defaults.headers.common['Authorization'] = `Bearer ${newAccessToken}`;
        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
        
        // Process queued requests
        processQueue(null, newAccessToken);
        
        // Retry original request
        return api(originalRequest);
        
      } catch (refreshError) {
        console.error('Token refresh failed:', refreshError);
        
        // Clear tokens and redirect to login
        localStorage.removeItem('token');
        localStorage.removeItem('refreshToken');
        localStorage.removeItem('user');
        
        // Redirect to login page
        if (window.location.pathname !== '/login') {
          window.location.href = '/login';
        }
        
        processQueue(refreshError, null);
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    // For other errors, just reject
    return Promise.reject(error);
  }
);

export const authAPI = {
  login: async (email, password) => {
    console.log(' authAPI.login - Sending request:', { email, password: '***' });
    const response = await api.post('/auth/login', { email, password });
    console.log(' authAPI.login - Full response:', response); // ADD THIS
    console.log(' authAPI.login - Response data:', response.data); // ADD THIS
    return response.data; // This should return the actual data
  },

  register: async (name, email, password) => {
    console.log(' authAPI.register - Sending request:', { name, email, password: '***' });
    const response = await api.post('/auth/register', { name, email, password });
    console.log(' authAPI.register - Full response:', response); 
    console.log(' authAPI.register - Response data:', response.data); 
    return response.data; 
  },
};

// Transactions API functions
export const transactionsAPI = {
  getAll: async () => {
    console.log(' transactionsAPI.getAll - Requesting transactions'); // ADD THIS
    const response = await api.get('/transactions');
    console.log(' transactionsAPI.getAll - Received:', response.data.length, 'transactions'); // ADD THIS
    return response.data;
  },

  create: async (transactionData) => {
    console.log(' transactionsAPI.create - Creating transaction:', transactionData); // ADD THIS
    const response = await api.post('/transactions', transactionData);
    console.log(' transactionsAPI.create - Created:', response.data); // ADD THIS
    return response.data;
  },

  update: async (id, transactionData) => {
    console.log(' transactionsAPI.update - Updating transaction:', id, transactionData); // ADD THIS
    const response = await api.put(`/transactions/${id}`, transactionData);
    console.log(' transactionsAPI.update - Updated:', response.data); // ADD THIS
    return response.data;
  },

  delete: async (id) => {
    console.log(' transactionsAPI.delete - Deleting transaction:', id); // ADD THIS
    const response = await api.delete(`/transactions/${id}`);
    console.log(' transactionsAPI.delete - Deleted:', response.data); // ADD THIS
    return response.data;
  },
};

// Accounts API functions
export const accountsAPI = {
  getAll: async () => {
    try {
      console.log(' accountsAPI.getAll - Requesting accounts'); // ADD THIS
      const response = await api.get('/accounts');
      console.log(' accountsAPI.getAll - Received:', response.data.length, 'accounts'); // ADD THIS
      return response.data;
    } catch (error) {
      console.error(' accountsAPI.getAll - Error:', error.response?.status); // ADD THIS
      if (error.response?.status === 404) {
        console.log(' accountsAPI.getAll - Endpoint not available, using default account'); // ADD THIS
        return [{ id: 1, name: "Main Account", balance: 0 }];
      }
      throw error;
    }
  },

  create: async (accountData) => {
    try {
      console.log(' accountsAPI.create - Creating account:', accountData); // ADD THIS
      const response = await api.post('/accounts', accountData);
      console.log(' accountsAPI.create - Created:', response.data); // ADD THIS
      return response.data;
    } catch (error) {
      console.error(' accountsAPI.create - Error:', error.response?.status); // ADD THIS
      if (error.response?.status === 404) {
        console.log(' accountsAPI.create - Endpoint not available'); // ADD THIS
        return { id: 1, ...accountData };
      }
      throw error;
    }
  },
};

// Budgets API functions
export const budgetsAPI = {
  getAll: async () => {
    console.log(' budgetsAPI.getAll - Requesting budgets'); // ADD THIS
    const response = await api.get('/budgets');
    console.log(' budgetsAPI.getAll - Received:', response.data.length, 'budgets'); // ADD THIS
    return response.data;
  },

  create: async (budgetData) => {
    console.log(' budgetsAPI.create - Creating budget:', budgetData); // ADD THIS
    const response = await api.post('/budgets', budgetData);
    console.log(' budgetsAPI.create - Created:', response.data); // ADD THIS
    return response.data;
  },

  update: async (id, budgetData) => {
    console.log(' budgetsAPI.update - Updating budget:', id, budgetData); // ADD THIS
    const response = await api.put(`/budgets/${id}`, budgetData);
    console.log(' budgetsAPI.update - Updated:', response.data); // ADD THIS
    return response.data;
  },

  delete: async (id) => {
    console.log(' budgetsAPI.delete - Deleting budget:', id); // ADD THIS
    const response = await api.delete(`/budgets/${id}`);
    console.log(' budgetsAPI.delete - Deleted:', response.data); // ADD THIS
    return response.data;
  },

  calculateRollover: async (id) => {
    console.log(' budgetsAPI.calculateRollover - Calculating for budget:', id); // ADD THIS
    const response = await api.post(`/budgets/${id}/calculate-rollover`);
    console.log(' budgetsAPI.calculateRollover - Result:', response.data); // ADD THIS
    return response.data;
  },
};

// Goals API functions
export const goalsAPI = {
  getAll: async () => {
    console.log(' goalsAPI.getAll - Requesting goals'); // ADD THIS
    const response = await api.get('/goals');
    console.log(' goalsAPI.getAll - Received:', response.data.length, 'goals'); // ADD THIS
    return response.data;
  },

  create: async (goalData) => {
    console.log(' goalsAPI.create - Creating goal:', goalData); // ADD THIS
    const response = await api.post('/goals', goalData);
    console.log(' goalsAPI.create - Created:', response.data); // ADD THIS
    return response.data;
  },

  update: async (id, goalData) => {
    console.log(' goalsAPI.update - Updating goal:', id, goalData); // ADD THIS
    const response = await api.put(`/goals/${id}`, goalData);
    console.log(' goalsAPI.update - Updated:', response.data); // ADD THIS
    return response.data;
  },

  delete: async (id) => {
    console.log(' goalsAPI.delete - Deleting goal:', id); // ADD THIS
    const response = await api.delete(`/goals/${id}`);
    console.log(' goalsAPI.delete - Deleted:', response.data); // ADD THIS
    return response.data;
  },

  contribute: async (id, contributionData) => {
    console.log(' goalsAPI.contribute - Contributing to goal:', id, contributionData); // ADD THIS
    const response = await api.post(`/goals/${id}/contribute`, contributionData);
    console.log(' goalsAPI.contribute - Result:', response.data); // ADD THIS
    return response.data;
  },

  autoAllocate: async (allocationData) => {
    console.log(' goalsAPI.autoAllocate - Auto-allocating:', allocationData); // ADD THIS
    const response = await api.post('/goals/auto-allocate', allocationData);
    console.log(' goalsAPI.autoAllocate - Result:', response.data); // ADD THIS
    return response.data;
  },
};

// Security API functions
export const securityAPI = {
  getSecurityOverview: async () => {
    const response = await api.get('/security/overview');
    return response.data;
  },

  getLoginAttempts: async (days = 30) => {
    console.log(' securityAPI.getLoginAttempts - Requesting login attempts');
    const response = await api.get(`/security/login-attempts?days=${days}`);
    return response.data;
  },

  getSuspiciousTransactions: async () => {
    console.log(' securityAPI.getSuspiciousTransactions - Requesting suspicious transactions');
    const response = await api.get('/security/suspicious-transactions');
    return response.data;
  },

  updateAlertPreferences: async (preferences) => {
    console.log(' securityAPI.updateAlertPreferences - Updating preferences:', preferences);
    const response = await api.post('/security/alert-preferences', preferences);
    return response.data;
  },

  getSecurityLogs: async () => {
    console.log(' securityAPI.getSecurityLogs - Requesting security logs');
    const response = await api.get('/security/logs');
    return response.data;
  },

  monitorTransaction: async (transactionData) => {
    console.log(' securityAPI.monitorTransaction - Monitoring transaction:', transactionData);
    const response = await api.post('/security/monitor-transaction', transactionData);
    console.log(' securityAPI.monitorTransaction - Monitoring result:', response.data);
    return response.data;
  }
};

// Transaction Moods API functions
export const transactionMoodsAPI = {
  addMood: async (moodData) => {
    console.log(' transactionMoodsAPI.addMood - Adding mood:', moodData);
    const response = await api.post('/transaction-moods', moodData);
    console.log(' transactionMoodsAPI.addMood - Added:', response.data);
    return response.data;
  },

  getMoodAnalysis: async () => {
    console.log(' transactionMoodsAPI.getMoodAnalysis - Requesting mood analysis');
    const response = await api.get('/transaction-moods/analysis');
    console.log(' transactionMoodsAPI.getMoodAnalysis - Received analysis');
    return response.data;
  },

  getMoodByTransaction: async (transactionId) => {
    console.log(' transactionMoodsAPI.getMoodByTransaction - Requesting mood for transaction:', transactionId);
    const response = await api.get(`/transaction-moods/transaction/${transactionId}`);
    console.log(' transactionMoodsAPI.getMoodByTransaction - Received:', response.data);
    return response.data;
  }
};

// Recurring Transactions API functions
export const recurringTransactionsAPI = {
  getAll: async () => {
    console.log(' recurringTransactionsAPI.getAll - Requesting recurring transactions');
    const response = await api.get('/recurring-transactions');
    console.log(' recurringTransactionsAPI.getAll - Received:', response.data.length, 'recurring transactions');
    return response.data;
  },

  create: async (recurringData) => {
    console.log(' recurringTransactionsAPI.create - Creating recurring transaction:', recurringData);
    const response = await api.post('/recurring-transactions', recurringData);
    console.log(' recurringTransactionsAPI.create - Created:', response.data);
    return response.data;
  },

  processDue: async () => {
    console.log(' recurringTransactionsAPI.processDue - Processing due transactions');
    const response = await api.post('/recurring-transactions/process-due');
    console.log(' recurringTransactionsAPI.processDue - Processed:', response.data);
    return response.data;
  }
};

export default api;
export { api };  