export class GoalOptimizer {
  static optimizeGoalAllocation(goals, availableFunds, riskProfile = 'moderate') {
    const optimizedAllocation = [];
    const totalPriority = goals.reduce((sum, goal) => sum + this.calculateGoalPriority(goal), 0);
    
    goals.forEach(goal => {
      const priority = this.calculateGoalPriority(goal);
      const allocationPercentage = priority / totalPriority;
      const allocatedAmount = availableFunds * allocationPercentage;
      
      optimizedAllocation.push({
        goal,
        allocatedAmount,
        allocationPercentage: (allocationPercentage * 100).toFixed(1),
        expectedCompletion: this.calculateExpectedCompletion(goal, allocatedAmount),
        impactScore: this.calculateImpactScore(goal, allocatedAmount)
      });
    });

    return optimizedAllocation.sort((a, b) => b.impactScore - a.impactScore);
  }

  static calculateGoalPriority(goal) {
    let priority = 0;
    
    // Time urgency (sooner deadlines get higher priority)
    const daysUntilDeadline = (new Date(goal.deadline) - new Date()) / (1000 * 60 * 60 * 24);
    if (daysUntilDeadline < 30) priority += 10;
    else if (daysUntilDeadline < 90) priority += 7;
    else if (daysUntilDeadline < 365) priority += 5;
    else priority += 2;

    // Completion status
    const completionPercentage = (goal.currentAmount / goal.targetAmount) * 100;
    if (completionPercentage > 80) priority += 8; // Close to completion
    else if (completionPercentage < 20) priority += 3; // Just started
    else priority += 5; // In progress

    // Goal type priority
    const priorityWeights = {
      'emergency': 10,
      'debt': 8,
      'retirement': 6,
      'education': 7,
      'housing': 9,
      'vehicle': 5,
      'vacation': 3,
      'other': 2
    };
    
    priority += priorityWeights[goal.category.toLowerCase()] || 4;

    return priority;
  }

  static calculateExpectedCompletion(goal, monthlyAllocation) {
    const remainingAmount = goal.targetAmount - goal.currentAmount;
    const monthsToComplete = remainingAmount / monthlyAllocation;
    const completionDate = new Date();
    completionDate.setMonth(completionDate.getMonth() + Math.ceil(monthsToComplete));
    
    return {
      monthsToComplete: Math.ceil(monthsToComplete),
      expectedDate: completionDate,
      isAchievable: monthsToComplete <= 60 // 5 years max for realistic goals
    };
  }

  static calculateImpactScore(goal, allocatedAmount) {
    const remainingAmount = goal.targetAmount - goal.currentAmount;
    const percentageCovered = (allocatedAmount / remainingAmount) * 100;
    
    let impact = percentageCovered * 0.6; // 60% weight on coverage
    
    // Time sensitivity bonus
    const daysUntilDeadline = (new Date(goal.deadline) - new Date()) / (1000 * 60 * 60 * 24);
    if (daysUntilDeadline < 90) impact += 30;
    else if (daysUntilDeadline < 180) impact += 15;

    // Goal importance bonus
    const importantGoals = ['emergency', 'debt', 'housing'];
    if (importantGoals.includes(goal.category.toLowerCase())) impact += 20;

    return Math.min(impact, 100); // Cap at 100
  }

  static generateGoalAchievementPlan(goal, monthlyContribution) {
    const plan = {
      timeline: [],
      milestones: [],
      recommendations: []
    };

    const remainingAmount = goal.targetAmount - goal.currentAmount;
    const totalMonths = Math.ceil(remainingAmount / monthlyContribution);
    
    // Generate monthly timeline
    for (let month = 1; month <= totalMonths; month++) {
      const accumulated = goal.currentAmount + (monthlyContribution * month);
      plan.timeline.push({
        month,
        accumulated,
        percentage: (accumulated / goal.targetAmount) * 100
      });
    }

    // Generate milestones
    const milestonePercentages = [25, 50, 75, 90, 100];
    milestonePercentages.forEach(percentage => {
      const targetAmount = (percentage / 100) * goal.targetAmount;
      const monthsToMilestone = Math.ceil((targetAmount - goal.currentAmount) / monthlyContribution);
      
      if (monthsToMilestone > 0) {
        plan.milestones.push({
          percentage,
          targetAmount,
          monthsToReach: monthsToMilestone,
          expectedDate: new Date(new Date().setMonth(new Date().getMonth() + monthsToMilestone))
        });
      }
    });

    // Generate recommendations
    if (totalMonths > 36) {
      plan.recommendations.push({
        type: 'timeframe',
        message: `This goal will take ${totalMonths} months to complete. Consider increasing your monthly contribution to accelerate achievement.`,
        suggestion: `Increase monthly contribution to $${(monthlyContribution * 1.5).toFixed(2)} to complete in ${Math.ceil(totalMonths / 1.5)} months`
      });
    }

    if (goal.currentAmount / goal.targetAmount < 0.1 && totalMonths > 12) {
      plan.recommendations.push({
        type: 'motivation',
        message: 'You\'re just starting this goal. Set smaller interim targets to stay motivated.',
        suggestion: 'Aim to reach 25% completion within the next 3 months'
      });
    }

    return plan;
  }
}