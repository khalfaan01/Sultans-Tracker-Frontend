export class PredictiveBudgeting {
  static generateSmartBudgets(transactions, currentBudgets = []) {
    const recommendations = [];
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    
    const recentTransactions = transactions.filter(tx => 
      new Date(tx.date) >= threeMonthsAgo
    );

    // Analyze spending by category
    const categorySpending = {};
    recentTransactions
      .filter(tx => tx.type === 'expense')
      .forEach(tx => {
        categorySpending[tx.category] = (categorySpending[tx.category] || 0) + Math.abs(tx.amount);
      });

    // Generate budget recommendations
    Object.entries(categorySpending).forEach(([category, spent]) => {
      const monthlyAverage = spent / 3;
      const existingBudget = currentBudgets.find(b => b.category === category);
      
      let recommendedLimit;
      if (monthlyAverage < 50) {
        recommendedLimit = Math.ceil(monthlyAverage / 10) * 10; // Round to nearest 10
      } else if (monthlyAverage < 500) {
        recommendedLimit = Math.ceil(monthlyAverage / 50) * 50; // Round to nearest 50
      } else {
        recommendedLimit = Math.ceil(monthlyAverage / 100) * 100; // Round to nearest 100
      }

      // Add buffer for variable spending
      recommendedLimit = Math.max(recommendedLimit * 1.2, recommendedLimit + 50);

      if (!existingBudget || Math.abs(existingBudget.limit - recommendedLimit) > recommendedLimit * 0.3) {
        recommendations.push({
          category,
          currentSpending: monthlyAverage,
          recommendedLimit,
          confidence: this.calculateConfidence(recentTransactions, category),
          reasoning: this.generateReasoning(category, monthlyAverage, recommendedLimit)
        });
      }
    });

    return recommendations;
  }

  static calculateConfidence(transactions, category) {
    const categoryTransactions = transactions.filter(tx => 
      tx.category === category && tx.type === 'expense'
    );
    
    if (categoryTransactions.length < 5) return 'low';
    if (categoryTransactions.length < 15) return 'medium';
    return 'high';
  }

  static generateReasoning(category, averageSpending, recommendedLimit) {
    const variance = ((recommendedLimit - averageSpending) / averageSpending) * 100;
    
    if (variance > 50) {
      return `Based on your ${category} spending patterns, we recommend a higher limit to accommodate occasional larger purchases.`;
    } else if (variance < -20) {
      return `Your current ${category} spending suggests you could maintain your lifestyle with a slightly lower budget.`;
    } else {
      return `This budget aligns well with your historical ${category} spending patterns.`;
    }
  }

  static predictOverspending(budgets, transactions) {
    const predictions = [];
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    budgets.forEach(budget => {
      const monthlySpending = transactions
        .filter(tx => 
          tx.type === 'expense' && 
          tx.category === budget.category &&
          new Date(tx.date).getMonth() === currentMonth &&
          new Date(tx.date).getFullYear() === currentYear
        )
        .reduce((sum, tx) => sum + Math.abs(tx.amount), 0);

      const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
      const today = new Date().getDate();
      const dailyAverage = monthlySpending / today;
      const projectedSpending = dailyAverage * daysInMonth;

      if (projectedSpending > budget.limit * 1.1) {
        predictions.push({
          budget,
          currentSpending: monthlySpending,
          projectedSpending,
          overshootAmount: projectedSpending - budget.limit,
          riskLevel: projectedSpending > budget.limit * 1.3 ? 'high' : 'medium'
        });
      }
    });

    return predictions;
  }
}