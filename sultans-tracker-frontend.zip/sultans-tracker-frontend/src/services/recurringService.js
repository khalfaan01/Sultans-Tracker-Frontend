// src/services/recurringService.js
import { api } from './api';

class RecurringService {
  // Get all recurring transactions
  async getRecurringTransactions() {
    try {
      console.log('🔁 Fetching recurring transactions from API');
      const response = await api.get('/recurring-transactions');
      console.log('🔁 Received recurring transactions:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ Error fetching recurring transactions:', error);
      
      // If endpoint doesn't exist, return mock data for development
      if (error.response?.status === 404) {
        console.log('🔁 Endpoint not found, returning mock data');
        return this.getMockRecurringTransactions();
      }
      
      throw error;
    }
  }

  // Create new recurring transaction
  async createRecurringTransaction(data) {
    try {
      // Transform data to match backend expectations
      const backendData = {
        accountId: parseInt(data.accountId) || 1,
        amount: parseFloat(data.amount),
        type: data.type,
        category: data.category || 'Uncategorized',
        description: data.description,
        frequency: data.frequency,
        interval: 1, // Default interval
        startDate: new Date().toISOString(),
        nextRunDate: this.calculateNextRunDate(data.frequency).toISOString(),
        isActive: data.isActive !== undefined ? data.isActive : true,
        autoApprove: data.autoApprove || false
      };

      console.log('🔁 Creating recurring transaction with data:', backendData);
      const response = await api.post('/recurring-transactions', backendData);
      console.log('✅ Recurring transaction created:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ Error creating recurring transaction:', error);
      console.error('❌ Error details:', error.response?.data);
      
      // If endpoint doesn't exist, simulate success for development
      if (error.response?.status === 404) {
        console.log('🔁 Endpoint not found, simulating success');
        return {
          id: Date.now(),
          ...data,
          nextRunDate: this.calculateNextRunDate(data.frequency).toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
      }
      
      throw error;
    }
  }

  // Update recurring transaction
  async updateRecurringTransaction(id, data) {
    try {
      const backendData = {
        ...data,
        accountId: data.accountId ? parseInt(data.accountId) : undefined,
        amount: data.amount ? parseFloat(data.amount) : undefined
      };

      console.log('🔁 Updating recurring transaction:', id, backendData);
      const response = await api.put(`/recurring-transactions/${id}`, backendData);
      console.log('✅ Recurring transaction updated:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ Error updating recurring transaction:', error);
      
      // If endpoint doesn't exist, simulate success for development
      if (error.response?.status === 404) {
        console.log('🔁 Endpoint not found, simulating success');
        return {
          id: parseInt(id),
          ...data,
          updatedAt: new Date().toISOString()
        };
      }
      
      throw error;
    }
  }

  // Delete recurring transaction
  async deleteRecurringTransaction(id) {
    try {
      console.log('🔁 Deleting recurring transaction:', id);
      await api.delete(`/recurring-transactions/${id}`);
      console.log('✅ Recurring transaction deleted');
    } catch (error) {
      console.error('❌ Error deleting recurring transaction:', error);
      
      // If endpoint doesn't exist, simulate success for development
      if (error.response?.status === 404) {
        console.log('🔁 Endpoint not found, simulating success');
        return;
      }
      
      throw error;
    }
  }

  // Toggle active status
  async toggleRecurringTransaction(id, isActive) {
    try {
      console.log('🔁 Toggling recurring transaction status:', id, isActive);
      const response = await api.patch(`/recurring-transactions/${id}/toggle`, { isActive });
      console.log('✅ Recurring transaction status updated:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ Error toggling recurring transaction:', error);
      
      // If endpoint doesn't exist, use update method instead
      if (error.response?.status === 404) {
        console.log('🔁 Toggle endpoint not found, using update instead');
        return this.updateRecurringTransaction(id, { isActive });
      }
      
      throw error;
    }
  }

  // Process due recurring transactions
  async processDueTransactions() {
    try {
      console.log('🔁 Processing due recurring transactions');
      const response = await api.post('/recurring-transactions/process-due');
      console.log('✅ Due transactions processed:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ Error processing due transactions:', error);
      throw error;
    }
  }

  // Detect recurring patterns from transaction history
  detectRecurringTransactions(transactions) {
    if (!transactions || transactions.length === 0) {
      return [];
    }

    const recurringPatterns = [];
    const groupedTransactions = this.groupTransactions(transactions);

    // Analyze each group for patterns
    Object.values(groupedTransactions).forEach(group => {
      const pattern = this.analyzePattern(group);
      if (pattern.confidence > 0.7) {
        recurringPatterns.push(pattern);
      }
    });

    return recurringPatterns;
  }

  // Group transactions by description and amount
  groupTransactions(transactions) {
    const groups = {};

    transactions.forEach(transaction => {
      const key = this.getTransactionKey(transaction);
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(transaction);
    });

    return groups;
  }

  // Create a unique key for grouping
  getTransactionKey(transaction) {
    const amount = Math.abs(transaction.amount).toFixed(2);
    const description = transaction.description?.toLowerCase().trim() || 'unknown';
    return `${description}_${amount}`;
  }

  // Analyze pattern for a group of transactions
  analyzePattern(transactions) {
    if (transactions.length < 2) {
      return { confidence: 0 };
    }

    const sortedTransactions = transactions.sort((a, b) => 
      new Date(a.date) - new Date(b.date)
    );

    const intervals = this.calculateIntervals(sortedTransactions);
    const frequency = this.detectFrequency(intervals);
    const confidence = this.calculateConfidence(intervals, frequency);

    const latestTransaction = sortedTransactions[sortedTransactions.length - 1];
    const nextBillingDate = this.predictNextDate(latestTransaction.date, frequency);

    return {
      id: `detected_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: this.generateSubscriptionName(latestTransaction.description),
      amount: Math.abs(latestTransaction.amount),
      frequency: frequency.type,
      category: latestTransaction.category,
      description: latestTransaction.description,
      lastTransaction: latestTransaction.date,
      nextBillingDate: nextBillingDate.toISOString(),
      transactionCount: transactions.length,
      confidence: confidence,
      status: 'detected',
      isActive: true,
      autoApprove: false
    };
  }

  // Calculate time intervals between transactions
  calculateIntervals(transactions) {
    const intervals = [];
    
    for (let i = 1; i < transactions.length; i++) {
      const prevDate = new Date(transactions[i - 1].date);
      const currentDate = new Date(transactions[i].date);
      const diffTime = Math.abs(currentDate - prevDate);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      intervals.push(diffDays);
    }

    return intervals;
  }

  // Detect frequency pattern
  detectFrequency(intervals) {
    if (intervals.length === 0) return { type: 'monthly', interval: 30 };
    
    const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    
    if (avgInterval >= 28 && avgInterval <= 31) {
      return { type: 'monthly', interval: avgInterval };
    } else if (avgInterval >= 84 && avgInterval <= 93) {
      return { type: 'quarterly', interval: avgInterval };
    } else if (avgInterval >= 350 && avgInterval <= 370) {
      return { type: 'yearly', interval: avgInterval };
    } else if (avgInterval >= 6 && avgInterval <= 8) {
      return { type: 'weekly', interval: avgInterval };
    } else if (avgInterval >= 1 && avgInterval <= 2) {
      return { type: 'daily', interval: avgInterval };
    } else {
      return { type: 'custom', interval: avgInterval };
    }
  }

  // Calculate confidence score (0-1)
  calculateConfidence(intervals, frequency) {
    if (intervals.length < 2) return 0;

    const variance = intervals.reduce((acc, interval) => {
      return acc + Math.pow(interval - frequency.interval, 2);
    }, 0) / intervals.length;

    const stdDev = Math.sqrt(variance);
    const consistency = Math.max(0, 1 - (stdDev / frequency.interval));
    const countFactor = Math.min(1, intervals.length / 6);

    return (consistency * 0.7) + (countFactor * 0.3);
  }

  // Predict next billing date
  predictNextDate(lastDate, frequency) {
    const date = new Date(lastDate);
    
    switch (frequency.type) {
      case 'daily':
        date.setDate(date.getDate() + 1);
        break;
      case 'weekly':
        date.setDate(date.getDate() + 7);
        break;
      case 'monthly':
        date.setMonth(date.getMonth() + 1);
        break;
      case 'quarterly':
        date.setMonth(date.getMonth() + 3);
        break;
      case 'yearly':
        date.setFullYear(date.getFullYear() + 1);
        break;
      default:
        date.setDate(date.getDate() + Math.round(frequency.interval));
    }

    return date;
  }

  // Calculate next run date for new recurring transactions
  calculateNextRunDate(frequency) {
    const nextDate = new Date();
    
    switch (frequency) {
      case 'daily':
        nextDate.setDate(nextDate.getDate() + 1);
        break;
      case 'weekly':
        nextDate.setDate(nextDate.getDate() + 7);
        break;
      case 'monthly':
        nextDate.setMonth(nextDate.getMonth() + 1);
        break;
      case 'quarterly':
        nextDate.setMonth(nextDate.getMonth() + 3);
        break;
      case 'yearly':
        nextDate.setFullYear(nextDate.getFullYear() + 1);
        break;
      default:
        nextDate.setMonth(nextDate.getMonth() + 1);
    }
    
    return nextDate;
  }

  // Generate friendly subscription name
  generateSubscriptionName(description) {
    if (!description) return 'Unknown Subscription';
    
    const commonServices = {
      'netflix': 'Netflix',
      'spotify': 'Spotify',
      'amazon prime': 'Amazon Prime',
      'youtube premium': 'YouTube Premium',
      'microsoft': 'Microsoft 365',
      'adobe': 'Adobe Creative Cloud',
      'apple': 'Apple Services',
      'google': 'Google Services',
      'disney': 'Disney+',
      'hbo': 'HBO Max',
      'hulu': 'Hulu',
      'electric': 'Electricity Bill',
      'water': 'Water Bill',
      'gas': 'Gas Bill',
      'internet': 'Internet Bill',
      'phone': 'Phone Bill',
      'rent': 'Rent',
      'mortgage': 'Mortgage',
      'insurance': 'Insurance',
      'gym': 'Gym Membership'
    };

    const lowerDesc = description.toLowerCase();
    
    for (const [key, value] of Object.entries(commonServices)) {
      if (lowerDesc.includes(key)) {
        return value;
      }
    }

    // Capitalize first letter of each word
    return description
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }

  // Analyze and save detected patterns
  async analyzeAndSaveRecurring(transactions) {
    try {
      const detected = this.detectRecurringTransactions(transactions);
      const saved = [];

      for (const pattern of detected) {
        if (pattern.confidence > 0.7) {
          try {
            const savedPattern = await this.createRecurringTransaction(pattern);
            saved.push(savedPattern);
          } catch (error) {
            console.error('Error saving detected pattern:', error);
          }
        }
      }

      return saved;
    } catch (error) {
      console.error('Error analyzing and saving recurring transactions:', error);
      throw error;
    }
  }

  // Mock data for development when backend is not available
  getMockRecurringTransactions() {
    return [
      {
        id: 1,
        description: 'Netflix Subscription',
        amount: 15.99,
        type: 'expense',
        category: 'Entertainment',
        frequency: 'monthly',
        nextRunDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        isActive: true,
        autoApprove: true,
        accountId: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 2,
        description: 'Monthly Salary',
        amount: 3000,
        type: 'income',
        category: 'Salary',
        frequency: 'monthly',
        nextRunDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        isActive: true,
        autoApprove: true,
        accountId: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 3,
        description: 'Gym Membership',
        amount: 29.99,
        type: 'expense',
        category: 'Health & Fitness',
        frequency: 'monthly',
        nextRunDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        isActive: true,
        autoApprove: false,
        accountId: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];
  }
}

export const recurringService = new RecurringService();
export default recurringService;