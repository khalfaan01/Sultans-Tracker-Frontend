import api from './api.js'; // Use your existing axios instance

export class AnalyticsService {
  static async getEnhancedAnalytics(timeframe = 'monthly') {
    try {
      console.log(' Fetching enhanced analytics...');
      const response = await api.get(`/analytics/enhanced?timeframe=${timeframe}`);
      console.log(' Enhanced analytics received:', response.data);
      return response.data;
    } catch (error) {
      console.error(' Enhanced analytics error:', error);
      throw error;
    }
  }

  static async getCashFlowAnalysis(granularity = 'daily') {
    try {
      const response = await api.get(`/analytics/cash-flow?granularity=${granularity}`);
      return response.data;
    } catch (error) {
      console.error('Cash flow analysis error:', error);
      throw error;
    }
  }

  static async getIncomeBreakdown() {
    try {
      const response = await api.get('/analytics/income-breakdown');
      return response.data;
    } catch (error) {
      console.error('Income breakdown error:', error);
      throw error;
    }
  }

  static async getSpendingForecast(days = 30) {
    try {
      const response = await api.get(`/analytics/forecast?days=${days}`);
      return response.data;
    } catch (error) {
      console.error('Spending forecast error:', error);
      throw error;
    }
  }

  static async getContextualInsights() {
    try {
      const response = await api.get('/analytics/contextual-insights');
      return response.data;
    } catch (error) {
      console.error('Contextual insights error:', error);
      throw error;
    }
  }
}