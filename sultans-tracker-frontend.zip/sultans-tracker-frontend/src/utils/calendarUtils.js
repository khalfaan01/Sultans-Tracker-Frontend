import { 
  getStartOfMonth, 
  getEndOfMonth, 
  getDaysInMonth, 
  addMonths,
  getMonthName,
  getShortMonthName,
  getWeekdayName,
  getShortWeekdayName,
  generateDateRange
} from './dateUtils';

// Calendar-specific utilities
export const generateCalendarMonth = (year, month) => {
  const startOfMonth = getStartOfMonth(new Date(year, month));
  const endOfMonth = getEndOfMonth(new Date(year, month));
  const daysInMonth = getDaysInMonth(year, month);
  
  // Get the day of the week for the first day of month (0 = Sunday, 1 = Monday, etc.)
  const firstDayOfMonth = startOfMonth.getDay();
  
  // Calculate days from previous month to show
  const daysFromPrevMonth = firstDayOfMonth;
  
  // Calculate days from next month to show (to fill 6 weeks)
  const totalCells = 42; // 6 weeks * 7 days
  const daysFromNextMonth = totalCells - daysInMonth - daysFromPrevMonth;

  const calendar = {
    year,
    month,
    monthName: getMonthName(month),
    shortMonthName: getShortMonthName(month),
    weeks: [],
    days: []
  };

  // Add days from previous month
  const prevMonth = month === 0 ? 11 : month - 1;
  const prevMonthYear = month === 0 ? year - 1 : year;
  const prevMonthDays = getDaysInMonth(prevMonthYear, prevMonth);
  
  for (let i = daysFromPrevMonth - 1; i >= 0; i--) {
    const day = prevMonthDays - i;
    calendar.days.push({
      date: new Date(prevMonthYear, prevMonth, day),
      isCurrentMonth: false,
      isPreviousMonth: true,
      isNextMonth: false,
      dayNumber: day
    });
  }

  // Add days from current month
  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month, day);
    calendar.days.push({
      date,
      isCurrentMonth: true,
      isPreviousMonth: false,
      isNextMonth: false,
      dayNumber: day,
      isToday: new Date().toDateString() === date.toDateString()
    });
  }

  // Add days from next month
  const nextMonth = month === 11 ? 0 : month + 1;
  const nextMonthYear = month === 11 ? year + 1 : year;
  
  for (let day = 1; day <= daysFromNextMonth; day++) {
    calendar.days.push({
      date: new Date(nextMonthYear, nextMonth, day),
      isCurrentMonth: false,
      isPreviousMonth: false,
      isNextMonth: true,
      dayNumber: day
    });
  }

  // Group days into weeks
  for (let i = 0; i < calendar.days.length; i += 7) {
    calendar.weeks.push(calendar.days.slice(i, i + 7));
  }

  return calendar;
};

export const getWeekNumbers = (year, month) => {
  const firstDayOfMonth = new Date(year, month, 1);
  const firstWeekNumber = getWeekNumber(firstDayOfMonth);
  const weeks = [];
  
  for (let i = 0; i < 6; i++) {
    weeks.push(firstWeekNumber + i);
  }
  
  return weeks;
};

export const getWeekNumber = (date) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
  const week1 = new Date(d.getFullYear(), 0, 4);
  return 1 + Math.round(((d - week1) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
};

export const getCalendarHeatmapData = (transactions, year, month) => {
  const calendar = generateCalendarMonth(year, month);
  const heatmapData = {};

  // Initialize all days with zero values
  calendar.days.forEach(day => {
    const dateKey = day.date.toISOString().split('T')[0];
    heatmapData[dateKey] = {
      date: day.date,
      transactions: [],
      totalIncome: 0,
      totalExpenses: 0,
      netAmount: 0,
      transactionCount: 0,
      intensity: 0 // 0-100 for heatmap intensity
    };
  });

  // Populate with actual transaction data
  transactions.forEach(transaction => {
    const transactionDate = new Date(transaction.date);
    const dateKey = transactionDate.toISOString().split('T')[0];
    
    if (heatmapData[dateKey]) {
      heatmapData[dateKey].transactions.push(transaction);
      heatmapData[dateKey].transactionCount++;
      
      if (transaction.amount > 0) {
        heatmapData[dateKey].totalIncome += transaction.amount;
      } else {
        heatmapData[dateKey].totalExpenses += Math.abs(transaction.amount);
      }
      
      heatmapData[dateKey].netAmount += transaction.amount;
    }
  });

  // Calculate intensity for heatmap (based on expense amount)
  const maxExpense = Math.max(...Object.values(heatmapData).map(day => day.totalExpenses));
  
  Object.values(heatmapData).forEach(day => {
    if (maxExpense > 0) {
      day.intensity = Math.min(100, (day.totalExpenses / maxExpense) * 100);
    } else {
      day.intensity = 0;
    }
  });

  return heatmapData;
};

export const getMonthNavigation = (currentYear, currentMonth) => {
  const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
  const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
  
  const nextMonth = currentMonth === 11 ? 0 : currentMonth + 1;
  const nextYear = currentMonth === 11 ? currentYear + 1 : currentYear;

  return {
    previous: {
      year: prevYear,
      month: prevMonth,
      name: getMonthName(prevMonth)
    },
    current: {
      year: currentYear,
      month: currentMonth,
      name: getMonthName(currentMonth)
    },
    next: {
      year: nextYear,
      month: nextMonth,
      name: getMonthName(nextMonth)
    }
  };
};

export const getWeekdayHeaders = (format = 'short') => {
  const weekdays = [];
  
  for (let i = 0; i < 7; i++) {
    weekdays.push(
      format === 'short' 
        ? getShortWeekdayName(i)
        : getWeekdayName(i)
    );
  }
  
  return weekdays;
};

// Get financial periods (weeks, months, quarters)
export const getFinancialPeriods = (startDate, endDate, periodType = 'month') => {
  const periods = [];
  let current = new Date(startDate);
  const end = new Date(endDate);

  while (current <= end) {
    let periodEnd;
    
    switch (periodType) {
      case 'week':
        periodEnd = new Date(current);
        periodEnd.setDate(periodEnd.getDate() + 6);
        break;
      case 'month':
        periodEnd = getEndOfMonth(current);
        break;
      case 'quarter':
        periodEnd = new Date(current);
        periodEnd.setMonth(periodEnd.getMonth() + 3);
        periodEnd.setDate(0);
        break;
      default:
        periodEnd = getEndOfMonth(current);
    }

    periods.push({
      start: new Date(current),
      end: periodEnd,
      label: getPeriodLabel(current, periodType),
      key: `${periodType}_${current.getFullYear()}_${current.getMonth()}`
    });

    // Move to next period
    switch (periodType) {
      case 'week':
        current.setDate(current.getDate() + 7);
        break;
      case 'month':
        current.setMonth(current.getMonth() + 1);
        current.setDate(1);
        break;
      case 'quarter':
        current.setMonth(current.getMonth() + 3);
        current.setDate(1);
        break;
      default:
        current.setMonth(current.getMonth() + 1);
        current.setDate(1);
    }
  }

  return periods;
};

const getPeriodLabel = (date, periodType) => {
  switch (periodType) {
    case 'week':
      return `Week ${getWeekNumber(date)}`;
    case 'month':
      return getMonthName(date.getMonth());
    case 'quarter':
      const quarter = Math.floor(date.getMonth() / 3) + 1;
      return `Q${quarter} ${date.getFullYear()}`;
    default:
      return getMonthName(date.getMonth());
  }
};

// Calculate business days between two dates
export const getBusinessDays = (startDate, endDate) => {
  let count = 0;
  const current = new Date(startDate);
  const end = new Date(endDate);

  while (current <= end) {
    const day = current.getDay();
    if (day !== 0 && day !== 6) { // Not Sunday or Saturday
      count++;
    }
    current.setDate(current.getDate() + 1);
  }

  return count;
};