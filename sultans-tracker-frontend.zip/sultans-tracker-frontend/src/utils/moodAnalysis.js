// Financial mood analysis utilities
export const calculateMoodScore = (transaction, context = {}) => {
  const baseScore = 50;
  let score = baseScore;
  const factors = [];

  const amount = Math.abs(transaction.amount);
  const isIncome = transaction.amount > 0;

  // Amount impact
  if (isIncome) {
    if (amount > 1000) {
      score += 25;
      factors.push('large-income');
    } else if (amount > 500) {
      score += 15;
      factors.push('medium-income');
    } else if (amount > 100) {
      score += 8;
      factors.push('small-income');
    }
  } else {
    // Expense impact
    if (amount > 500) {
      score -= 30;
      factors.push('large-expense');
    } else if (amount > 200) {
      score -= 20;
      factors.push('medium-expense');
    } else if (amount > 50) {
      score -= 10;
      factors.push('small-expense');
    } else if (amount < 10) {
      score += 5;
      factors.push('micro-expense');
    }
  }

  // Category impact
  const categoryImpact = getCategoryImpact(transaction.category);
  score += categoryImpact.score;
  if (categoryImpact.factor) {
    factors.push(categoryImpact.factor);
  }

  // Context impact
  if (context.budgetStatus === 'under_budget') {
    score += 10;
    factors.push('under-budget');
  } else if (context.budgetStatus === 'over_budget') {
    score -= 15;
    factors.push('over-budget');
  }

  if (context.savingsTrend === 'increasing') {
    score += 8;
    factors.push('savings-increasing');
  } else if (context.savingsTrend === 'decreasing') {
    score -= 12;
    factors.push('savings-decreasing');
  }

  // Clamp score between 0-100
  score = Math.max(0, Math.min(100, score));

  return {
    score: Math.round(score),
    factors
  };
};

export const getCategoryImpact = (category) => {
  const impacts = {
    // Positive impact categories
    'Savings': { score: 15, factor: 'savings' },
    'Investment': { score: 12, factor: 'investment' },
    'Education': { score: 8, factor: 'education' },
    'Healthcare': { score: 5, factor: 'healthcare' },
    
    // Neutral categories
    'Groceries': { score: 0, factor: 'groceries' },
    'Utilities': { score: -2, factor: 'utilities' },
    'Transportation': { score: -3, factor: 'transportation' },
    
    // Negative impact categories
    'Dining': { score: -8, factor: 'dining' },
    'Entertainment': { score: -10, factor: 'entertainment' },
    'Shopping': { score: -12, factor: 'shopping' },
    'Travel': { score: -15, factor: 'travel' }
  };

  return impacts[category] || { score: 0, factor: 'other' };
};

export const getMoodLabel = (score) => {
  if (score >= 80) return 'excellent';
  if (score >= 65) return 'good';
  if (score >= 45) return 'neutral';
  if (score >= 30) return 'poor';
  return 'terrible';
};

export const getMoodEmoji = (moodLabel) => {
  const emojis = {
    'excellent': '😊',
    'good': '🙂',
    'neutral': '😐',
    'poor': '😕',
    'terrible': '😞'
  };
  return emojis[moodLabel] || '😐';
};

export const getMoodColor = (moodLabel) => {
  const colors = {
    'excellent': '#10B981', // Green
    'good': '#34D399',      // Light Green
    'neutral': '#6B7280',   // Gray
    'poor': '#F59E0B',      // Yellow
    'terrible': '#EF4444'   // Red
  };
  return colors[moodLabel] || '#6B7280';
};

export const analyzeMoodTrend = (moodHistory) => {
  if (!moodHistory || moodHistory.length < 2) {
    return {
      trend: 'stable',
      direction: 0,
      confidence: 0
    };
  }

  const recentScores = moodHistory.slice(-7).map(entry => entry.score);
  const olderScores = moodHistory.slice(-14, -7).map(entry => entry.score);
  
  const recentAvg = recentScores.reduce((a, b) => a + b, 0) / recentScores.length;
  const olderAvg = olderScores.length > 0 
    ? olderScores.reduce((a, b) => a + b, 0) / olderScores.length 
    : recentAvg;

  const difference = recentAvg - olderAvg;
  const absoluteDiff = Math.abs(difference);
  
  let trend = 'stable';
  if (absoluteDiff > 10) {
    trend = difference > 0 ? 'improving' : 'declining';
  } else if (absoluteDiff > 5) {
    trend = difference > 0 ? 'slightly improving' : 'slightly declining';
  }

  return {
    trend,
    direction: difference,
    confidence: Math.min(100, absoluteDiff * 2)
  };
};

export const generateMoodInsights = (moodAnalysis, transactions) => {
  const insights = [];
  const { score, factors } = moodAnalysis;

  if (score < 40) {
    insights.push({
      type: 'warning',
      message: 'Your financial mood is low. Consider reviewing recent expenses.',
      suggestion: 'Look for subscription services you can cancel or reduce.'
    });
  }

  if (factors.includes('large-expense')) {
    insights.push({
      type: 'info',
      message: 'You had a large expense recently.',
      suggestion: 'Consider spreading large purchases over multiple months.'
    });
  }

  if (factors.includes('over-budget')) {
    insights.push({
      type: 'warning',
      message: 'You are over budget in some categories.',
      suggestion: 'Review your budget limits and adjust spending habits.'
    });
  }

  if (factors.includes('savings-increasing')) {
    insights.push({
      type: 'positive',
      message: 'Great! Your savings are increasing.',
      suggestion: 'Consider increasing your savings rate by 5%.'
    });
  }

  if (score > 75) {
    insights.push({
      type: 'positive',
      message: 'Excellent financial mood!',
      suggestion: 'Your financial habits are working well. Consider setting new goals!'
    });
  }

  // Add general insights if no specific ones were generated
  if (insights.length === 0) {
    insights.push({
      type: 'info',
      message: 'Your financial mood is stable.',
      suggestion: 'Continue monitoring your spending and savings patterns.'
    });
  }

  return insights;
};

export const calculateFinancialHealthScore = (transactions, period = 'month') => {
  if (!transactions || transactions.length === 0) {
    return 50; // Neutral score for no data
  }

  const recentTransactions = transactions.filter(t => {
    const transactionDate = new Date(t.date);
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - 30); // Last 30 days
    
    return transactionDate >= cutoffDate;
  });

  const income = recentTransactions
    .filter(t => t.amount > 0)
    .reduce((sum, t) => sum + t.amount, 0);

  const expenses = recentTransactions
    .filter(t => t.amount < 0)
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);

  const savingsRate = income > 0 ? (income - expenses) / income : 0;
  const expenseDiversity = calculateExpenseDiversity(recentTransactions);
  const consistencyScore = calculateSpendingConsistency(recentTransactions);

  // Weighted score calculation
  const savingsScore = Math.min(100, savingsRate * 200); // 50% savings rate = 100 points
  const diversityScore = expenseDiversity * 100;
  const consistencyScorePoints = consistencyScore * 100;

  const totalScore = (
    savingsScore * 0.5 + 
    diversityScore * 0.3 + 
    consistencyScorePoints * 0.2
  );

  return Math.round(Math.max(0, Math.min(100, totalScore)));
};

const calculateExpenseDiversity = (transactions) => {
  const expenses = transactions.filter(t => t.amount < 0);
  const categoryCounts = {};
  
  expenses.forEach(transaction => {
    const category = transaction.category || 'Other';
    categoryCounts[category] = (categoryCounts[category] || 0) + 1;
  });

  const totalCategories = Object.keys(categoryCounts).length;
  const totalExpenses = expenses.length;
  
  // Diversity score: more categories = better, but avoid extreme fragmentation
  return totalExpenses > 0 
    ? Math.min(1, totalCategories / Math.max(1, totalExpenses / 3))
    : 0.5;
};

const calculateSpendingConsistency = (transactions) => {
  const dailySpending = {};
  
  transactions.forEach(transaction => {
    if (transaction.amount < 0) {
      const date = new Date(transaction.date).toISOString().split('T')[0];
      dailySpending[date] = (dailySpending[date] || 0) + Math.abs(transaction.amount);
    }
  });

  const spendingAmounts = Object.values(dailySpending);
  if (spendingAmounts.length < 2) return 0.5;

  const average = spendingAmounts.reduce((a, b) => a + b, 0) / spendingAmounts.length;
  const variance = spendingAmounts.reduce((acc, val) => acc + Math.pow(val - average, 2), 0) / spendingAmounts.length;
  const stdDev = Math.sqrt(variance);
  const coefficientOfVariation = stdDev / average;

  // Lower variation = higher consistency
  return Math.max(0, 1 - coefficientOfVariation);
};