// src/components/ui/DirectionalList.jsx
import { motion } from 'framer-motion';
import { useState } from 'react';

export default function DirectionalList({ items }) {
  const [hoveredIndex, setHoveredIndex] = useState(null);

  return (
    <div className="space-y-2">
      {items.map((item, index) => (
        <motion.div
          key={index}
          className="p-4 bg-white bg-opacity-90 rounded-lg cursor-pointer border border-gray-200"
          whileHover={{ 
            x: 20,
            transition: { type: "spring", stiffness: 300 }
          }}
          onHoverStart={() => setHoveredIndex(index)}
          onHoverEnd={() => setHoveredIndex(null)}
          data-magnetic="true"
        >
          <div className="flex justify-between items-center">
            <span className="font-medium">{item.label}</span>
            <motion.div
              animate={{ 
                opacity: hoveredIndex === index ? 1 : 0,
                x: hoveredIndex === index ? 0 : -10
              }}
              className="text-lg font-bold"
            >
              →
            </motion.div>
          </div>
          {item.description && (
            <p className="text-sm text-gray-600 mt-1">{item.description}</p>
          )}
        </motion.div>
      ))}
    </div>
  );
}