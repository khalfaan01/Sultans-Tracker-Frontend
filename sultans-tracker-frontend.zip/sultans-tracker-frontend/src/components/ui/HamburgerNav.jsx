// src/components/ui/HamburgerNav.jsx
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, LogIn, UserPlus, LogOut, User, Settings } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function HamburgerNav() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    setIsOpen(false);
    navigate('/');
  };

  const handleNavigation = (path) => {
    navigate(path);
    setIsOpen(false);
  };

  const menuItems = isAuthenticated 
    ? [
        { icon: User, label: 'Dashboard', action: () => handleNavigation('/dashboard') },
        { icon: LogOut, label: 'Logout', action: handleLogout }
      ]
    : [
        { icon: LogIn, label: 'Login', action: () => handleNavigation('/login') },
        { icon: UserPlus, label: 'Register', action: () => handleNavigation('/register') }
      ];

  return (
    <>
      <motion.button
        className="fixed top-6 left-6 z-50 p-3 bg-white rounded-full shadow-lg"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ x: -300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -300, opacity: 0 }}
            transition={{ type: "spring", damping: 25 }}
            className="fixed top-0 left-0 h-full w-80 bg-white shadow-2xl z-40 p-6"
          >
            <div className="mt-20 space-y-4">
              {isAuthenticated && user && (
                <div className="p-4 bg-gray-50 rounded-lg mb-4">
                  <p className="font-semibold">Welcome back!</p>
                  <p className="text-sm text-gray-600">{user.email}</p>
                  {user.lastLoginFrom && (
                    <p className="text-xs text-gray-500">Last login: {user.lastLoginFrom}</p>
                  )}
                </div>
              )}
              
              {menuItems.map((item, index) => (
                <motion.button
                  key={item.label}
                  onClick={item.action}
                  className="w-full flex items-center space-x-3 p-4 hover:bg-gray-100 rounded-lg transition-colors text-left"
                  whileHover={{ x: 10 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <item.icon size={20} />
                  <span className="font-medium">{item.label}</span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overlay */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}