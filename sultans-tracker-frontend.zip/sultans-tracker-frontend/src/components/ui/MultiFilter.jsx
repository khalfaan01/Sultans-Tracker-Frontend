import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, X, ChevronDown } from 'lucide-react';

export default function MultiFilter({ filters, onFiltersChange, activeTab = 'Transactions' }) {
  const [isOpen, setIsOpen] = useState(false);

  // Only show filters for Transactions tab
  if (activeTab !== 'Transactions') {
    return null;
  }

  const filterTypes = [
    {
      key: 'dateRange',
      label: 'Date Range',
      type: 'date-range'
    },
    {
      key: 'amountRange', 
      label: 'Amount Range',
      type: 'amount-range'
    },
    {
      key: 'categories',
      label: 'Categories',
      type: 'multi-select',
      options: ['Food', 'Travel', 'Entertainment', 'Rent', 'Shopping', 'Utilities', 'Healthcare', 'Other']
    },
    {
      key: 'type',
      label: 'Type',
      type: 'select', 
      options: ['All', 'Income', 'Expense']
    }
  ];

  const handleDateRangeChange = (type, value) => {
    const newDateRange = { ...filters.dateRange, [type]: value };
    onFiltersChange({ ...filters, dateRange: newDateRange });
  };

  const handleAmountRangeChange = (type, value) => {
    const newAmountRange = { ...filters.amountRange, [type]: value };
    onFiltersChange({ ...filters, amountRange: newAmountRange });
  };

  const clearFilter = (filterKey) => {
    onFiltersChange({ ...filters, [filterKey]: null });
  };

  return (
    <div className="mb-6">
      <div className="flex items-center space-x-4">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg border shadow-sm hover:bg-gray-50 transition-colors"
        >
          <Filter size={20} />
          <span>Filters</span>
          <ChevronDown size={16} className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
        
        {/* Active filters display */}
        <div className="flex flex-wrap gap-2">
          {filters.dateRange && (filters.dateRange.start || filters.dateRange.end) && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="flex items-center space-x-2 bg-blue-100 px-3 py-1 rounded-full text-sm"
            >
              <span>Date: {filters.dateRange.start || 'Any'} to {filters.dateRange.end || 'Any'}</span>
              <button onClick={() => clearFilter('dateRange')} className="hover:text-blue-700">
                <X size={14} />
              </button>
            </motion.div>
          )}
          
          {filters.amountRange && (filters.amountRange.min || filters.amountRange.max) && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="flex items-center space-x-2 bg-green-100 px-3 py-1 rounded-full text-sm"
            >
              <span>Amount: ${filters.amountRange.min || '0'} to ${filters.amountRange.max || 'Any'}</span>
              <button onClick={() => clearFilter('amountRange')} className="hover:text-green-700">
                <X size={14} />
              </button>
            </motion.div>
          )}
          
          {filters.categories && filters.categories.length > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="flex items-center space-x-2 bg-purple-100 px-3 py-1 rounded-full text-sm"
            >
              <span>Categories: {filters.categories.length} selected</span>
              <button onClick={() => clearFilter('categories')} className="hover:text-purple-700">
                <X size={14} />
              </button>
            </motion.div>
          )}
          
          {filters.type && filters.type !== 'all' && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="flex items-center space-x-2 bg-orange-100 px-3 py-1 rounded-full text-sm"
            >
              <span>Type: {filters.type}</span>
              <button onClick={() => clearFilter('type')} className="hover:text-orange-700">
                <X size={14} />
              </button>
            </motion.div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 bg-white p-6 rounded-lg border shadow-sm"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Date Range Filter */}
              <div>
  <label className="block text-sm font-medium mb-3">Date Range</label>
  <div className="space-y-3">
    <div>
      <label className="block text-xs text-gray-500 mb-1">From</label>
      <input
        type="date"
        value={filters.dateRange?.start || ''}
        onChange={(e) => {
          const selectedDate = new Date(e.target.value);
          const today = new Date();
          
          // Prevent future dates
          if (selectedDate > today) {
            alert('Future dates are not allowed for filtering.');
            return;
          }
          handleDateRangeChange('start', e.target.value);
        }}
        max={new Date().toISOString().split('T')[0]}
        className="w-full p-2 border rounded-lg text-sm"
      />
    </div>
    <div>
      <label className="block text-xs text-gray-500 mb-1">To</label>
      <input
        type="date"
        value={filters.dateRange?.end || ''}
        onChange={(e) => {
          const selectedDate = new Date(e.target.value);
          const today = new Date();
          
          // Prevent future dates
          if (selectedDate > today) {
            alert('Future dates are not allowed for filtering.');
            return;
          }
          handleDateRangeChange('end', e.target.value);
        }}
        max={new Date().toISOString().split('T')[0]}
        className="w-full p-2 border rounded-lg text-sm"
      />
    </div>
  </div>
  <p className="text-xs text-gray-500 mt-2">
    Filter by date range (past dates only)
  </p>
</div>

              {/* Amount Range Filter */}
              <div>
                <label className="block text-sm font-medium mb-3">Amount Range</label>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Min Amount ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      value={filters.amountRange?.min || ''}
                      onChange={(e) => handleAmountRangeChange('min', e.target.value)}
                      className="w-full p-2 border rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Max Amount ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="Any"
                      value={filters.amountRange?.max || ''}
                      onChange={(e) => handleAmountRangeChange('max', e.target.value)}
                      className="w-full p-2 border rounded-lg text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Categories Filter */}
              <div>
                <label className="block text-sm font-medium mb-3">Categories</label>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {filterTypes.find(f => f.key === 'categories').options.map(option => (
                    <label key={option} className="flex items-center space-x-2 hover:bg-gray-50 p-1 rounded">
                      <input
                        type="checkbox"
                        checked={filters.categories?.includes(option) || false}
                        onChange={(e) => {
                          const newCategories = e.target.checked
                            ? [...(filters.categories || []), option]
                            : filters.categories?.filter(cat => cat !== option);
                          onFiltersChange({...filters, categories: newCategories});
                        }}
                        className="rounded border-gray-300"
                      />
                      <span className="text-sm">{option}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Type Filter */}
              <div>
                <label className="block text-sm font-medium mb-3">Type</label>
                <select
                  className="w-full p-2 border rounded-lg text-sm"
                  value={filters.type || 'all'}
                  onChange={(e) => onFiltersChange({...filters, type: e.target.value})}
                >
                  {filterTypes.find(f => f.key === 'type').options.map(option => (
                    <option key={option} value={option.toLowerCase()}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Clear All Button */}
            <div className="flex justify-end mt-4">
              <button
                onClick={() => onFiltersChange({
                  dateRange: null,
                  amountRange: null,
                  categories: [],
                  type: 'all'
                })}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
              >
                Clear All Filters
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}