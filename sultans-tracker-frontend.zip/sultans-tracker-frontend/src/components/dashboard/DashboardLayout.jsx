// SULTANS-TRACKER-FRONTEND/src/components/dashboard/DashboardLayout.jsx (CLEANED)
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion'; // Removed AnimatePresence
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { 
  Home, BarChart3, Target, Shield, CreditCard, User, LogOut, Clock,  Settings, DollarSign
} from 'lucide-react';
import MultiFilter from '../ui/MultiFilter';

// ✅ CORRECTED IMPORTS
import HomePage from '../../pages/HomePage';
import AnalyticsPage from './AnalyticsPage';
import BudgetsPage from './BudgetsPage';
import GoalsPage from './GoalsPage';
import SecurityAnalyticsPage from './SecurityAnalyticsPage';
import TransactionsMain from './TransactionsMain';
import DebtList from '../debt/DebtList'; // Add this import

// Removed TransactionsPage import since it's not used
import TransactionList from '../transactions/TransactionList';
import TransactionHeatmap from '../transactions/TransactionHeatmap';
import RecurringTransactions from './RecurringTransactions';
import CashCompass from './CashCompass';
import { useAuth } from '../../contexts/AuthContext';

// Clean, organized navigation
const navigationItems = [
  { name: 'Home', icon: Home, path: '/dashboard', component: HomePage },
  { name: 'Analytics', icon: BarChart3, path: '/dashboard/analytics', component: AnalyticsPage },
  { name: 'Budgets', icon: Target, path: '/dashboard/budgets', component: BudgetsPage },
  { name: 'Goals', icon: Target, path: '/dashboard/goals', component: GoalsPage },
  { name: 'Transactions', icon: CreditCard, path: '/dashboard/transactions', component: TransactionsMain },
  { name: 'Debt Management', icon: DollarSign, path: '/dashboard/debts', component: DebtList },
  { name: 'Security', icon: Shield, path: '/dashboard/security', component: SecurityAnalyticsPage },
];

export default function DashboardLayout() {
  const [filters, setFilters] = useState({
    categories: [],
    dateRange: {},
    amountRange: {},
    type: 'all'
  });
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [sessionTime, setSessionTime] = useState('');

  const { isAuthenticated, loading: authLoading, logout, updateLastActivity } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Get current active tab from URL
  const getActiveTabFromPath = () => {
    const currentPath = location.pathname;
    const navItem = navigationItems.find(item => currentPath === item.path);
    return navItem ? navItem.name : 'Home';
  };

  const [activeTab, setActiveTab] = useState(getActiveTabFromPath());

  // Update active tab when route changes
  useEffect(() => {
    setActiveTab(getActiveTabFromPath());
  }, [location.pathname]);

  // Calculate session time
  const updateSessionTime = () => {
    const loginTime = localStorage.getItem('loginTime');
    if (loginTime) {
      const timeDiff = Date.now() - parseInt(loginTime);
      const hours = Math.floor(timeDiff / (1000 * 60 * 60));
      const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
      setSessionTime(`${hours}h ${minutes}m`);
    }
  };

  // Safe activity update function
  const safeUpdateActivity = () => {
    if (updateLastActivity) {
      updateLastActivity();
    } else {
      // Fallback: manually update last activity
      localStorage.setItem('lastActivity', Date.now().toString());
    }
  };

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      console.log(' Not authenticated, redirecting to login');
      navigate('/login');
    }
  }, [isAuthenticated, authLoading, navigate]);

  // Update session timer and activity
  useEffect(() => {
    if (isAuthenticated) {
      updateSessionTime();
      const timer = setInterval(updateSessionTime, 60000); // Update every minute
      
      // Update activity on user interactions
      const updateActivity = () => {
        safeUpdateActivity();
      };

      const events = ['click', 'keypress', 'scroll'];
      events.forEach(event => {
        document.addEventListener(event, updateActivity);
      });

      return () => {
        clearInterval(timer);
        events.forEach(event => {
          document.removeEventListener(event, updateActivity);
        });
      };
    }
  }, [isAuthenticated]);

  const handleLogout = () => {
    logout('User manually logged out');
    setShowUserMenu(false);
  };

  const handleGoToMainPage = () => {
    navigate('/');
    setShowUserMenu(false);
  };

  const handleNavigation = (path) => {
    navigate(path);
  };

  // Show loading while checking authentication
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  // Don't render if not authenticated (will redirect)
  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <div className="flex items-center space-x-4">
              {/* Session Timer */}
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Clock size={16} />
                <span>Session: {sessionTime}</span>
              </div>
              
              {/* User Dropdown Menu */}
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <User size={20} />
                  <span>Account</span>
                </button>
                
                {/* Dropdown Menu */}
                {showUserMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border py-2 z-50"
                  >
                    <div className="px-4 py-2 text-xs text-gray-500 border-b">
                      Session: {sessionTime}
                    </div>
                    
                    <button
                      onClick={handleGoToMainPage}
                      className="w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 transition-colors"
                    >
                      <User size={16} />
                      <span>Go to Main Page</span>
                    </button>
                    
                    <div className="border-t my-1"></div>
                    
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center space-x-3 px-4 py-2 text-left text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <LogOut size={16} />
                      <span>Logout</span>
                    </button>
                  </motion.div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white min-h-screen border-r">
          <div className="p-4 space-y-2">
            {navigationItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavigation(item.path)}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                  activeTab === item.name ? 'bg-black text-white' : 'hover:bg-gray-100'
                }`}
              >
                <item.icon size={20} />
                <span>{item.name}</span>
              </button>
            ))}
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Multi-Filter System - Only show for transaction-related pages */}
          {(activeTab === 'Home' || activeTab === 'Transactions') && (
            <MultiFilter 
              filters={filters} 
              onFiltersChange={setFilters} 
              activeTab={activeTab}  
            />
          )}
          
          {/* Fixed Routes Configuration */}
          <Routes>
            {/* Main dashboard pages */}
            <Route path="/" element={<HomePage />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="/budgets" element={<BudgetsPage />} />
            <Route path="/goals" element={<GoalsPage />} />
            <Route path="/debts" element={<DebtList />} />
            <Route path="/security" element={<SecurityAnalyticsPage />} />
              {/* Transactions route with filters prop */}
            <Route 
            path="/transactions/*" 
            element={<TransactionsMain filters={filters} />} 
            />
            
            {/* Transaction sub-routes */}
            <Route path="/transactions/list" element={<TransactionList />} />
            <Route path="/transactions/heatmap" element={<TransactionHeatmap />} />
            <Route path="/transactions/recurring" element={<RecurringTransactions />} />
            <Route path="/transactions/cash-compass" element={<CashCompass />} />
          </Routes>
        </main>
      </div>

      {/* Close dropdown when clicking outside */}
      {showUserMenu && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowUserMenu(false)}
        />
      )}
    </div>
  );
}