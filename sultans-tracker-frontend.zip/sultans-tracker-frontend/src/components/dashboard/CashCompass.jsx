import { motion } from 'framer-motion';
import { useState, useMemo } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, Lightbulb, Target, Zap, Brain, Heart, Calendar } from 'lucide-react';
import { useTransactions } from '../../contexts/TransactionsContext';
import { useTransactionMood } from '../../contexts/TransactionMoodContext';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function CashCompass() {
  const { transactions, budgets, goals } = useTransactions();
  const { moods, analysis, getMoodInsights } = useTransactionMood();
  const [timeRange, setTimeRange] = useState('month');
  const navigate = useNavigate();

  // FIXED: Enhanced spending pattern analysis using moods from TransactionMoodContext
  const spendingPatterns = useMemo(() => {
    const patterns = {
      emotionalSpending: 0,
      plannedSpending: 0,
      impulsiveSpending: 0,
      weeklyPatterns: {},
      monthlyTrends: {}
    };

    // Use moods array from TransactionMoodContext instead of transaction.mood
    moods.forEach(mood => {
      const transaction = transactions.find(tx => tx.id === mood.transactionId);
      if (!transaction) return;

      const amount = Math.abs(transaction.amount);
      
      if (['stressed', 'bored', 'anxious'].includes(mood.mood)) {
        patterns.emotionalSpending += amount;
      } else if (mood.mood === 'planned') {
        patterns.plannedSpending += amount;
      } else if (mood.mood === 'impulsive') {
        patterns.impulsiveSpending += amount;
      }

      // Weekly patterns
      const dayOfWeek = new Date(transaction.date).getDay();
      patterns.weeklyPatterns[dayOfWeek] = (patterns.weeklyPatterns[dayOfWeek] || 0) + amount;
    });

    return patterns;
  }, [moods, transactions]);

  // Generate personalized recommendations
  const recommendations = useMemo(() => {
    const recs = [];
    
    // FIXED: Check if we have any emotional spending data
    if (spendingPatterns.emotionalSpending > spendingPatterns.plannedSpending && spendingPatterns.emotionalSpending > 0) {
      recs.push({
        type: 'behavioral',
        icon: Brain,
        title: 'Emotional Spending Detected',
        message: `You spend $${spendingPatterns.emotionalSpending.toFixed(2)} when feeling emotional vs $${spendingPatterns.plannedSpending.toFixed(2)} on planned purchases.`,
        action: 'Try the 24-hour rule: Wait a day before making emotional purchases'
      });
    }

    // Budget adherence analysis
    budgets.forEach(budget => {
      const spent = transactions
        .filter(tx => tx.type === 'expense' && tx.category === budget.category)
        .reduce((sum, tx) => sum + Math.abs(tx.amount), 0);
      
      if (spent > budget.limit * 0.8) {
        recs.push({
          type: 'budget',
          icon: Target,
          title: `${budget.category} Budget Alert`,
          message: `You've used ${((spent / budget.limit) * 100).toFixed(1)}% of your ${budget.category} budget.`,
          action: `Consider reducing ${budget.category} spending for the rest of the period`
        });
      }
    });

    // Savings rate analysis
    const totalIncome = transactions
      .filter(tx => tx.type === 'income')
      .reduce((sum, tx) => sum + tx.amount, 0);
    
    const totalExpenses = Math.abs(transactions
      .filter(tx => tx.type === 'expense')
      .reduce((sum, tx) => sum + tx.amount, 0));
    
    const savingsRate = totalIncome > 0 ? ((totalIncome - totalExpenses) / totalIncome) * 100 : 0;
    
    if (savingsRate < 20 && totalIncome > 0) {
      recs.push({
        type: 'savings',
        icon: TrendingUp,
        title: 'Savings Opportunity',
        message: `Your current savings rate is ${savingsRate.toFixed(1)}%. Aim for 20% for healthy finances.`,
        action: 'Consider automating savings transfers each pay period'
      });
    }

    return recs;
  }, [transactions, budgets, spendingPatterns]);

  return (
    <div className="space-y-6">
      <button
        onClick={() => navigate('/dashboard/transactions')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
      >
        <ArrowLeft size={16} />
        Back to Transactions
      </button>

      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Cash Compass</h2>
          <p className="text-gray-600">Intelligent financial guidance based on your behavior</p>
        </div>
        
        <select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value)}
          className="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
        >
          <option value="week">Last Week</option>
          <option value="month">Last Month</option>
          <option value="year">Last Year</option>
        </select>
      </div>

      {/* Behavioral Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg shadow-sm border">
          <div className="flex items-center space-x-3">
            <Brain className="text-purple-600" size={24} />
            <div>
              <p className="text-sm text-gray-600">Emotional Spending</p>
              <p className="text-xl font-bold text-purple-600">
                ${spendingPatterns.emotionalSpending.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border">
          <div className="flex items-center space-x-3">
            <Calendar className="text-green-600" size={24} />
            <div>
              <p className="text-sm text-gray-600">Planned Spending</p>
              <p className="text-xl font-bold text-green-600">
                ${spendingPatterns.plannedSpending.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border">
          <div className="flex items-center space-x-3">
            <Zap className="text-orange-600" size={24} />
            <div>
              <p className="text-sm text-gray-600">Impulsive Spending</p>
              <p className="text-xl font-bold text-orange-600">
                ${spendingPatterns.impulsiveSpending.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm border">
          <div className="flex items-center space-x-3">
            <Lightbulb className="text-blue-600" size={24} />
            <div>
              <p className="text-sm text-gray-600">Smart Suggestions</p>
              <p className="text-xl font-bold text-blue-600">
                {recommendations.length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Personalized Recommendations */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Personalized Guidance</h3>
        
        {recommendations.length === 0 ? (
          <div className="bg-white p-6 rounded-lg shadow-sm border text-center">
            <Lightbulb className="mx-auto text-gray-400 mb-2" size={32} />
            <p className="text-gray-600">Your financial habits look great!</p>
            <p className="text-sm text-gray-500">Keep up the good work and continue tracking your moods.</p>
          </div>
        ) : (
          recommendations.map((rec, index) => {
            const Icon = rec.icon;
            const getBorderColor = (type) => {
              switch (type) {
                case 'behavioral': return 'border-purple-200 bg-purple-50';
                case 'budget': return 'border-red-200 bg-red-50';
                case 'savings': return 'border-green-200 bg-green-50';
                default: return 'border-blue-200 bg-blue-50';
              }
            };

            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-4 rounded-lg border-l-4 ${getBorderColor(rec.type)}`}
              >
                <div className="flex items-start space-x-3">
                  <Icon className={`mt-1 ${rec.type === 'behavioral' ? 'text-purple-600' : rec.type === 'budget' ? 'text-red-600' : 'text-green-600'}`} size={20} />
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-800">{rec.title}</h4>
                    <p className="text-gray-600 mt-1">{rec.message}</p>
                    <div className="mt-3 p-3 bg-white rounded border">
                      <p className="text-sm font-medium text-gray-700">💡 Suggested Action:</p>
                      <p className="text-sm text-gray-600 mt-1">{rec.action}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Mood Analysis Section */}
      {analysis && analysis.totalTracked > 0 && (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-lg font-semibold mb-4">Spending Psychology Analysis</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Mood-Spending Correlation - FIXED width and overflow */}
            <div>
              <h4 className="font-medium mb-3">Mood vs Spending</h4>
              <div className="space-y-3">
                {Object.entries(analysis.averageSpendingByMood || {}).map(([mood, data]) => (
                  <div key={mood} className="flex items-center justify-between">
                    <span className="capitalize text-sm min-w-20">{mood}</span>
                    <div className="flex items-center space-x-2 flex-1 max-w-48">
                      <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                        <div 
                          className="h-2 rounded-full transition-all duration-500"
                          style={{ 
                            width: `${Math.min((data.average / 100) * 100, 100)}%`,
                            backgroundColor: mood === 'stressed' ? '#ef4444' : 
                                           mood === 'happy' ? '#10b981' :
                                           mood === 'bored' ? '#f59e0b' :
                                           mood === 'planned' ? '#3b82f6' : '#8b5cf6'
                          }}
                        ></div>
                      </div>
                      <span className="text-xs font-medium w-12 text-right">${data.average.toFixed(0)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Behavioral Patterns */}
            <div>
              <h4 className="font-medium mb-3">Behavioral Patterns</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Emotional vs Planned Ratio</span>
                  <span className="text-sm font-medium">
                    {spendingPatterns.plannedSpending > 0 
                      ? `${((spendingPatterns.emotionalSpending / spendingPatterns.plannedSpending) * 100).toFixed(1)}%`
                      : '0%'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Highest Spending Day</span>
                  <span className="text-sm font-medium">
                    {Object.keys(spendingPatterns.weeklyPatterns).length > 0
                      ? (() => {
                          const highestDay = Object.entries(spendingPatterns.weeklyPatterns)
                            .reduce((max, [day, amount]) => amount > max.amount ? { day, amount } : max, { day: 0, amount: 0 });
                          const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                          return dayNames[parseInt(highestDay.day)] || 'Unknown';
                        })()
                      : 'No data'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}