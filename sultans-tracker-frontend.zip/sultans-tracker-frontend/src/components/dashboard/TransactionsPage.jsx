import { motion } from 'framer-motion';
import { 
  Plus, 
  Filter, 
  Search, 
  Trash2, 
  Edit, 
  AlertTriangle, 
  Calendar, 
  BarChart3  
} from 'lucide-react';
import { useState } from 'react';
import { useTransactions } from '../../contexts/TransactionsContext';
import TransactionMoodTracker from './TransactionMoodTracker'; 
import CalendarView from './CalendarView'; 
import MultiFilter from '../ui/MultiFilter';


export default function TransactionsPage({ filters }) {
  const { 
    transactions, 
    loading, 
    error, 
    deleteTransaction, 
    addTransaction, 
    defaultTransaction 
  } = useTransactions();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTransaction, setNewTransaction] = useState(defaultTransaction);
  const [activeView, setActiveView] = useState('list');
  const [localFilters, setLocalFilters] = useState({
    dateRange: null,
    amountRange: null,
    categories: [],
    type: 'all'
  });

  // ✅ SAFETY CHECK: Create safe filters with default values
  const safeFilters = {
    categories: filters?.categories || [],
    type: filters?.type || 'all',
    dateRange: filters?.dateRange || null,
    amountRange: filters?.amountRange || null
  };

  const handleAddTransaction = async (e) => {
    e.preventDefault();
    const result = await addTransaction(newTransaction);
    
    if (result.success) {
      setShowAddForm(false);
      setNewTransaction(defaultTransaction);
      
      if (result.warning) {
        alert(`Fraud Detection Alert: ${result.warning}`);
      }
    } else {
      if (result.error && result.error.includes('exceed budget')) {
        const budgetError = `


 BUDGET LIMIT EXCEEDED

Category: ${result.budgetCategory}
Current Spent: $${result.currentSpent?.toFixed(2) || '0.00'}
Budget Limit: $${result.budgetLimit?.toFixed(2) || '0.00'}
This Transaction: $${result.transactionAmount?.toFixed(2) || '0.00'}
Would Be Total: $${result.wouldBeTotal?.toFixed(2) || '0.00'}

${result.suggestion ? `Suggestion: ${result.suggestion}` : 'Please reduce the amount or choose a different category.'}
        `;
        alert(budgetError);
      } else {
        alert(`Error: ${result.error}`);
      }
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this transaction?')) {
      const result = await deleteTransaction(id);
      if (!result.success) {
        alert(`Error: ${result.error}`);
      }
    }
  };

  // ✅ UPDATED: Filter transactions using safeFilters instead of filters
  const filteredTransactions = transactions.filter(tx => {
    // Category filter
    if (safeFilters.categories.length > 0 && !safeFilters.categories.includes(tx.category)) {
      return false;
    }
    
    // Type filter
    if (safeFilters.type !== 'all' && tx.type !== safeFilters.type) {
      return false;
    }
    
    // Date range filter
    if (safeFilters.dateRange) {
      const txDate = new Date(tx.date);
      
      if (safeFilters.dateRange.start) {
        const startDate = new Date(safeFilters.dateRange.start);
        if (txDate < startDate) return false;
      }
      
      if (safeFilters.dateRange.end) {
        const endDate = new Date(safeFilters.dateRange.end);
        endDate.setHours(23, 59, 59, 999); // End of day
        if (txDate > endDate) return false;
      }
    }
    
    // Amount range filter
    if (safeFilters.amountRange) {
      const txAmount = Math.abs(tx.amount);
      
      if (safeFilters.amountRange.min && txAmount < parseFloat(safeFilters.amountRange.min)) {
        return false;
      }
      
      if (safeFilters.amountRange.max && txAmount > parseFloat(safeFilters.amountRange.max)) {
        return false;
      }
    }
    
    return true;
  }); 

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

 return (
    <div className="space-y-6">
      {/* Header with View Toggle */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Transactions</h2>
        <div className="flex items-center space-x-3">
          {/* View Toggle Buttons */}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setActiveView('list')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                activeView === 'list' 
                  ? 'bg-white text-black shadow-sm' 
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <BarChart3 size={16} className="inline mr-1" />
              List
            </button>
            <button
              onClick={() => setActiveView('calendar')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                activeView === 'calendar' 
                  ? 'bg-white text-black shadow-sm' 
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Calendar size={16} className="inline mr-1" />
              Calendar
            </button>
          </div>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowAddForm(true)}
            className="flex items-center space-x-2 bg-black text-white px-4 py-2 rounded-lg"
          >
            <Plus size={20} />
            <span>Add Transaction</span>
          </motion.button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      {/* MultiFilter Component */}
      <MultiFilter 
        filters={localFilters}
        onFiltersChange={setLocalFilters}
        activeTab="Transactions"
      />

      {/* Add Transaction Form */}
      {showAddForm && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-lg shadow-sm border"
        >
          <h3 className="text-lg font-semibold mb-4">Add New Transaction</h3>
          <form onSubmit={handleAddTransaction} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Type</label>
                <select
                  value={newTransaction.type}
                  onChange={(e) => setNewTransaction({...newTransaction, type: e.target.value})}
                  className="w-full p-2 border rounded-lg"
                >
                  <option value="income">Income</option>
                  <option value="expense">Expense</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={newTransaction.amount}
                  onChange={(e) => setNewTransaction({...newTransaction, amount: e.target.value})}
                  className="w-full p-2 border rounded-lg"
                  placeholder="0.00"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Category</label>
                <select
                  value={newTransaction.category}
                  onChange={(e) => setNewTransaction({...newTransaction, category: e.target.value})}
                  className="w-full p-2 border rounded-lg"
                >
                  <option value="Food">Food</option>
                  <option value="Travel">Travel</option>
                  <option value="Entertainment">Entertainment</option>
                  <option value="Rent">Rent</option>
                  <option value="Utilities">Utilities</option>
                  <option value="Shopping">Shopping</option>
                  <option value="Healthcare">Healthcare</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Date</label>
                <input
                  type="date"
                  value={newTransaction.date}
                  onChange={(e) => {
                    const selectedDate = new Date(e.target.value);
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    
                    if (selectedDate > today) {
                      alert('Future dates are not allowed. Please select today or a past date.');
                      return;
                    }
                    
                    setNewTransaction({...newTransaction, date: e.target.value});
                  }}
                  max={new Date().toISOString().split('T')[0]}
                  className="w-full p-2 border rounded-lg"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  Select today or a past date (future dates not allowed)
                </p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Description</label>
              <input
                type="text"
                value={newTransaction.description}
                onChange={(e) => setNewTransaction({...newTransaction, description: e.target.value})}
                className="w-full p-2 border rounded-lg"
                placeholder="Transaction description"
              />
            </div>

            <div className="flex space-x-3">
              <button
                type="submit"
                className="bg-black text-white px-4 py-2 rounded-lg"
              >
                Add Transaction
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg"
              >
                Cancel
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Conditional Rendering based on Active View */}
      {activeView === 'calendar' ? (
        <CalendarView />
      ) : (
        /* Transactions List View */
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-4 border-b">
            <div className="flex items-center space-x-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search transactions..."
                  className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                />
              </div>
            </div>
          </div>

          <div className="divide-y">
            {filteredTransactions.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                No transactions found. Add your first transaction to get started.
              </div>
            ) : (
              filteredTransactions.map((transaction, index) => (
                <motion.div
                  key={transaction.id || `transaction-${index}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 flex justify-between items-start hover:bg-gray-50 group"
                >
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className="font-medium">{transaction.description || 'No description'}</h3>
                            {transaction.flagged && (
                              <AlertTriangle size={16} className="text-red-500" title="Flagged for review" />
                            )}
                          </div>
                          <p className="text-sm text-gray-500">
                            {transaction.category} • {new Date(transaction.date).toLocaleDateString()}
                            {transaction.fraudReason && (
                              <span className="text-red-500 ml-2">⚠️ Suspicious</span>
                            )}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <div className={`text-lg font-semibold ${
                          transaction.amount >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {transaction.amount >= 0 ? '+' : ''}${Math.abs(transaction.amount).toFixed(2)}
                        </div>
                        
                        <button
                          onClick={() => handleDelete(transaction.id)}
                          className="opacity-0 group-hover:opacity-100 p-1 hover:bg-red-50 rounded transition-all"
                          title="Delete transaction"
                        >
                          <Trash2 size={16} className="text-red-500" />
                        </button>
                      </div>
                    </div>
                    
                    {/* Mood Tracker - ADD THIS SECTION */}
                    <div className="mt-2">
                      <TransactionMoodTracker 
                        transaction={transaction}
                        onMoodAdded={(mood) => {
                          console.log('Mood added:', mood);
                          // You could add a toast notification here
                        }}
                      />
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
} 