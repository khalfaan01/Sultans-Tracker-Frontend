// src/components/dashboard/AnalyticsPage.jsx
import { motion } from 'framer-motion';
import { Pie, Bar, Line } from 'react-chartjs-2';
import { 
  Chart as ChartJS, 
  ArcElement, 
  Tooltip, 
  Legend, 
  CategoryScale, 
  LinearScale, 
  BarElement,
  LineElement,
  PointElement,
  Title, 
  Filler
} from 'chart.js';
import { useTransactions } from '../../contexts/TransactionsContext';
import { useState, useEffect } from 'react';
import { AnalyticsService } from '../../services/analyticsService';
import IncomeExpenseChart from './IncomeExpenseChart';
import CashFlowRadar from './CashFlowRadar';
import FinanceHealthScore from './FinanceHealthScore';
import SmartSuggestions from './SmartSuggestions';

// Register ChartJS components
ChartJS.register(
  ArcElement, Tooltip, Legend, CategoryScale, LinearScale, 
  BarElement, LineElement, PointElement, Title, Filler
);

export default function AnalyticsPage({ filters }) {
  const { getDashboardStats, loading, transactions, budgets, goals } = useTransactions();
  const [enhancedAnalytics, setEnhancedAnalytics] = useState(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(true);
  const [timeframe, setTimeframe] = useState('monthly');
  const [activeTab, setActiveTab] = useState('overview');

  const stats = getDashboardStats();

  useEffect(() => {
  const loadEnhancedAnalytics = async () => {
    try {
      setAnalyticsLoading(true);
      console.log('🔄 Loading enhanced analytics...');
      const analytics = await AnalyticsService.getEnhancedAnalytics(timeframe);
      console.log('✅ Enhanced analytics loaded successfully');
      setEnhancedAnalytics(analytics);
    } catch (error) {
      console.error('❌ Failed to load enhanced analytics:', error);
      
      // Show user-friendly error message
      if (error.message.includes('endpoint not available') || error.message.includes('404')) {
        console.error('Backend analytics endpoints are not set up yet.');
        // You can set a state to show a message to the user
        // setAnalyticsError('Analytics features are currently being set up. Please check back later.');
      } else if (error.message.includes('Authentication')) {
        console.error('Authentication issue with analytics');
        // setAnalyticsError('Please log in to view analytics.');
      }
      
      // Don't set enhancedAnalytics - let components handle null/undefined data
      setEnhancedAnalytics(null);
    } finally {
      setAnalyticsLoading(false);
    }
  };

  loadEnhancedAnalytics();
}, [timeframe]);

  // Enhanced financial stats with forecasting
  const financialStats = [
    { 
      title: 'Total Balance', 
      value: `$${stats.balance.toFixed(2)}`,
      trend: enhancedAnalytics?.cashFlowAnalysis?.trends?.netGrowth || 0
    },
    { 
      title: 'Projected 30-day', 
      value: enhancedAnalytics ? `$${enhancedAnalytics.spendingForecast?.dailyProjections?.reduce((sum, day) => sum + day.projectedAmount, 0).toFixed(2)}` : 'Calculating...',
      subtitle: 'Spending Forecast'
    },
    { 
      title: 'Income Diversity', 
      value: enhancedAnalytics ? `${enhancedAnalytics.incomeBreakdown?.diversityScore?.toFixed(0)}%` : 'N/A',
      subtitle: 'Stream Variety'
    },
  ];

  // Timeframe selector
  const TimeframeSelector = () => (
    <div className="flex space-x-2 mb-6">
      {['weekly', 'monthly', 'yearly'].map((frame) => (
        <button
          key={frame}
          onClick={() => setTimeframe(frame)}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            timeframe === frame
              ? 'bg-black text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {frame.charAt(0).toUpperCase() + frame.slice(1)}
        </button>
      ))}
    </div>
  );

  // Tab selector
  const TabSelector = () => (
    <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-6">
      {[
        { id: 'overview', label: 'Overview' },
        { id: 'cashflow', label: 'Cash Flow' },
        { id: 'income', label: 'Income Streams' },
        { id: 'forecast', label: 'Forecast' }
      ].map((tab) => (
        <button
          key={tab.id}
          onClick={() => setActiveTab(tab.id)}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === tab.id
              ? 'bg-white text-gray-900 shadow-sm'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );

  if (loading || analyticsLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Advanced Analytics</h2>
        <TimeframeSelector />
      </div>

      <TabSelector />

      {/* Financial Overview Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        {financialStats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white p-6 rounded-lg shadow-sm border"
          >
            <h3 className="text-gray-600 text-sm font-medium">{stat.title}</h3>
            <p className="text-2xl font-bold mt-2">{stat.value}</p>
            {stat.subtitle && (
              <p className="text-sm text-gray-500 mt-1">{stat.subtitle}</p>
            )}
            {stat.trend !== undefined && (
              <p className={`text-sm mt-1 ${
                stat.trend >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {stat.trend >= 0 ? '↗' : '↘'} {Math.abs(stat.trend).toFixed(1)}%
              </p>
            )}
          </motion.div>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <OverviewTab 
          stats={stats} 
          enhancedAnalytics={enhancedAnalytics}
          timeframe={timeframe}
          transactions={transactions}
          budgets={budgets}
          goals={goals}
        />
      )}

      {activeTab === 'cashflow' && (
        <CashFlowTab 
          enhancedAnalytics={enhancedAnalytics}
          timeframe={timeframe}
          transactions={transactions}
        />
      )}

      {activeTab === 'income' && (
        <IncomeTab 
          enhancedAnalytics={enhancedAnalytics}
        />
      )}

      {activeTab === 'forecast' && (
        <ForecastTab 
          enhancedAnalytics={enhancedAnalytics}
        />
      )}
    </div>
  );
}

// Overview Tab Component
const OverviewTab = ({ stats, enhancedAnalytics, timeframe, transactions, budgets, goals }) => (
  <div className="space-y-6">
    {/* Enhanced IncomeExpenseChart */}
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <IncomeExpenseChart 
        data={stats.monthlyData} 
        timeframe={timeframe}
        enhancedData={enhancedAnalytics}
      />
    </motion.div>

    {/* Existing Charts - Enhanced */}
    <div className="grid md:grid-cols-2 gap-6">
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-white p-6 rounded-lg shadow-sm border"
      >
        <h3 className="text-lg font-semibold mb-4">Spending by Category</h3>
        <div className="h-64">
          {Object.keys(stats.categoryBreakdown).length > 0 ? (
            <Pie 
              data={{
                labels: Object.keys(stats.categoryBreakdown),
                datasets: [
                  {
                    data: Object.values(stats.categoryBreakdown),
                    backgroundColor: [
                      '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', 
                      '#9966FF', '#FF9F40', '#FF6384', '#C9CBCF'
                    ],
                  },
                ],
              }} 
              options={{ 
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'bottom'
                  }
                }
              }} 
            />
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500">
              No spending data available
            </div>
          )}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-white p-6 rounded-lg shadow-sm border"
      >
        <h3 className="text-lg font-semibold mb-4">Income vs Expenses Trend</h3>
        <div className="h-64">
          {stats.monthlyData.length > 0 ? (
            <Bar 
              data={{
                labels: stats.monthlyData.map(data => data.month),
                datasets: [
                  {
                    label: 'Income',
                    data: stats.monthlyData.map(data => data.income),
                    backgroundColor: '#4BC0C0',
                  },
                  {
                    label: 'Expenses',
                    data: stats.monthlyData.map(data => data.expenses),
                    backgroundColor: '#FF6384',
                  },
                ],
              }} 
              options={{ 
                maintainAspectRatio: false,
                responsive: true,
                scales: {
                  x: {
                    grid: {
                      display: false
                    }
                  },
                  y: {
                    beginAtZero: true
                  }
                }
              }} 
            />
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500">
              No transaction data available
            </div>
          )}
        </div>
      </motion.div>
    </div>

    {/* Enhanced Health Score and Smart Suggestions */}
    <div className="grid md:grid-cols-2 gap-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <FinanceHealthScore 
          transactions={transactions} 
          budgets={budgets} 
          goals={goals} 
          timeframe={timeframe}
          enhancedData={enhancedAnalytics}
        />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <SmartSuggestions 
          transactions={transactions}
          budgets={budgets}
          categoryBreakdown={stats.categoryBreakdown}
          timeframe={timeframe}
          enhancedData={enhancedAnalytics}
        />
      </motion.div>
    </div>
  </div>
);

// Cash Flow Tab Component
const CashFlowTab = ({ enhancedAnalytics, timeframe, transactions }) => (
  <div className="space-y-6">
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <CashFlowRadar 
        transactions={transactions}
        timeframe={timeframe}
        enhancedData={enhancedAnalytics}
      />
    </motion.div>

    {/* Enhanced Cash Flow Chart */}
    {enhancedAnalytics?.cashFlowAnalysis && (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-6 rounded-lg shadow-sm border"
      >
        <h3 className="text-lg font-semibold mb-4">
          Detailed Cash Flow Analysis ({timeframe})
        </h3>
        <div className="h-80">
          <Line
            data={{
              labels: enhancedAnalytics.cashFlowAnalysis.periods.map(p => 
                timeframe === 'daily' ? p.date.split('-').slice(1).join('/') : p.period
              ),
              datasets: [
                {
                  label: 'Income',
                  data: enhancedAnalytics.cashFlowAnalysis.periods.map(p => p.income),
                  borderColor: '#10B981',
                  backgroundColor: 'rgba(16, 185, 129, 0.1)',
                  fill: true,
                  tension: 0.4
                },
                {
                  label: 'Expenses',
                  data: enhancedAnalytics.cashFlowAnalysis.periods.map(p => p.expenses),
                  borderColor: '#EF4444',
                  backgroundColor: 'rgba(239, 68, 68, 0.1)',
                  fill: true,
                  tension: 0.4
                },
                {
                  label: 'Net Cash Flow',
                  data: enhancedAnalytics.cashFlowAnalysis.periods.map(p => p.net),
                  borderColor: '#3B82F6',
                  backgroundColor: 'rgba(59, 130, 246, 0.1)',
                  fill: true,
                  tension: 0.4
                }
              ]
            }}
            options={{
              maintainAspectRatio: false,
              responsive: true,
              interaction: {
                mode: 'index',
                intersect: false
              },
              scales: {
                x: {
                  grid: {
                    display: false
                  }
                },
                y: {
                  beginAtZero: true
                }
              }
            }}
          />
        </div>
        
        {/* Cash Flow Insights */}
        {enhancedAnalytics.cashFlowAnalysis.insights.length > 0 && (
          <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h4 className="font-semibold text-yellow-800 mb-2">Cash Flow Insights</h4>
            <div className="space-y-2">
              {enhancedAnalytics.cashFlowAnalysis.insights.map((insight, index) => (
                <div key={index} className="flex items-start space-x-2 text-sm text-yellow-700">
                  <span>•</span>
                  <span>{insight.message} - {insight.recommendation}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </motion.div>
    )}
  </div>
);

// Income Tab Component
const IncomeTab = ({ enhancedAnalytics }) => (
  <div className="space-y-6">
    {enhancedAnalytics?.incomeBreakdown && (
      <>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-lg shadow-sm border"
        >
          <h3 className="text-lg font-semibold mb-4">Income Stream Breakdown</h3>
          <div className="h-64">
            <Pie
              data={{
                labels: Object.keys(enhancedAnalytics.incomeBreakdown.streams),
                datasets: [
                  {
                    data: Object.values(enhancedAnalytics.incomeBreakdown.streams).map(s => s.percentage),
                    backgroundColor: [
                      '#10B981', '#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4'
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                  }
                ]
              }}
              options={{
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'bottom'
                  },
                  tooltip: {
                    callbacks: {
                      label: function(context) {
                        const stream = Object.values(enhancedAnalytics.incomeBreakdown.streams)[context.dataIndex];
                        return `${context.label}: ${stream.percentage.toFixed(1)}% ($${stream.total.toFixed(2)})`;
                      }
                    }
                  }
                }
              }}
            />
          </div>
        </motion.div>

        {/* Income Stream Details */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-lg shadow-sm border"
        >
          <h3 className="text-lg font-semibold mb-4">Income Stream Analysis</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-900">
                ${enhancedAnalytics.incomeBreakdown.totalIncome.toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Total Income</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-900">
                {enhancedAnalytics.incomeBreakdown.streamCount}
              </div>
              <div className="text-sm text-gray-600">Income Streams</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-900">
                {enhancedAnalytics.incomeBreakdown.primaryStream}
              </div>
              <div className="text-sm text-gray-600">Primary Source</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-900">
                {enhancedAnalytics.incomeBreakdown.diversityScore.toFixed(0)}%
              </div>
              <div className="text-sm text-gray-600">Diversity Score</div>
            </div>
          </div>

          {/* Income Stream Recommendations */}
          {enhancedAnalytics.incomeBreakdown.diversityScore < 50 && (
            <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-semibold text-blue-800 mb-2">Diversity Recommendation</h4>
              <p className="text-sm text-blue-700">
                Consider diversifying your income streams. Having multiple sources of income 
                provides better financial stability.
              </p>
            </div>
          )}
        </motion.div>
      </>
    )}
  </div>
);

// Forecast Tab Component
const ForecastTab = ({ enhancedAnalytics }) => (
  <div className="space-y-6">
    {enhancedAnalytics?.spendingForecast && (
      <>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-lg shadow-sm border"
        >
          <h3 className="text-lg font-semibold mb-4">
            30-Day Spending Forecast 
            <span className={`ml-2 text-sm font-normal px-2 py-1 rounded-full ${
              enhancedAnalytics.spendingForecast.confidence === 'high' 
                ? 'bg-green-100 text-green-800'
                : enhancedAnalytics.spendingForecast.confidence === 'medium'
                ? 'bg-yellow-100 text-yellow-800'
                : 'bg-red-100 text-red-800'
            }`}>
              {enhancedAnalytics.spendingForecast.confidence} confidence
            </span>
          </h3>
          <div className="h-80">
            <Line
              data={{
                labels: enhancedAnalytics.spendingForecast.dailyProjections.map(p => 
                  new Date(p.date).getDate()
                ),
                datasets: [
                  {
                    label: 'Projected Daily Spending',
                    data: enhancedAnalytics.spendingForecast.dailyProjections.map(p => p.projectedAmount),
                    borderColor: '#8B5CF6',
                    backgroundColor: 'rgba(139, 92, 246, 0.1)',
                    fill: true,
                    tension: 0.4
                  }
                ]
              }}
              options={{
                maintainAspectRatio: false,
                responsive: true,
                scales: {
                  x: {
                    title: {
                      display: true,
                      text: 'Day of Month'
                    },
                    grid: {
                      display: false
                    }
                  },
                  y: {
                    title: {
                      display: true,
                      text: 'Amount ($)'
                    },
                    beginAtZero: true
                  }
                }
              }}
            />
          </div>
        </motion.div>

        {/* Forecast Insights */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Risk Factors */}
          {enhancedAnalytics.spendingForecast.riskFactors.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-6 rounded-lg shadow-sm border"
            >
              <h3 className="text-lg font-semibold mb-4 text-red-600">Risk Factors</h3>
              <div className="space-y-3">
                {enhancedAnalytics.spendingForecast.riskFactors.map((risk, index) => (
                  <div key={index} className="flex items-start space-x-2 text-sm text-red-700">
                    <span className="text-red-500">⚠</span>
                    <span>{risk}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Recommendations */}
          {enhancedAnalytics.spendingForecast.recommendations.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-6 rounded-lg shadow-sm border"
            >
              <h3 className="text-lg font-semibold mb-4 text-blue-600">Recommendations</h3>
              <div className="space-y-3">
                {enhancedAnalytics.spendingForecast.recommendations.map((rec, index) => (
                  <div key={index} className="flex items-start space-x-2 text-sm text-blue-700">
                    <span className="text-blue-500">💡</span>
                    <div>
                      <div className="font-medium">{rec.message}</div>
                      <div className="text-blue-600 mt-1">Action: {rec.action}</div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </>
    )}
  </div>
);

