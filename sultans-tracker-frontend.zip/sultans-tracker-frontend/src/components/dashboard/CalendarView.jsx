import { motion } from 'framer-motion';
import { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight, TrendingUp, TrendingDown, ArrowLeft } from 'lucide-react';
import { useTransactions } from '../../contexts/TransactionsContext';
import { useNavigate } from 'react-router-dom';

export default function CalendarView() {
  const { transactions } = useTransactions();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const navigate = useNavigate();

  // Get transactions for the current month
  const monthlyTransactions = useMemo(() => {
    const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    
    return transactions.filter(tx => {
      const txDate = new Date(tx.date);
      return txDate >= startOfMonth && txDate <= endOfMonth;
    });
  }, [transactions, currentDate]);

  // Group transactions by date
  const transactionsByDate = useMemo(() => {
    const grouped = {};
    monthlyTransactions.forEach(tx => {
      const dateStr = new Date(tx.date).toDateString();
      if (!grouped[dateStr]) {
        grouped[dateStr] = [];
      }
      grouped[dateStr].push(tx);
    });
    return grouped;
  }, [monthlyTransactions]);

  // Calculate daily totals
  const dailyTotals = useMemo(() => {
    const totals = {};
    Object.entries(transactionsByDate).forEach(([dateStr, txs]) => {
      const total = txs.reduce((sum, tx) => sum + tx.amount, 0);
      totals[dateStr] = total;
    });
    return totals;
  }, [transactionsByDate]);

  // Generate calendar days
  const calendarDays = useMemo(() => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDay = firstDay.getDay();
    const daysInMonth = lastDay.getDate();
    
    const days = [];
    
    // Add empty days for start of month
    for (let i = 0; i < startDay; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const dateStr = date.toDateString();
      const dayTransactions = transactionsByDate[dateStr] || [];
      const dailyTotal = dailyTotals[dateStr] || 0;
      
      days.push({
        date,
        day,
        transactions: dayTransactions,
        total: dailyTotal,
        isToday: date.toDateString() === new Date().toDateString()
      });
    }
    
    return days;
  }, [currentDate, transactionsByDate, dailyTotals]);

  // Navigation
  const navigateMonth = (direction) => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      newDate.setMonth(prev.getMonth() + direction);
      return newDate;
    });
  };

  // Get spending intensity color
  const getSpendingColor = (amount) => {
    if (amount === 0) return 'bg-gray-100';
    if (amount > 0) return 'bg-green-100 border-green-300';
    
    const intensity = Math.min(Math.abs(amount) / 100, 1); // Scale to 0-1
    if (intensity < 0.3) return 'bg-red-50 border-red-200';
    if (intensity < 0.6) return 'bg-red-100 border-red-300';
    return 'bg-red-200 border-red-400';
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="space-y-6">
      

      <div className="bg-white rounded-lg shadow-sm border p-6">
        {/* Calendar Header - NO BACK BUTTON HERE */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Spending Calendar</h2>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigateMonth(-1)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronLeft size={20} />
            </button>
            <span className="text-lg font-semibold min-w-32 text-center">
              {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
            </span>
            <button
              onClick={() => navigateMonth(1)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>

        {/* Day Headers */}
        <div className="grid grid-cols-7 gap-1 mb-4">
          {dayNames.map(day => (
            <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1">
          {calendarDays.map((day, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: day ? 1.05 : 1 }}
              onClick={() => day && setSelectedDate(day)}
              className={`
                min-h-20 p-1 border rounded-lg cursor-pointer transition-all
                ${day ? getSpendingColor(day.total) : ''}
                ${day?.isToday ? 'ring-2 ring-blue-500' : ''}
                ${selectedDate?.date.toDateString() === day?.date.toDateString() ? 'ring-2 ring-black' : ''}
              `}
            >
              {day && (
                <div className="h-full flex flex-col">
                  {/* Date Number */}
                  <div className={`text-sm font-medium ${
                    day.isToday ? 'text-blue-600' : 'text-gray-700'
                  }`}>
                    {day.day}
                  </div>
                  
                  {/* Spending Summary */}
                  <div className="flex-1 flex flex-col justify-center items-center space-y-1">
                    {day.total !== 0 && (
                      <>
                        <div className={`flex items-center space-x-1 text-xs ${
                          day.total > 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {day.total > 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                          <span>${Math.abs(day.total).toFixed(0)}</span>
                        </div>
                        {day.transactions.length > 0 && (
                          <div className="text-xs text-gray-500">
                            {day.transactions.length} tx
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Selected Date Details */}
        {selectedDate && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 p-4 bg-gray-50 rounded-lg"
          >
            <h3 className="font-semibold mb-3">
              {selectedDate.date.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </h3>
            
            {selectedDate.transactions.length === 0 ? (
              <p className="text-gray-500">No transactions on this day</p>
            ) : (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Net Flow:</span>
                  <span className={`font-medium ${
                    selectedDate.total >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {selectedDate.total >= 0 ? '+' : ''}${selectedDate.total.toFixed(2)}
                  </span>
                </div>
                
                <div className="space-y-1 max-h-40 overflow-y-auto">
                  {selectedDate.transactions.map(tx => (
                    <div key={tx.id} className="flex justify-between items-center text-sm p-2 bg-white rounded">
                      <div>
                        <span className="font-medium">{tx.category}</span>
                        {tx.description && (
                          <span className="text-gray-500 ml-2">- {tx.description}</span>
                        )}
                      </div>
                      <span className={tx.amount >= 0 ? 'text-green-600' : 'text-red-600'}>
                        {tx.amount >= 0 ? '+' : ''}${Math.abs(tx.amount).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {/* Legend */}
        <div className="mt-4 flex items-center justify-center space-x-4 text-xs text-gray-600">
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-red-50 border border-red-200 rounded"></div>
            <span>Low Spending</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-red-200 border border-red-400 rounded"></div>
            <span>High Spending</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-green-100 border border-green-300 rounded"></div>
            <span>Income</span>
          </div>
        </div>
      </div>
    </div>
  );
}