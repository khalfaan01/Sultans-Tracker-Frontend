// src/components/dashboard/IncomeExpenseChart.jsx
import { useMemo } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

const IncomeExpenseChart = ({ data, timeframe }) => {
  const chartData = useMemo(() => {
    if (!data || data.length === 0) {
      // Return sample data structure for empty state
      return { 
        labels: [], 
        income: [], 
        expenses: [],
        net: [] 
      };
    }

    // Sort data by date
    const sortedData = [...data].sort((a, b) => {
      const dateA = new Date(a.month);
      const dateB = new Date(b.month);
      return dateA - dateB;
    });

    return {
      labels: sortedData.map(item => {
        const date = new Date(item.month);
        return timeframe === 'monthly' 
          ? date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
          : date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
      }),
      income: sortedData.map(item => item.income),
      expenses: sortedData.map(item => item.expenses),
      net: sortedData.map(item => item.income - item.expenses)
    };
  }, [data, timeframe]);

  // Calculate statistics for the header
  const stats = useMemo(() => {
    const totalIncome = chartData.income.reduce((sum, income) => sum + income, 0);
    const totalExpenses = chartData.expenses.reduce((sum, expense) => sum + expense, 0);
    const netCashFlow = totalIncome - totalExpenses;
    const growthRate = chartData.income.length > 1 
      ? ((chartData.income[chartData.income.length - 1] - chartData.income[0]) / chartData.income[0] * 100) 
      : 0;

    return {
      totalIncome,
      totalExpenses,
      netCashFlow,
      growthRate
    };
  }, [chartData]);

  // Calculate max value for scaling
  const maxValue = useMemo(() => {
    const allValues = [...chartData.income, ...chartData.expenses];
    const max = Math.max(...allValues, 100); // Minimum max of 100 for better visualization
    return max === 0 ? 100 : max; // Prevent division by zero
  }, [chartData]);

  if (!data || data.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Income vs Expenses</h3>
          <div className="text-sm text-gray-500">No data available</div>
        </div>
        <div className="flex items-center justify-center h-64 bg-gray-50 rounded-lg">
          <div className="text-center">
            <TrendingUp className="mx-auto text-gray-300 mb-2" size={32} />
            <p className="text-gray-500">No transaction data available</p>
            <p className="text-sm text-gray-400 mt-1">Add income and expenses to see charts</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      {/* Header with Stats */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Income vs Expenses</h3>
          <p className="text-sm text-gray-600">
            {timeframe === 'monthly' ? 'Last 30 days' : 'Last 12 months'}
          </p>
        </div>
        <div className="text-right">
          <div className="flex items-center space-x-4 text-sm">
            <div>
              <div className="text-green-600 font-semibold">+${stats.totalIncome.toFixed(2)}</div>
              <div className="text-gray-500">Income</div>
            </div>
            <div>
              <div className="text-red-600 font-semibold">-${stats.totalExpenses.toFixed(2)}</div>
              <div className="text-gray-500">Expenses</div>
            </div>
            <div>
              <div className={`font-semibold ${
                stats.netCashFlow >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {stats.netCashFlow >= 0 ? '+' : ''}${stats.netCashFlow.toFixed(2)}
              </div>
              <div className="text-gray-500">Net</div>
            </div>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="h-64">
        <div className="flex h-full items-end space-x-1">
          {chartData.labels.map((label, index) => (
            <div key={index} className="flex-1 flex flex-col items-center space-y-2 group relative">
              {/* Bars Container */}
              <div className="flex space-x-1 w-full justify-center" style={{ height: '180px' }}>
                {/* Income Bar */}
                <div className="flex flex-col items-center justify-end">
                  <div
                    className="bg-green-500 rounded-t w-4 transition-all duration-300 hover:bg-green-600 cursor-pointer group relative"
                    style={{ 
                      height: `${(chartData.income[index] / maxValue) * 160}px`,
                      minHeight: chartData.income[index] > 0 ? '4px' : '0px'
                    }}
                  >
                    {/* Tooltip */}
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                      Income: ${chartData.income[index].toFixed(2)}
                    </div>
                  </div>
                  <span className="text-xs text-gray-500 mt-1">
                    ${chartData.income[index] > 1000 
                      ? `${(chartData.income[index] / 1000).toFixed(1)}k`
                      : chartData.income[index].toFixed(0)
                    }
                  </span>
                </div>
                
                {/* Expense Bar */}
                <div className="flex flex-col items-center justify-end">
                  <div
                    className="bg-red-500 rounded-t w-4 transition-all duration-300 hover:bg-red-600 cursor-pointer group relative"
                    style={{ 
                      height: `${(chartData.expenses[index] / maxValue) * 160}px`,
                      minHeight: chartData.expenses[index] > 0 ? '4px' : '0px'
                    }}
                  >
                    {/* Tooltip */}
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                      Expenses: ${chartData.expenses[index].toFixed(2)}
                    </div>
                  </div>
                  <span className="text-xs text-gray-500 mt-1">
                    ${chartData.expenses[index] > 1000 
                      ? `${(chartData.expenses[index] / 1000).toFixed(1)}k`
                      : chartData.expenses[index].toFixed(0)
                    }
                  </span>
                </div>
              </div>
              
              {/* Net Indicator */}
              {chartData.net[index] !== 0 && (
                <div className={`absolute -bottom-2 text-xs ${
                  chartData.net[index] >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {chartData.net[index] >= 0 ? '↑' : '↓'}
                </div>
              )}
              
              {/* Label */}
              <span className="text-xs text-gray-600 truncate w-full text-center">
                {label}
              </span>
            </div>
          ))}
        </div>
      </div>
      
      {/* Legend and Summary */}
      <div className="flex justify-between items-center mt-6 pt-4 border-t border-gray-200">
        <div className="flex space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span className="text-sm text-gray-600">Income</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded"></div>
            <span className="text-sm text-gray-600">Expenses</span>
          </div>
        </div>
        
        <div className="text-right">
          <div className="flex items-center space-x-2 text-sm">
            {stats.growthRate !== 0 && (
              <>
                {stats.growthRate >= 0 ? (
                  <TrendingUp size={16} className="text-green-500" />
                ) : (
                  <TrendingDown size={16} className="text-red-500" />
                )}
                <span className={stats.growthRate >= 0 ? 'text-green-600' : 'text-red-600'}>
                  {stats.growthRate >= 0 ? '+' : ''}{stats.growthRate.toFixed(1)}%
                </span>
                <span className="text-gray-500">from start</span>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default IncomeExpenseChart;