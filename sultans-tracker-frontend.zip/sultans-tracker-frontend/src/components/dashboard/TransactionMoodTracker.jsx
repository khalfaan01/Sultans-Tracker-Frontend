import { motion } from 'framer-motion';
import { useState } from 'react';
import { useTransactionMood } from '../../contexts/TransactionMoodContext';
import { Smile, Frown, Meh, Zap, Heart, Clock, AlertCircle, TrendingUp } from 'lucide-react';

const moodOptions = [
  { value: 'happy', label: 'Happy', icon: Smile, color: 'text-green-500', bgColor: 'bg-green-50' },
  { value: 'stressed', label: 'Stressed', icon: Frown, color: 'text-red-500', bgColor: 'bg-red-50' },
  { value: 'bored', label: 'Bored', icon: Meh, color: 'text-yellow-500', bgColor: 'bg-yellow-50' },
  { value: 'impulsive', label: 'Impulsive', icon: Zap, color: 'text-purple-500', bgColor: 'bg-purple-50' },
  { value: 'planned', label: 'Planned', icon: Clock, color: 'text-blue-500', bgColor: 'bg-blue-50' },
  { value: 'anxious', label: 'Anxious', icon: AlertCircle, color: 'text-orange-500', bgColor: 'bg-orange-50' },
  { value: 'excited', label: 'Excited', icon: TrendingUp, color: 'text-pink-500', bgColor: 'bg-pink-50' },
  { value: 'regretful', label: 'Regretful', icon: Heart, color: 'text-gray-500', bgColor: 'bg-gray-50' }
];

export default function TransactionMoodTracker({ transaction, onMoodAdded }) {
  const [showMoodSelector, setShowMoodSelector] = useState(false);
  const [selectedMood, setSelectedMood] = useState(null);
  const [intensity, setIntensity] = useState(5);
  const [notes, setNotes] = useState('');
  const { addTransactionMood, loading } = useTransactionMood();

  const handleMoodSelect = async (mood) => {
    setSelectedMood(mood);
    
    const result = await addTransactionMood(transaction.id, {
      mood: mood.value,
      intensity,
      notes: notes.trim() || null
    });

    if (result.success) {
      setShowMoodSelector(false);
      setSelectedMood(null);
      setIntensity(5);
      setNotes('');
      if (onMoodAdded) onMoodAdded(result.data);
    }
  };

  const currentMood = transaction.mood;

  return (
    <div className="relative">
      {/* Mood Display/Trigger */}
      {currentMood ? (
        <div className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${
          moodOptions.find(m => m.value === currentMood.mood)?.bgColor || 'bg-gray-50'
        }`}>
          {(() => {
            const moodConfig = moodOptions.find(m => m.value === currentMood.mood);
            const Icon = moodConfig?.icon || Smile;
            return <Icon className={moodConfig?.color || 'text-gray-500'} size={16} />;
          })()}
          <span className="text-sm font-medium capitalize">{currentMood.mood}</span>
          {currentMood.intensity && (
            <span className="text-xs text-gray-500">({currentMood.intensity}/10)</span>
          )}
          {currentMood.notes && (
            <div className="text-xs text-gray-600 truncate max-w-20" title={currentMood.notes}>
              💬
            </div>
          )}
        </div>
      ) : (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowMoodSelector(true)}
          className="flex items-center space-x-2 px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
        >
          <Smile size={16} className="text-gray-600" />
          <span className="text-sm text-gray-700">How did this make you feel?</span>
        </motion.button>
      )}

      {/* Mood Selector Modal */}
      {showMoodSelector && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute top-full left-0 mt-2 w-80 bg-white rounded-lg shadow-lg border z-10 p-4"
        >
          <h3 className="font-semibold mb-3">Track Your Spending Mood</h3>
          
          {/* Mood Options */}
          <div className="grid grid-cols-4 gap-2 mb-4">
            {moodOptions.map((mood) => (
              <motion.button
                key={mood.value}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleMoodSelect(mood)}
                disabled={loading}
                className={`p-2 rounded-lg flex flex-col items-center justify-center transition-all ${
                  selectedMood?.value === mood.value 
                    ? `${mood.bgColor} border-2 border-black` 
                    : 'bg-gray-50 hover:bg-gray-100'
                } ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <mood.icon className={mood.color} size={20} />
                <span className="text-xs mt-1 capitalize">{mood.label}</span>
              </motion.button>
            ))}
          </div>

          {/* Intensity Slider */}
          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">
              Intensity: {intensity}/10
            </label>
            <input
              type="range"
              min="1"
              max="10"
              value={intensity}
              onChange={(e) => setIntensity(parseInt(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Low</span>
              <span>High</span>
            </div>
          </div>

          {/* Notes */}
          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">Notes (optional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Why did you feel this way?"
              className="w-full p-2 border rounded-lg text-sm resize-none"
              rows="2"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-2">
            <button
              onClick={() => setShowMoodSelector(false)}
              className="flex-1 px-3 py-2 text-sm border rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}