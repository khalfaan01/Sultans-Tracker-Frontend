import { motion } from 'framer-motion';
import { Plus, Calendar, Repeat, Trash2, Edit, Play, Pause } from 'lucide-react';
import { useState, useEffect } from 'react';
import { recurringService } from '../../services/recurringService';
import { ArrowLeft } from 'lucide-react'; // ADD IMPORT
import { useNavigate } from 'react-router-dom'; // ADD IMPORT
import { accountsAPI } from '../../services/api'; // ADD IMPORT

export default function RecurringTransactions() {
  const [showForm, setShowForm] = useState(false);
  const [recurringTransactions, setRecurringTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const navigate = useNavigate(); // ADD NAVIGATION HOOK

  // Load recurring transactions
  const loadRecurringTransactions = async () => {
    try {
      setLoading(true);
      const transactions = await recurringService.getRecurringTransactions();
      setRecurringTransactions(transactions);
    } catch (error) {
      console.error('Error loading recurring transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRecurringTransactions();
  }, []);

  // Delete recurring transaction
  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this recurring transaction?')) {
      try {
        await recurringService.deleteRecurringTransaction(id);
        await loadRecurringTransactions();
      } catch (error) {
        console.error('Error deleting recurring transaction:', error);
        alert('Failed to delete recurring transaction');
      }
    }
  };

  // Toggle active status
  const toggleActive = async (transaction) => {
    try {
      await recurringService.updateRecurringTransaction(transaction.id, {
        ...transaction,
        isActive: !transaction.isActive
      });
      await loadRecurringTransactions();
    } catch (error) {
      console.error('Error updating recurring transaction:', error);
      alert('Failed to update recurring transaction');
    }
  };

  // Edit transaction
  const handleEdit = (transaction) => {
    setEditingTransaction(transaction);
    setShowForm(true);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* ADD BACK TO TRANSACTIONS BUTTON */}
      <button
        onClick={() => navigate('/dashboard/transactions')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
      >
        <ArrowLeft size={16} />
        Back to Transactions
      </button>

      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Recurring Transactions</h2>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => {
            setEditingTransaction(null);
            setShowForm(true);
          }}
          className="flex items-center space-x-2 bg-black text-white px-4 py-2 rounded-lg"
        >
          <Plus size={20} />
          <span>Add Recurring</span>
        </motion.button>
      </div>

      <div className="grid gap-4">
        {recurringTransactions.map((transaction, index) => (
          <motion.div
            key={transaction.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white p-4 rounded-lg shadow-sm border"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`p-2 rounded-lg ${
                  transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                }`}>
                  <Repeat className={
                    transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                  } size={20} />
                </div>
                
                <div>
                  <h3 className="font-semibold">{transaction.description}</h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <span className={`px-2 py-1 rounded-full ${
                      transaction.type === 'income' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                    }`}>
                      {transaction.type}
                    </span>
                    <span className="flex items-center space-x-1">
                      <Repeat size={14} />
                      <span>Every {transaction.frequency}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Calendar size={14} />
                      <span>Next: {new Date(transaction.nextRunDate).toLocaleDateString()}</span>
                    </span>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      transaction.isActive ? 'bg-green-50 text-green-700' : 'bg-gray-50 text-gray-700'
                    }`}>
                      {transaction.isActive ? 'Active' : 'Paused'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <span className={`text-lg font-semibold ${
                  transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {transaction.type === 'income' ? '+' : '-'}${transaction.amount.toFixed(2)}
                </span>
                
                <button 
                  onClick={() => toggleActive(transaction)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  {transaction.isActive ? <Pause size={16} /> : <Play size={16} />}
                </button>
                <button 
                  onClick={() => handleEdit(transaction)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Edit size={16} />
                </button>
                <button 
                  onClick={() => handleDelete(transaction.id)}
                  className="p-2 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 size={16} className="text-red-500" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {recurringTransactions.length === 0 && (
        <div className="text-center py-12">
          <Repeat size={48} className="mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">No Recurring Transactions</h3>
          <p className="text-gray-500">Set up recurring transactions to automate your finances.</p>
        </div>
      )}

      {/* Add/Edit Form Modal */}
      {showForm && (
        <RecurringTransactionForm
          transaction={editingTransaction}
          onClose={() => {
            setShowForm(false);
            setEditingTransaction(null);
          }}
          onSave={loadRecurringTransactions}
        />
      )}
    </div>
  );
}

// Simple form component for adding/editing
function RecurringTransactionForm({ transaction, onClose, onSave }) {
  const [formData, setFormData] = useState({
    description: transaction?.description || '',
    amount: transaction?.amount || '',
    type: transaction?.type || 'expense',
    category: transaction?.category || 'Utilities',
    frequency: transaction?.frequency || 'monthly',
    accountId: transaction?.accountId || '',
    isActive: transaction?.isActive ?? true,
    autoApprove: transaction?.autoApprove || false
  });

  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadAccounts = async () => {
      try {
        const accountsData = await accountsAPI.getAll();
        setAccounts(accountsData);
        if (accountsData.length > 0 && !formData.accountId) {
          setFormData(prev => ({ ...prev, accountId: accountsData[0].id }));
        }
      } catch (error) {
        console.error('Error loading accounts:', error);
      }
    };
    loadAccounts();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (transaction) {
        await recurringService.updateRecurringTransaction(transaction.id, formData);
      } else {
        await recurringService.createRecurringTransaction(formData);
      }
      onSave();
      onClose();
    } catch (error) {
      console.error('Error saving recurring transaction:', error);
      alert('Failed to save recurring transaction: ' + (error.response?.data?.error || error.message));
    } finally {
      setLoading(false);
    }
  };

  const categories = [
    'Utilities', 'Entertainment', 'Food & Dining', 'Shopping', 
    'Healthcare', 'Transportation', 'Education', 'Salary', 
    'Investment', 'Other'
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-96 max-h-[90vh] overflow-y-auto">
        <h3 className="text-lg font-semibold mb-4">
          {transaction ? 'Edit' : 'Add'} Recurring Transaction
        </h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description *
            </label>
            <input
              type="text"
              placeholder="e.g., Netflix Subscription"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="w-full p-2 border rounded"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Amount *
            </label>
            <input
              type="number"
              placeholder="0.00"
              value={formData.amount}
              onChange={(e) => setFormData({...formData, amount: parseFloat(e.target.value)})}
              className="w-full p-2 border rounded"
              step="0.01"
              min="0.01"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Type *
            </label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({...formData, type: e.target.value})}
              className="w-full p-2 border rounded"
              required
            >
              <option value="expense">Expense</option>
              <option value="income">Income</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Category *
            </label>
            <select
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value})}
              className="w-full p-2 border rounded"
              required
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Frequency *
            </label>
            <select
              value={formData.frequency}
              onChange={(e) => setFormData({...formData, frequency: e.target.value})}
              className="w-full p-2 border rounded"
              required
            >
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
              <option value="yearly">Yearly</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Account *
            </label>
            <select
              value={formData.accountId}
              onChange={(e) => setFormData({...formData, accountId: e.target.value})}
              className="w-full p-2 border rounded"
              required
            >
              <option value="">Select an account</option>
              {accounts.map(account => (
                <option key={account.id} value={account.id}>
                  {account.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="autoApprove"
              checked={formData.autoApprove}
              onChange={(e) => setFormData({...formData, autoApprove: e.target.checked})}
              className="rounded"
            />
            <label htmlFor="autoApprove" className="text-sm text-gray-700">
              Auto-approve transactions
            </label>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="isActive"
              checked={formData.isActive}
              onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
              className="rounded"
            />
            <label htmlFor="isActive" className="text-sm text-gray-700">
              Active
            </label>
          </div>

          <div className="flex gap-2 pt-4">
            <button 
              type="submit" 
              disabled={loading}
              className="flex-1 bg-black text-white py-2 rounded disabled:bg-gray-400"
            >
              {loading ? 'Saving...' : (transaction ? 'Update' : 'Create')}
            </button>
            <button type="button" onClick={onClose} className="flex-1 bg-gray-300 py-2 rounded">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}