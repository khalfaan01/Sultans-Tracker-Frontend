// src/components/dashboard/NotificationsSummary.jsx
import { useMemo } from 'react';
import { 
  Bell, Calendar, Target, TrendingUp, AlertTriangle, 
  CheckCircle, Clock, DollarSign
} from 'lucide-react';

const NotificationsSummary = ({ transactions, budgets, goals }) => {
  const notifications = useMemo(() => {
    const notificationsList = [];
    const today = new Date();
    const oneWeekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);

    // 1. Bill due notifications (simulated - you'll need to add bill tracking)
    const upcomingBills = [
      { name: 'Electricity Bill', dueDate: new Date(today.getTime() + 2 * 24 * 60 * 60 * 1000), amount: 120 },
      { name: 'Internet Bill', dueDate: new Date(today.getTime() + 5 * 24 * 60 * 60 * 1000), amount: 80 },
    ].filter(bill => bill.dueDate <= oneWeekFromNow);

    upcomingBills.forEach(bill => {
      const daysUntilDue = Math.ceil((bill.dueDate - today) / (1000 * 60 * 60 * 24));
      notificationsList.push({
        type: 'bill_due',
        title: 'Bill Due Soon',
        message: `${bill.name} of $${bill.amount} due in ${daysUntilDue} day${daysUntilDue !== 1 ? 's' : ''}`,
        severity: daysUntilDue <= 2 ? 'high' : 'medium',
        icon: Calendar,
        dueDate: bill.dueDate,
        amount: bill.amount
      });
    });

    // 2. Goal progress notifications
    goals.forEach(goal => {
      if (!goal.isCompleted && goal.isActive) {
        const progress = (goal.currentAmount / goal.targetAmount) * 100;
        const daysLeft = Math.ceil((new Date(goal.deadline) - today) / (1000 * 60 * 60 * 24));
        
        if (progress >= 90 && progress < 100) {
          notificationsList.push({
            type: 'goal_near_completion',
            title: 'Goal Almost Reached!',
            message: `${goal.name} is ${progress.toFixed(1)}% complete - only $${(goal.targetAmount - goal.currentAmount).toFixed(2)} to go`,
            severity: 'low',
            icon: Target,
            progress: progress,
            goalId: goal.id
          });
        }

        if (daysLeft <= 7 && progress < 100) {
          notificationsList.push({
            type: 'goal_deadline',
            title: 'Goal Deadline Approaching',
            message: `${goal.name} deadline in ${daysLeft} day${daysLeft !== 1 ? 's' : ''}. ${progress.toFixed(1)}% complete`,
            severity: 'medium',
            icon: Clock,
            daysLeft: daysLeft,
            progress: progress
          });
        }

        if (progress >= 100 && !goal.isCompleted) {
          notificationsList.push({
            type: 'goal_completed',
            title: 'Goal Completed! 🎉',
            message: `Congratulations! You've reached your ${goal.name} goal`,
            severity: 'info',
            icon: CheckCircle,
            goalId: goal.id
          });
        }
      }
    });

    // 3. Budget alerts
    budgets.forEach(budget => {
      if (budget.isActive) {
        const spent = transactions
          .filter(tx => tx.type === 'expense' && tx.category === budget.category)
          .reduce((sum, tx) => sum + Math.abs(tx.amount), 0);
        
        const percentage = (spent / budget.limit) * 100;
        
        if (percentage >= 90 && percentage < 100) {
          notificationsList.push({
            type: 'budget_warning',
            title: 'Budget Nearly Exceeded',
            message: `${budget.category} budget is ${percentage.toFixed(1)}% used. $${(budget.limit - spent).toFixed(2)} remaining`,
            severity: 'medium',
            icon: AlertTriangle,
            category: budget.category,
            percentage: percentage
          });
        }

        if (percentage >= 100) {
          notificationsList.push({
            type: 'budget_exceeded',
            title: 'Budget Exceeded',
            message: `${budget.category} budget exceeded by $${(spent - budget.limit).toFixed(2)}`,
            severity: 'high',
            icon: AlertTriangle,
            category: budget.category,
            overspend: spent - budget.limit
          });
        }
      }
    });

    // 4. Spending pattern notifications
    const thisWeekSpending = transactions
      .filter(tx => tx.type === 'expense' && 
        new Date(tx.date) >= new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000))
      .reduce((sum, tx) => sum + Math.abs(tx.amount), 0);
    
    const lastWeekSpending = 500; // This would come from your data
    const spendingChange = ((thisWeekSpending - lastWeekSpending) / lastWeekSpending) * 100;

    if (Math.abs(spendingChange) > 20) {
      notificationsList.push({
        type: 'spending_trend',
        title: 'Spending Trend Alert',
        message: `Your spending this week is ${spendingChange > 0 ? 'up' : 'down'} ${Math.abs(spendingChange).toFixed(1)}% compared to last week`,
        severity: spendingChange > 0 ? 'medium' : 'low',
        icon: TrendingUp,
        change: spendingChange
      });
    }

    // 5. Low balance alert (simulated)
    const totalBalance = 1000; // This would come from your accounts data
    if (totalBalance < 500) {
      notificationsList.push({
        type: 'low_balance',
        title: 'Low Balance Alert',
        message: `Your account balance is low: $${totalBalance.toFixed(2)}`,
        severity: 'high',
        icon: DollarSign,
        balance: totalBalance
      });
    }

    return notificationsList.sort((a, b) => {
      const severityOrder = { high: 0, medium: 1, low: 2, info: 3 };
      return severityOrder[a.severity] - severityOrder[b.severity];
    }).slice(0, 8); // Limit to 8 notifications
  }, [transactions, budgets, goals]);

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'low': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'info': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'high': return <AlertTriangle size={16} />;
      case 'medium': return <Clock size={16} />;
      case 'low': return <Bell size={16} />;
      case 'info': return <CheckCircle size={16} />;
      default: return <Bell size={16} />;
    }
  };

  const unreadCount = notifications.length;

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center">
          <Bell className="mr-2" size={20} />
          Notifications
        </h3>
        {unreadCount > 0 && (
          <span className="px-2 py-1 bg-red-100 text-red-700 text-sm rounded-full">
            {unreadCount} new
          </span>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="text-center py-8">
          <Bell size={32} className="mx-auto text-gray-300 mb-2" />
          <p className="text-gray-500">No notifications</p>
          <p className="text-sm text-gray-400 mt-1">You're all caught up!</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {notifications.map((notification, index) => {
            const IconComponent = notification.icon || Bell;
            return (
              <div
                key={index}
                className={`p-3 rounded-lg border ${getSeverityColor(notification.severity)}`}
              >
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-0.5">
                    <IconComponent size={16} />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h4 className="text-sm font-semibold">{notification.title}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        notification.severity === 'high' ? 'bg-red-100 text-red-700' :
                        notification.severity === 'medium' ? 'bg-orange-100 text-orange-700' :
                        notification.severity === 'low' ? 'bg-blue-100 text-blue-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {notification.severity}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 mt-1">{notification.message}</p>
                    {notification.dueDate && (
                      <p className="text-xs text-gray-500 mt-1">
                        Due: {notification.dueDate.toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Notification Summary */}
      {notifications.length > 0 && (
        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Priority breakdown</span>
          </div>
          <div className="flex space-x-2 mt-2">
            {notifications.some(n => n.severity === 'high') && (
              <span className="px-2 py-1 bg-red-100 text-red-700 text-xs rounded-full">
                {notifications.filter(n => n.severity === 'high').length} Critical
              </span>
            )}
            {notifications.some(n => n.severity === 'medium') && (
              <span className="px-2 py-1 bg-orange-100 text-orange-700 text-xs rounded-full">
                {notifications.filter(n => n.severity === 'medium').length} Important
              </span>
            )}
            {notifications.some(n => n.severity === 'low') && (
              <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                {notifications.filter(n => n.severity === 'low').length} Updates
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationsSummary;