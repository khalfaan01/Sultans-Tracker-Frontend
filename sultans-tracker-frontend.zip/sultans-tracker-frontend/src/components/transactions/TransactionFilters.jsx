// src/components/transactions/TransactionFilters.jsx - FIX OVERVIEW
import React, { useState, useMemo } from 'react';
import { Search, Filter, Calendar, Tag, DollarSign, X } from 'lucide-react';

const TransactionFilters = ({ transactions, onFilterChange, activeView }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [amountRange, setAmountRange] = useState({ min: '', max: '' });
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [typeFilter, setTypeFilter] = useState('all');

  // Get unique categories from transactions
  const categories = useMemo(() => {
    const uniqueCategories = [...new Set(transactions.map(t => t.category))];
    return uniqueCategories.filter(Boolean).sort();
  }, [transactions]);

  // Apply filters automatically when any filter changes
  React.useEffect(() => {
    applyFilters();
  }, [searchTerm, selectedCategories, amountRange, dateRange, typeFilter, transactions]);

  // Apply filters
  const applyFilters = () => {
    const filtered = transactions.filter(transaction => {
      // Search term filter
      const matchesSearch = searchTerm === '' || 
        transaction.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.category?.toLowerCase().includes(searchTerm.toLowerCase());

      // Category filter
      const matchesCategory = selectedCategories.length === 0 || 
        selectedCategories.includes(transaction.category);

      // Amount range filter
      const amount = Math.abs(transaction.amount);
      const matchesMin = amountRange.min === '' || amount >= parseFloat(amountRange.min);
      const matchesMax = amountRange.max === '' || amount <= parseFloat(amountRange.max);

      // Date range filter
      const transactionDate = new Date(transaction.date);
      const matchesStart = dateRange.start === '' || transactionDate >= new Date(dateRange.start);
      const matchesEnd = dateRange.end === '' || transactionDate <= new Date(dateRange.end);

      // Type filter
      const matchesType = typeFilter === 'all' || 
        (typeFilter === 'income' && transaction.amount > 0) ||
        (typeFilter === 'expense' && transaction.amount < 0);

      return matchesSearch && matchesCategory && matchesMin && matchesMax && 
             matchesStart && matchesEnd && matchesType;
    });

    onFilterChange(filtered);
  };

  // Clear all filters
  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategories([]);
    setAmountRange({ min: '', max: '' });
    setDateRange({ start: '', end: '' });
    setTypeFilter('all');
  };

  // Handle category selection
  const toggleCategory = (category) => {
    setSelectedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  // Count active filters
  const activeFilterCount = [
    searchTerm,
    selectedCategories.length,
    amountRange.min || amountRange.max,
    dateRange.start || dateRange.end,
    typeFilter !== 'all'
  ].filter(Boolean).length;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-gray-600" />
          <h3 className="text-lg font-semibold text-gray-900">
            {activeView === 'overview' ? 'Transaction Overview' : 'Filter Transactions'}
          </h3>
          {activeFilterCount > 0 && (
            <span className="bg-blue-100 text-blue-800 text-sm px-2 py-1 rounded-full">
              {activeFilterCount} active
            </span>
          )}
        </div>
        <button
          onClick={clearFilters}
          className="text-sm text-gray-600 hover:text-gray-800 flex items-center gap-1"
        >
          <X className="w-4 h-4" />
          Clear All
        </button>
      </div>

      {/* Search and Quick Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search transactions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Type Filter */}
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="all">All Types</option>
          <option value="income">Income Only</option>
          <option value="expense">Expenses Only</option>
        </select>

        {/* View Summary Button for Overview */}
        {activeView === 'overview' && (
          <button className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
            View Summary
          </button>
        )}
      </div>

      {/* Advanced Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Amount Range */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
            <DollarSign className="w-4 h-4" />
            Amount Range
          </label>
          <div className="flex gap-2">
            <input
              type="number"
              placeholder="Min"
              value={amountRange.min}
              onChange={(e) => setAmountRange(prev => ({ ...prev, min: e.target.value }))}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
            <input
              type="number"
              placeholder="Max"
              value={amountRange.max}
              onChange={(e) => setAmountRange(prev => ({ ...prev, max: e.target.value }))}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
          </div>
        </div>

        {/* Date Range */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
            <Calendar className="w-4 h-4" />
            Date Range
          </label>
          <div className="flex gap-2">
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm"
            />
          </div>
        </div>

        {/* Categories */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
            <Tag className="w-4 h-4" />
            Categories
          </label>
          <select
            multiple
            value={selectedCategories}
            onChange={(e) => {
              const selected = Array.from(e.target.selectedOptions, option => option.value);
              setSelectedCategories(selected);
            }}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm h-24"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
          <p className="text-xs text-gray-500">Hold Ctrl to select multiple</p>
        </div>

        {/* Quick Category Filters */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">Quick Categories</label>
          <div className="flex flex-wrap gap-2">
            {categories.slice(0, 4).map(category => (
              <button
                key={category}
                onClick={() => toggleCategory(category)}
                className={`px-3 py-1 rounded-full text-sm transition-colors ${
                  selectedCategories.includes(category)
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Selected Categories Display */}
      {selectedCategories.length > 0 && (
        <div className="mt-4">
          <div className="flex flex-wrap gap-2">
            {selectedCategories.map(category => (
              <span
                key={category}
                className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center gap-1"
              >
                {category}
                <button
                  onClick={() => toggleCategory(category)}
                  className="hover:text-blue-900"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TransactionFilters;