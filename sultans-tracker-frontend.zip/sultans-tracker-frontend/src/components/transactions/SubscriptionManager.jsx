import React, { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, Filter, Plus, Trash2, Edit3, AlertTriangle, 
  Zap, Calendar, DollarSign, TrendingUp,
  CreditCard, Shield, Bell
} from 'lucide-react';
import { useTransactions } from '../../contexts/TransactionsContext';

const SubscriptionManager = () => {
  const { transactions, recurringTransactions, updateRecurringTransaction, deleteRecurringTransaction } = useTransactions();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('amount');
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});

  // Advanced subscription detection and analysis
  const subscriptions = useMemo(() => {
    const detectedSubscriptions = recurringTransactions || [];
    
    // Enhanced analysis
    return detectedSubscriptions.map(sub => {
      const monthlyCost = sub.amount * (sub.frequency === 'yearly' ? 1/12 : 1);
      const totalYearlyCost = sub.amount * (sub.frequency === 'monthly' ? 12 : 1);
      
      // Calculate value score (0-100)
      let valueScore = 50;
      const usageScore = Math.min((sub.usageHours || 0) / 10, 1) * 40;
      const costEfficiency = Math.max(0, 1 - (monthlyCost / 100)) * 30;
      const necessityScore = sub.category === 'Essential' ? 30 : 10;
      
      valueScore = usageScore + costEfficiency + necessityScore;
      
      // Risk assessment
      const risks = [];
      if (monthlyCost > 50) risks.push('High Cost');
      if (sub.frequency === 'yearly' && sub.amount > 200) risks.push('Large Annual Commitment');
      if (!sub.cancellationUrl) risks.push('Hard to Cancel');
      if (sub.priceIncreased) risks.push('Recent Price Increase');
      
      return {
        ...sub,
        monthlyCost,
        totalYearlyCost,
        valueScore: Math.round(valueScore),
        risks,
        status: sub.status || 'active'
      };
    });
  }, [recurringTransactions]);

  const filteredSubscriptions = useMemo(() => {
    return subscriptions.filter(sub => {
      const matchesSearch = sub.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           sub.category.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || sub.status === statusFilter;
      return matchesSearch && matchesStatus;
    }).sort((a, b) => {
      switch (sortBy) {
        case 'amount': return b.monthlyCost - a.monthlyCost;
        case 'name': return a.name.localeCompare(b.name);
        case 'value': return b.valueScore - a.valueScore;
        case 'date': return new Date(b.nextBillingDate) - new Date(a.nextBillingDate);
        default: return 0;
      }
    });
  }, [subscriptions, searchTerm, statusFilter, sortBy]);

  const analytics = useMemo(() => {
    const totalMonthly = subscriptions.reduce((sum, sub) => sum + sub.monthlyCost, 0);
    const totalYearly = subscriptions.reduce((sum, sub) => sum + sub.totalYearlyCost, 0);
    const byCategory = subscriptions.reduce((acc, sub) => {
      acc[sub.category] = (acc[sub.category] || 0) + sub.monthlyCost;
      return acc;
    }, {});
    
    const optimizationOpportunities = subscriptions.filter(sub => 
      sub.valueScore < 40 && sub.monthlyCost > 10
    ).length;

    return {
      totalMonthly,
      totalYearly,
      byCategory,
      optimizationOpportunities,
      subscriptionCount: subscriptions.length
    };
  }, [subscriptions]);

  const handleEdit = useCallback((subscription) => {
    setEditingId(subscription.id);
    setEditForm({
      name: subscription.name,
      amount: subscription.amount,
      frequency: subscription.frequency,
      category: subscription.category,
      nextBillingDate: subscription.nextBillingDate
    });
  }, []);

  const handleSave = useCallback(async () => {
    try {
      await updateRecurringTransaction(editingId, editForm);
      setEditingId(null);
      setEditForm({});
    } catch (error) {
      console.error('Failed to update subscription:', error);
    }
  }, [editingId, editForm, updateRecurringTransaction]);

  const handleCancelSubscription = useCallback(async (subscriptionId) => {
    if (window.confirm('Are you sure you want to cancel this subscription?')) {
      try {
        await deleteRecurringTransaction(subscriptionId);
      } catch (error) {
        console.error('Failed to cancel subscription:', error);
      }
    }
  }, [deleteRecurringTransaction]);

  const getValueColor = (score) => {
    if (score >= 70) return 'text-green-600 bg-green-100';
    if (score >= 40) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getRiskLevel = (risks) => {
    if (risks.length >= 3) return 'high';
    if (risks.length >= 2) return 'medium';
    return 'low';
  };

  return (
    <div className="space-y-6">
      {/* Analytics Header */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <span className="font-semibold text-gray-700">Monthly Cost</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">
            ${analytics.totalMonthly.toFixed(2)}
          </p>
        </div>
        
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-5 h-5 text-green-600" />
            <span className="font-semibold text-gray-700">Yearly Cost</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">
            ${analytics.totalYearly.toFixed(2)}
          </p>
        </div>
        
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-purple-600" />
            <span className="font-semibold text-gray-700">Subscriptions</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">
            {analytics.subscriptionCount}
          </p>
        </div>
        
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-5 h-5 text-orange-600" />
            <span className="font-semibold text-gray-700">Optimization</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">
            {analytics.optimizationOpportunities}
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-4 items-center justify-between">
        <div className="flex gap-4 flex-1">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search subscriptions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="cancelled">Cancelled</option>
            <option value="paused">Paused</option>
          </select>
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="amount">Sort by Amount</option>
            <option value="name">Sort by Name</option>
            <option value="value">Sort by Value</option>
            <option value="date">Sort by Date</option>
          </select>
        </div>
        
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Plus className="w-4 h-4" />
          Add Subscription
        </button>
      </div>

      {/* Subscription List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <AnimatePresence>
          {filteredSubscriptions.map((subscription, index) => (
            <motion.div
              key={subscription.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: index * 0.1 }}
              className="border-b border-gray-100 last:border-b-0"
            >
              <div className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="font-semibold text-gray-900">{subscription.name}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          subscription.status === 'active' 
                            ? 'bg-green-100 text-green-700'
                            : 'bg-gray-100 text-gray-700'
                        }`}>
                          {subscription.status}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getValueColor(subscription.valueScore)}`}>
                          Value: {subscription.valueScore}/100
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>${subscription.amount} {subscription.frequency}</span>
                        <span>•</span>
                        <span>{subscription.category}</span>
                        <span>•</span>
                        <span>Next: {new Date(subscription.nextBillingDate).toLocaleDateString()}</span>
                      </div>
                      
                      {subscription.risks.length > 0 && (
                        <div className="flex items-center gap-2 mt-2">
                          <AlertTriangle className="w-4 h-4 text-orange-500" />
                          <div className="flex gap-2">
                            {subscription.risks.map((risk, idx) => (
                              <span
                                key={idx}
                                className={`px-2 py-1 rounded-full text-xs ${
                                  getRiskLevel(subscription.risks) === 'high'
                                    ? 'bg-red-100 text-red-700'
                                    : 'bg-orange-100 text-orange-700'
                                }`}
                              >
                                {risk}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleEdit(subscription)}
                      className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleCancelSubscription(subscription.id)}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Edit Form */}
                <AnimatePresence>
                  {editingId === subscription.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 p-4 bg-gray-50 rounded-lg"
                    >
                      <div className="grid grid-cols-2 gap-4">
                        <input
                          type="text"
                          value={editForm.name}
                          onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="Subscription Name"
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        />
                        <input
                          type="number"
                          value={editForm.amount}
                          onChange={(e) => setEditForm(prev => ({ ...prev, amount: parseFloat(e.target.value) }))}
                          placeholder="Amount"
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        />
                        <select
                          value={editForm.frequency}
                          onChange={(e) => setEditForm(prev => ({ ...prev, frequency: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="monthly">Monthly</option>
                          <option value="yearly">Yearly</option>
                        </select>
                        <select
                          value={editForm.category}
                          onChange={(e) => setEditForm(prev => ({ ...prev, category: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="Entertainment">Entertainment</option>
                          <option value="Productivity">Productivity</option>
                          <option value="Essential">Essential</option>
                          <option value="Lifestyle">Lifestyle</option>
                        </select>
                      </div>
                      <div className="flex gap-2 mt-4">
                        <button
                          onClick={handleSave}
                          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          Save Changes
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Empty State */}
      {filteredSubscriptions.length === 0 && (
        <div className="text-center py-12">
          <CreditCard className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No subscriptions found</h3>
          <p className="text-gray-600">
            {subscriptions.length === 0 
              ? "We haven't detected any subscriptions yet. They'll appear here automatically."
              : "Try adjusting your search or filters."
            }
          </p>
        </div>
      )}
    </div>
  );
};

export default SubscriptionManager;