import { motion } from 'framer-motion';
import { useState, useMemo } from 'react';
import { useTransactions } from '../../contexts/TransactionsContext';
import { ArrowLeft } from 'lucide-react'; // ADD IMPORT
import { useNavigate } from 'react-router-dom'; // ADD IMPORT

export default function TransactionHeatmap() {
  const { transactions } = useTransactions();
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const navigate = useNavigate(); // ADD NAVIGATION HOOK

  // Get transactions for selected year
  const yearlyTransactions = useMemo(() => {
    const startDate = new Date(selectedYear, 0, 1);
    const endDate = new Date(selectedYear, 11, 31);
    
    return transactions.filter(tx => {
      const txDate = new Date(tx.date);
      return txDate >= startDate && txDate <= endDate;
    });
  }, [transactions, selectedYear]);

  // Generate heatmap data
  const heatmapData = useMemo(() => {
    const data = {};
    const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    
    // Check for leap year
    if ((selectedYear % 4 === 0 && selectedYear % 100 !== 0) || selectedYear % 400 === 0) {
      daysInMonth[1] = 29;
    }

    // Initialize data structure
    for (let month = 0; month < 12; month++) {
      data[month] = {};
      for (let day = 1; day <= daysInMonth[month]; day++) {
        const dateStr = `${selectedYear}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        data[month][day] = {
          date: new Date(dateStr),
          amount: 0,
          count: 0
        };
      }
    }

    // Populate with transaction data
    yearlyTransactions.forEach(tx => {
      const txDate = new Date(tx.date);
      const month = txDate.getMonth();
      const day = txDate.getDate();
      
      if (data[month] && data[month][day]) {
        data[month][day].amount += Math.abs(tx.amount);
        data[month][day].count += 1;
      }
    });

    return data;
  }, [yearlyTransactions, selectedYear]);

  // Get intensity color based on spending
  const getIntensityColor = (amount) => {
    if (amount === 0) return 'bg-gray-100';
    
    // Find max amount for scaling
    const allAmounts = Object.values(heatmapData).flatMap(month => 
      Object.values(month).map(day => day.amount)
    );
    const maxAmount = Math.max(...allAmounts);
    
    const intensity = amount / maxAmount;
    
    if (intensity < 0.2) return 'bg-green-100';
    if (intensity < 0.4) return 'bg-green-200';
    if (intensity < 0.6) return 'bg-green-300';
    if (intensity < 0.8) return 'bg-green-400';
    return 'bg-green-500';
  };

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - i);

  return (
    <div className="space-y-6">
      {/* ADD BACK TO TRANSACTIONS BUTTON */}
      <button
        onClick={() => navigate('/dashboard/transactions')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
      >
        <ArrowLeft size={16} />
        Back to Transactions
      </button>

      <div className="bg-white rounded-lg shadow-sm border p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Spending Heatmap</h2>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(parseInt(e.target.value))}
            className="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
          >
            {years.map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
        </div>

        <div className="overflow-x-auto">
          <div className="flex space-x-2 min-w-max">
            {monthNames.map((monthName, monthIndex) => (
              <div key={monthIndex} className="flex flex-col items-center space-y-1">
                <div className="text-xs font-medium text-gray-600 mb-2">{monthName}</div>
                <div className="grid grid-rows-7 gap-1">
                  {Object.entries(heatmapData[monthIndex] || {}).map(([day, dayData]) => {
                    const date = dayData.date;
                    const dayOfWeek = date.getDay();
                    
                    return (
                      <motion.div
                        key={`${monthIndex}-${day}`}
                        whileHover={{ scale: 1.2 }}
                        className={`w-4 h-4 rounded-sm border ${getIntensityColor(dayData.amount)} ${
                          dayData.count > 0 ? 'cursor-pointer' : ''
                        }`}
                        title={`${date.toLocaleDateString()}: $${dayData.amount.toFixed(2)} (${dayData.count} transactions)`}
                      />
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="mt-6 flex items-center justify-center space-x-4 text-xs">
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-gray-100 rounded-sm border"></div>
            <span>No spending</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-green-100 rounded-sm border"></div>
            <span>Low</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-green-300 rounded-sm border"></div>
            <span>Medium</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-green-500 rounded-sm border"></div>
            <span>High</span>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-6 grid grid-cols-3 gap-4 text-center">
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">
              ${yearlyTransactions
                .filter(tx => tx.type === 'income')
                .reduce((sum, tx) => sum + tx.amount, 0)
                .toFixed(2)}
            </div>
            <div className="text-sm text-gray-600">Total Income</div>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-red-600">
              ${Math.abs(yearlyTransactions
                .filter(tx => tx.type === 'expense')
                .reduce((sum, tx) => sum + tx.amount, 0))
                .toFixed(2)}
            </div>
            <div className="text-sm text-gray-600">Total Expenses</div>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">
              {yearlyTransactions.length}
            </div>
            <div className="text-sm text-gray-600">Total Transactions</div>
          </div>
        </div>
      </div>
    </div>
  );
}