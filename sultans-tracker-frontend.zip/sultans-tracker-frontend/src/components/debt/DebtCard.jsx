// src/components/debt/DebtCard.jsx - FIXED NUMBER DISPLAY
import React, { useState } from 'react';
import { useDebt } from '../../contexts/DebtContext.jsx';
import PaymentModal from './PaymentModal.jsx';

const DebtCard = ({ debt, onEdit }) => {
  const { deleteDebt } = useDebt();
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showActions, setShowActions] = useState(false);

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this debt?')) {
      await deleteDebt(debt.id);
    }
  };

  const getDebtTypeIcon = (type) => {
    const icons = {
      loan: '💰',
      credit_card: '💳',
      mortgage: '🏠',
      personal: '👥',
      auto: '🚗',
      student: '🎓'
    };
    return icons[type] || '📊';
  };

  // FIXED: Proper currency formatting
  const formatCurrency = (amount) => {
    if (typeof amount !== 'number') {
      amount = parseFloat(amount) || 0;
    }
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  // FIXED: Proper percentage formatting
  const formatPercentage = (rate) => {
    if (typeof rate !== 'number') {
      rate = parseFloat(rate) || 0;
    }
    return `${rate.toFixed(2)}%`;
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString();
  };

  return (
    <>
      <div className={`bg-white rounded-xl shadow-sm border p-6 transition-all hover:shadow-md ${
        !debt.isActive ? 'bg-green-50 border-green-200' : 'border-gray-200'
      }`}>
        {/* Header */}
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-start space-x-3 flex-1">
            <div className="text-2xl mt-1">{getDebtTypeIcon(debt.type)}</div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900 text-lg">{debt.name}</h3>
              {debt.lender && (
                <p className="text-sm text-gray-600 mt-1">{debt.lender}</p>
              )}
            </div>
          </div>
          
          {/* Actions Dropdown */}
          <div className="relative">
            <button 
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-500 hover:text-gray-700"
              onClick={() => setShowActions(!showActions)}
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z"/>
              </svg>
            </button>
            
            {showActions && (
              <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg py-2 z-10 min-w-[120px]">
                <button 
                  onClick={() => {
                    onEdit(debt);
                    setShowActions(false);
                  }}
                  className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Edit
                </button>
                <button 
                  onClick={() => {
                    setShowPaymentModal(true);
                    setShowActions(false);
                  }}
                  className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Make Payment
                </button>
                <button 
                  onClick={handleDelete}
                  className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 transition-colors"
                >
                  Delete
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Stats Grid - FIXED SPACING AND DISPLAY */}
<div className="debt-stats-grid mb-4">
  <div className="debt-stat-item">
    <div className="debt-stat-label">Balance</div>
    <div className="debt-stat-value text-gray-900 dark:text-white">
      {formatCurrency(debt.balance)}
    </div>
  </div>
  <div className="debt-stat-item">
    <div className="debt-stat-label">Interest</div>
    <div className="debt-stat-value text-gray-900 dark:text-white">
      {formatPercentage(debt.interestRate)}
    </div>
  </div>
  <div className="debt-stat-item">
    <div className="debt-stat-label">Min Payment</div>
    <div className="debt-stat-value text-gray-900 dark:text-white">
      {formatCurrency(debt.minimumPayment)}
    </div>
  </div>
</div>

        {/* Due Date */}
        {debt.dueDate && (
          <div className="text-sm text-gray-600 mb-4 flex items-center gap-2">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd"/>
            </svg>
            Due: {formatDate(debt.dueDate)}
          </div>
        )}

        {/* Progress Bar */}
        {debt.isActive && debt.progressPercentage > 0 && (
          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-600 mb-1">
              <span>Progress</span>
              <span>{debt.progressPercentage.toFixed(1)}% Paid</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-green-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${debt.progressPercentage}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Payoff Estimate */}
        {debt.estimatedPayoffMonths && debt.isActive && (
          <div className="text-sm text-gray-600 mb-4 flex items-center gap-2">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd"/>
            </svg>
            Payoff: {debt.estimatedPayoffMonths} months
          </div>
        )}

        {/* Paid Off Badge */}
        {!debt.isActive && (
          <div className="bg-green-100 text-green-800 px-3 py-2 rounded-lg text-sm font-medium text-center mb-4">
            🎉 Paid Off!
          </div>
        )}

        {/* Make Payment Button */}
        {debt.isActive && (
          <button 
            className="w-full bg-black text-white py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium"
            onClick={() => setShowPaymentModal(true)}
          >
            Make Payment
          </button>
        )}
      </div>

        {/* Payment Modal */}
      {showPaymentModal && (
        <PaymentModal 
          debt={debt}
          onClose={() => setShowPaymentModal(false)}
          onSuccess={() => setShowPaymentModal(false)}
        />
      )}
    </>
  );
};

export default DebtCard;