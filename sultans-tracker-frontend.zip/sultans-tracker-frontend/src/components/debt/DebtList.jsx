import React, { useState } from 'react';
import { useDebt } from '../../contexts/DebtContext.jsx';
import { useAuth } from '../../contexts/AuthContext.jsx';
import DebtCard from './DebtCard.jsx';
import DebtForm from './DebtForm.jsx';
import DebtAnalytics from './DebtAnalytics.jsx';

const DebtList = () => {
  const { debts, loading, error } = useDebt();
  const { isAuthenticated } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [editingDebt, setEditingDebt] = useState(null);
  const [view, setView] = useState('list');

  const handleEdit = (debt) => {
    setEditingDebt(debt);
    setShowForm(true);
  };

  const handleFormClose = () => {
    setShowForm(false);
    setEditingDebt(null);
  };

  const activeDebts = debts.filter(debt => debt.isActive);
  const paidOffDebts = debts.filter(debt => !debt.isActive);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">Error loading debts: {error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="mt-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-8 text-center">
          <h2 className="text-xl font-bold text-yellow-800 mb-4">Authentication Required</h2>
          <p className="text-yellow-700 mb-6">Please log in to access Debt Management</p>
          <button 
            onClick={() => window.location.href = '/login'}
            className="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium"
          >
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Debt Management</h1>
          <p className="text-gray-600 mt-2">Track and manage your debts in one place</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          {/* View Toggle */}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button 
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                view === 'list' 
                  ? 'bg-white text-gray-900 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              onClick={() => setView('list')}
            >
              List View
            </button>
            <button 
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                view === 'analytics' 
                  ? 'bg-white text-gray-900 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              onClick={() => setView('analytics')}
            >
              Analytics
            </button>
          </div>
          
          {/* Add Debt Button */}
          <button 
            className="bg-black text-white px-6 py-2 rounded-lg hover:bg-gray-800 transition-colors font-medium flex items-center gap-2"
            onClick={() => setShowForm(true)}
          >
            <span>+</span>
            Add New Debt
          </button>
        </div>
      </div>

      {/* Content */}
      {view === 'analytics' ? (
        <DebtAnalytics />
      ) : (
        <>
          {/* Active Debts Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">
                Active Debts ({activeDebts.length})
              </h2>
            </div>
            
            {activeDebts.length === 0 ? (
              <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                <div className="text-6xl mb-4">💸</div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No active debts found</h3>
                <p className="text-gray-600 mb-6">Add your first debt to get started with debt tracking</p>
                <button 
                  onClick={() => setShowForm(true)}
                  className="bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium"
                >
                  Add Your First Debt
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeDebts.map(debt => (
                  <DebtCard 
                    key={debt.id} 
                    debt={debt} 
                    onEdit={handleEdit}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Paid Off Debts Section */}
          {paidOffDebts.length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">
                Paid Off ({paidOffDebts.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {paidOffDebts.map(debt => (
                  <DebtCard 
                    key={debt.id} 
                    debt={debt} 
                    onEdit={handleEdit}
                  />
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* Debt Form Modal */}
      {showForm && (
        <DebtForm 
          debt={editingDebt}
          onClose={handleFormClose}
          onSave={handleFormClose}
        />
      )}
    </div>
  );
};

export default DebtList;