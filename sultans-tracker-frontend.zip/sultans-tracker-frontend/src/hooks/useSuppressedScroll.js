import { useScroll } from 'framer-motion';
import { useEffect } from 'react';

export function useSuppressedScroll(options) {
  useEffect(() => {
    const originalWarn = console.warn;
    console.warn = (...args) => {
      if (args[0]?.includes?.('ensure that the container has a non-static position')) {
        return;
      }
      originalWarn.apply(console, args);
    };
    
    return () => {
      console.warn = originalWarn;
    };
  }, []);
  
  return useScroll(options);
}