import { useState, useEffect, useCallback } from 'react';
import { useTransactions } from '../contexts/TransactionsContext';

export const useCalendarData = () => {
  const { transactions } = useTransactions();
  const [calendarData, setCalendarData] = useState({});
  const [selectedDate, setSelectedDate] = useState(null);
  const [loading, setLoading] = useState(true);

  // Process transactions into calendar format
  const processCalendarData = useCallback(() => {
    setLoading(true);
    
    const data = transactions.reduce((acc, transaction) => {
      const date = new Date(transaction.date).toISOString().split('T')[0];
      
      if (!acc[date]) {
        acc[date] = {
          transactions: [],
          totalIncome: 0,
          totalExpenses: 0,
          netAmount: 0
        };
      }

      acc[date].transactions.push(transaction);
      
      if (transaction.amount > 0) {
        acc[date].totalIncome += transaction.amount;
      } else {
        acc[date].totalExpenses += Math.abs(transaction.amount);
      }
      
      acc[date].netAmount += transaction.amount;
      
      return acc;
    }, {});

    setCalendarData(data);
    setLoading(false);
  }, [transactions]);

  // Get data for specific date
  const getDateData = useCallback((dateString) => {
    return calendarData[dateString] || {
      transactions: [],
      totalIncome: 0,
      totalExpenses: 0,
      netAmount: 0
    };
  }, [calendarData]);

  // Get monthly summary
  const getMonthlySummary = useCallback((year, month) => {
    const monthStr = month.toString().padStart(2, '0');
    const prefix = `${year}-${monthStr}`;
    
    const monthlyData = Object.entries(calendarData)
      .filter(([date]) => date.startsWith(prefix))
      .reduce((acc, [, data]) => {
        acc.totalIncome += data.totalIncome;
        acc.totalExpenses += data.totalExpenses;
        acc.netAmount += data.netAmount;
        acc.transactionCount += data.transactions.length;
        return acc;
      }, {
        totalIncome: 0,
        totalExpenses: 0,
        netAmount: 0,
        transactionCount: 0
      });

    return monthlyData;
  }, [calendarData]);

  // Get spending trends for a date range
  const getDateRangeData = useCallback((startDate, endDate) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    const rangeData = Object.entries(calendarData)
      .filter(([date]) => {
        const currentDate = new Date(date);
        return currentDate >= start && currentDate <= end;
      })
      .reduce((acc, [date, data]) => {
        acc.dates[date] = data;
        acc.summary.totalIncome += data.totalIncome;
        acc.summary.totalExpenses += data.totalExpenses;
        acc.summary.netAmount += data.netAmount;
        acc.summary.transactionCount += data.transactions.length;
        return acc;
      }, {
        dates: {},
        summary: {
          totalIncome: 0,
          totalExpenses: 0,
          netAmount: 0,
          transactionCount: 0
        }
      });

    return rangeData;
  }, [calendarData]);

  // Get heatmap data for calendar view
  const getHeatmapData = useCallback((year, month) => {
    const monthStr = month.toString().padStart(2, '0');
    const prefix = `${year}-${monthStr}`;
    
    const heatmapData = {};
    
    // Initialize all days in the month
    const daysInMonth = new Date(year, month, 0).getDate();
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${prefix}-${day.toString().padStart(2, '0')}`;
      heatmapData[dateStr] = getDateData(dateStr);
    }

    return heatmapData;
  }, [getDateData]);

  // Get top spending days
  const getTopSpendingDays = useCallback((limit = 5) => {
    return Object.entries(calendarData)
      .filter(([, data]) => data.totalExpenses > 0)
      .sort(([,a], [,b]) => b.totalExpenses - a.totalExpenses)
      .slice(0, limit)
      .map(([date, data]) => ({
        date,
        amount: data.totalExpenses,
        transactionCount: data.transactions.length
      }));
  }, [calendarData]);

  // Refresh data
  const refreshData = useCallback(() => {
    processCalendarData();
  }, [processCalendarData]);

  // Initialize data
  useEffect(() => {
    processCalendarData();
  }, [processCalendarData]);

  return {
    calendarData,
    selectedDate,
    setSelectedDate,
    loading,
    getDateData,
    getMonthlySummary,
    getDateRangeData,
    getHeatmapData,
    getTopSpendingDays,
    refreshData
  };
};

export default useCalendarData;